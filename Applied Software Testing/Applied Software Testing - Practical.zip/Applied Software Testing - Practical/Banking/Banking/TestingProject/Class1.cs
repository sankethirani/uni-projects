﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingProject
{
    public class BankAccount
    {
        private String accountHolderName;
        private long accountNumber;
        private double balance;
        public const String INSUFFICIENT_BALANCE = "Insufficient balalnce.";
        public const String WRONG_ACCOUNT_NUMBER = "Wrong account number generated.";        
        public const String WRONG_AMOUNT = "Cannot withdraw or deposit zero or negative amount.";        

        public String AccountHolderName { get { return accountHolderName; } }

        public double Balance { get { return balance; } }

        public BankAccount(double initialBalance, String accountHolderName)
        {
            this.accountHolderName = accountHolderName;
            balance = initialBalance;
            long newAccountNumber = GetNewAccontNumber();
            if (IsAccountNumberVerified(newAccountNumber)) { accountNumber = newAccountNumber; }
        }

        public double Debit(double amount)
        {
            if (IsAmountVerified(amount))
            {
                if (amount >= balance)
                {                    
                    throw new ArgumentOutOfRangeException(INSUFFICIENT_BALANCE, "balance");
                }
                else { balance -= amount; return balance; }
            }
            else { throw new ArgumentOutOfRangeException(WRONG_AMOUNT, "amount"); }
        }

        public void Deposit(double amount)
        {
            if (IsAmountVerified(amount))
            {
                balance += amount;
            }
            else { throw new ArgumentOutOfRangeException("amount", WRONG_AMOUNT); }
        }

        private long GetNewAccontNumber()
        {
            Random random = new Random();
            return random.Next(31999999, 33000000);
        }

        public bool IsAccountNumberVerified(long accountNumber)
        {
            string acNumber = accountNumber.ToString();
            bool isVerified = true;
            if (acNumber.Length != 8 || acNumber.Substring(0, 2) != "32")
            {
                isVerified = false;
                throw new ArgumentException(WRONG_ACCOUNT_NUMBER, "AccountNumber");                
            }
            return isVerified;
        }

        private bool IsAmountVerified(double amount)
        {
            if (amount <= 0)
            {
                return false;
            }
            else { return true; }
        }

        public void UpdateAccountHolderName(String newName)
        {
            accountHolderName = newName;
        }        

    }
}
