﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestingProject;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ID_01_TestAccountNumber_BVAValid()
        {
            //A valid account number is generated (min)
            //Arrange            
            long accountNumber = 32000000;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");            

            //Assert            
            Assert.IsTrue(bankAccount.IsAccountNumberVerified(accountNumber));
        }

        [TestMethod]
        public void ID_02_TestAccountNumber_BVAValid()
        {
            //A valid account number is generated (min+1)
            //Arrange            
            long accountNumber = 32000000 + 1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");

            //Assert            
            Assert.IsTrue(bankAccount.IsAccountNumberVerified(accountNumber));
        }

        [TestMethod]
        public void ID_03_TestAccountNumber_BVAValid()
        {
            //A valid account number is generated (max-1)
            //Arrange            
            long accountNumber = 32999999 - 1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");

            //Assert            
            Assert.IsTrue(bankAccount.IsAccountNumberVerified(accountNumber));
        }

        [TestMethod]
        public void ID_04_TestAccountNumber_BVAValid()
        {
            //A valid account number is generated (max)
            //Arrange            
            long accountNumber = 32999999;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");

            //Assert            
            Assert.IsTrue(bankAccount.IsAccountNumberVerified(accountNumber));
        }

        [TestMethod]
        public void ID_05_TestAccountNumber_InValidLength()
        {
            //An invalid account number that invalidates account number policy a(account number must be 8 digits long)            
            //Arrange
            long accountNumber = 328547584;
            String expected = BankAccount.WRONG_ACCOUNT_NUMBER;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");                        
            try
            {
                bankAccount.IsAccountNumberVerified(accountNumber);
            }

            catch(Exception ex)
            {
                String actual = ex.Message;
                //Assert
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_06_TestAccountNumber_InValidStart()
        {
            //An invalid account number that invalidates account number policy b (Account number must start with 32)
            //Arrange
            long accountNumber = 10245651;
            String expected = BankAccount.WRONG_ACCOUNT_NUMBER;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try
            {
                bankAccount.IsAccountNumberVerified(accountNumber);
            }
            catch (Exception ex)
            {
                String actual = ex.Message;
                //Assert
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_07_TestAccountNumber_BVAInvalid()
        {
            //An invalid BVA test case for lower end of account number (min account number - 1)
            //Act
            long accountNumber = 32000000 - 1;
            String expected = BankAccount.WRONG_ACCOUNT_NUMBER;

            //Arrange
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try
            {
                bankAccount.IsAccountNumberVerified(accountNumber);
            }
            catch (Exception ex)
            {
                String actual = ex.Message;
                //Assert
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_08_TestAccountNumber_BVAInvalid()
        {
            //An invalid BVA test case for upper end of account number (max account number + 1)
            //Act
            long accountNumber = 32999999 + 1;
            String expected = BankAccount.WRONG_ACCOUNT_NUMBER;

            //Arrange
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try
            {
                bankAccount.IsAccountNumberVerified(accountNumber);
            }
            catch (Exception ex)
            {
                String actual = ex.Message;
                //Assert
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_09_TestUpdateAccountHolderName_Valid()
        {
            //A valid test case that verifies accountHolderName is property updated
            //Arrange
            String expected = "Hirani";

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            bankAccount.UpdateAccountHolderName(expected);
            String actual = bankAccount.AccountHolderName;

            //Assert
            StringAssert.Contains(expected, actual);

        }

        [TestMethod]
        public void ID_10_TestDeposit_BVAValid()
        {
            //Verify a valid deposit operation and check the balance afterwards(min)
            //Arrange
            double expected = 1501;
            double amount = 1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            bankAccount.Deposit(amount);
            double actual = bankAccount.Balance;

            //Assert
            Assert.AreEqual(expected, actual, 0.0);
        }

        [TestMethod]
        public void ID_11_TestDeposit_BVAValid()
        {
            //Verify a valid deposit operation and check the balance afterwards (min+1)
            //Arrange
            double expected = 1502;
            double amount = 1 + 1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            bankAccount.Deposit(amount);
            double actual = bankAccount.Balance;

            //Assert
            Assert.AreEqual(expected, actual, 0.0);
        }

        [TestMethod]
        public void ID_12_TestDeposit_InvalidZeroAmount()
        {
            //Perform a deposit with zero amount
            //Arrange
            String expected = BankAccount.WRONG_AMOUNT;
            double amount = 0;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try { bankAccount.Deposit(amount); }
            catch (ArgumentOutOfRangeException ex)
            {
                //Assert
                String actual = ex.Message;
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_13_TestDeposit_InvalidNegativeAmount()
        {
            //Perform a deposit with negative amount 
            //Arrange
            String expected = BankAccount.WRONG_AMOUNT;
            double amount = -1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try { bankAccount.Deposit(amount); }
            catch (ArgumentOutOfRangeException ex)
            {
                //Assert
                String actual = ex.Message;
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_14_TestDebit_Valid()
        {
            //Verify a valid debit operation and check the balance and debited amount afterwards
            //Arrange            
            double amount = 150;
            double expected = 1350;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            double actual = bankAccount.Debit(amount);

            //Assert
            Assert.AreEqual(expected, actual, 0.0);
        }

        [TestMethod]
        public void ID_15_TestDebit_InvalidZeroAmount()
        {
            //Perform a debit with zero amount
            //Arrange
            String expected = BankAccount.WRONG_AMOUNT;
            double amount = 0;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try { bankAccount.Debit(amount); }
            catch (ArgumentOutOfRangeException ex)
            {
                //Assert
                String actual = ex.Message;
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_16_TestDebit_InvalidNegativeAmount()
        {
            //Perform a debit with a negative amount
            //Arrange
            String expected = BankAccount.WRONG_AMOUNT;
            double amount = -1;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try { bankAccount.Debit(amount); }
            catch (ArgumentOutOfRangeException ex)
            {
                //Assert
                String actual = ex.Message;
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

        [TestMethod]
        public void ID_17_TestDebit_InsuffecientBalance()
        {
            //Perform a debit that triggers insufficient balance
            //Arrange
            String expected = BankAccount.INSUFFICIENT_BALANCE;
            double amount = 1500;

            //Act
            BankAccount bankAccount = new BankAccount(1500, "Sanket");
            try { bankAccount.Debit(amount); }
            catch (ArgumentOutOfRangeException ex)
            {
                //Assert
                String actual = ex.Message;
                StringAssert.Contains(actual, expected);
                return;
            }

            Assert.Fail("No Exception was thrown");
        }

    }
}
