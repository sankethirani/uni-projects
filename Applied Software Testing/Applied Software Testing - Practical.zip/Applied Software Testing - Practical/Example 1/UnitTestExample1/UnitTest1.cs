﻿using System;
using Example1;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestExample1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ID_01_TestStudentAge_Valid()
        {
            //test verifies that the Student class calculates age properly
            //Arrange
            int birthYear = 1999;
            int expected = DateTime.Now.Year - birthYear;

            //Act
            Student student = new Student();
            student.Birthyear = birthYear;
            int actual = student.Age;

            //Assert
            Assert.AreEqual(expected, actual, 0, "Age test failed. Expected:" + expected.ToString() + "Actual" + actual.ToString());
        }

        [TestMethod]
        public void ID_02_TestStudentNumber_Valid()
        {
            //Arrange
            long studentNumber = 1800024562;
            long expected = studentNumber;

            //Act
            Student student = new Student();
            student.StudentNumber = studentNumber;
            long actual = student.StudentNumber;

            //Assert
            Assert.AreEqual(expected, actual, 0.0, "Valid student number test failed");
        }

        [TestMethod]
        public void ID_03_TestStudentNumber_inValidLength()
        {
            //Arrange
            long studentNumber = 186587623;
            String expected = Student.WRONG_ARGUMENT_EXCEPTION_MESSAGE;
            //Act
            Student student = new Student();
            try
            {
                student.StudentNumber = studentNumber;

            }
            catch (Exception ex)
            {
                //Assert
                // Test passes if this assert is true
                string actual = ex.Message;
                StringAssert.Contains(actual, expected);
                // Add return to finish this test method.
                return;
            }
            // Test fails if the exception is not thrown.
            Assert.Fail("No exception was thrown.");
        }

        [TestMethod]
        public void ID_04_TestStudentNumber_inValidStart()
        {
            //Arrange
            long studentNumber = 2465876232;
            String expected = Student.WRONG_ARGUMENT_EXCEPTION_MESSAGE;
            //Act
            Student student = new Student();
            try
            {
                student.StudentNumber = studentNumber;

            }
            catch (Exception ex)
            {
                //Assert                
                string actual = ex.Message;
                StringAssert.Contains(actual, expected);
                
                return;
            }         
            Assert.Fail("No exception was thrown.");
        }

        [TestMethod]
        public void ID_05_TestBirthyear_BVAValid()
        {
            //Min birthyear
            //Arrange
            int birthYear = DateTime.Now.Year - 100;
            int expected = DateTime.Now.Year - birthYear;

            //Act
            Student student = new Student();
            student.Birthyear = birthYear;
            int actual = student.Age;

            //Assert
            Assert.AreEqual(expected, actual, 0.0, "Age test failed. Expected:" + expected.ToString() + "Actual" + actual.ToString());
        }

        [TestMethod]
        public void ID_06_TestBirthyear_BVAValid()
        {
            //Min birthyear + 1
            //Arrange
            int birthYear = DateTime.Now.Year - 100 + 1;
            int expected = DateTime.Now.Year - birthYear;

            //Act
            Student student = new Student();
            student.Birthyear = birthYear;
            int actual = student.Age;

            //Assert
            Assert.AreEqual(expected, actual, 0.0, "Age test failed. Expected:" + expected.ToString() + "Actual" + actual.ToString());
        }

        [TestMethod]
        public void ID_07_TestBirthyear_BVAValid()
        {
            //Max birthyear 
            //Arrange
            int birthYear = DateTime.Now.Year - 16;
            int expected = DateTime.Now.Year - birthYear;

            //Act
            Student student = new Student();
            student.Birthyear = birthYear;
            int actual = student.Age;

            //Assert
            Assert.AreEqual(expected, actual, 0.0, "Age test failed. Expected:" + expected.ToString() + "Actual" + actual.ToString());
        }

        [TestMethod]
        public void ID_08_TestBirthyear_BVAValid()
        {
            //Max birthyear 
            //Arrange
            int birthYear = DateTime.Now.Year - 16-1;
            int expected = DateTime.Now.Year - birthYear;

            //Act
            Student student = new Student();
            student.Birthyear = birthYear;
            int actual = student.Age;

            //Assert
            Assert.AreEqual(expected, actual, 0.0, "Age test failed. Expected:" + expected.ToString() + "Actual" + actual.ToString());
        }

        [TestMethod]
        public void ID_09_TestBirthYear_BVAInvalid()
        {
            //Min Birthyear - 1
            //Arrange
            int birthYear = DateTime.Now.Year - 100 -1;
            string expected = Student.WRONG_ARGUMENT_EXCEPTION_MESSAGE;

            //Act
            Student student = new Student();
            try
            {
                student.Birthyear = birthYear;
            }

            catch(Exception ex)
            {
                //Assert
                string actual = ex.Message;                
                StringAssert.Contains(actual, expected);
                return;
            }
            Assert.Fail("No exception thrown");
        }

        [TestMethod]
        public void ID_10_TestBirthYear_BVAInvalid()
        {
            //Max Birthyear + 1
            //Arrange
            int birthYear = DateTime.Now.Year - 16 + 1;
            string expected = Student.WRONG_ARGUMENT_EXCEPTION_MESSAGE;

            //Act
            Student student = new Student();
            try
            {
                student.Birthyear = birthYear;
            }

            catch (Exception ex)
            {
                //Assert
                string actual = ex.Message;                
                StringAssert.Contains(actual, expected);
                return;
            }
            Assert.Fail("No exception thrown");
        }
    }
}
