﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    public class Student
    {
        private int birthyear;
        private string firstName;
        private string lastName;
        private long studentNumber;
        public const string WRONG_ARGUMENT_EXCEPTION_MESSAGE = "Wrong argument supplied";

        public string FirstName { get { return firstName; } set { firstName = value; } }

        public string LastName { get { return lastName; } set { lastName = value; } }

        public long StudentNumber
        {
            get { return studentNumber; }

            set
            {
                bool isVerified = IsStudentNumberVerified(value);

                if (isVerified == true)
                {
                    studentNumber = value;
                }

                else
                {
                    throw new ArgumentException(WRONG_ARGUMENT_EXCEPTION_MESSAGE,"StudentNumber");
                }
            }
        }

        public int Birthyear {
            set
            {
                if (IsAgeValid(value))
                    birthyear = value;
                else
                    throw new ArgumentOutOfRangeException("birthyear", WRONG_ARGUMENT_EXCEPTION_MESSAGE);
            }
        }

        public int Age { get { return DateTime.Now.Year - birthyear; } }

        private bool IsStudentNumberVerified (long value)
        {
            string number = value.ToString();
            bool isValid = true;
            /*another way of checking first two digits
            if(number.Substring(0,2) != "18"))
            number[0].ToString() != "1" && number[1].ToString() != "8"
            */

            if (number.Length != 10 || number.Substring(0, 2) != "18")
            {
                isValid= false;
            }

            return isValid;
        }

        private bool IsAgeValid(int birthyear)
        {
            bool isValid = true;
            int currentYear = DateTime.Now.Year;
            int currentAge = currentYear - birthyear;

            if(currentAge <16 || currentAge > 100)
            {
                isValid = false;
            }

            return isValid;
        }
    }

    
}
