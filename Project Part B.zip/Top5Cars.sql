SELECT        TOP (5) CarModel.Model, CarModel.Manufacturer, IndividualCar.Colour, CarModel.EngineSize
FROM            CarModel INNER JOIN
                         IndividualCar ON CarModel.ModelID = IndividualCar.Model_ID INNER JOIN
                         Cars_Sold ON IndividualCar.CarID = Cars_Sold.Car_For_Sale_Id
						 GROUP BY CarModel.Model, CarModel.Manufacturer, IndividualCar.Colour, CarModel.EngineSize
ORDER BY COUNT(Cars_Sold.Car_For_Sale_Id) DESC
