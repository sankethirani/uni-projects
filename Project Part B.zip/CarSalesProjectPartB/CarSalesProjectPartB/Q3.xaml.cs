﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarSalesProjectPartB
{
    /// <summary>
    /// Interaction logic for Q3.xaml
    /// </summary>
    public partial class Q3 : UserControl
    {
        public Q3()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int year;
            int month;
            if(int.TryParse(yearTextBox.Text, out year))
            {

            }
            else
            {
                MessageBox.Show("Please enter year");
            }
            if(int.TryParse(monthTextBox.Text, out month)){

            }
            else
            {
                MessageBox.Show("Please enter month");
            }

            using (Entities ctx = new Entities())
                {
                    grid.ItemsSource = ctx.GetTotalMonthlySalesByMonth(month, year).ToList();
                }
        }


    }
}
