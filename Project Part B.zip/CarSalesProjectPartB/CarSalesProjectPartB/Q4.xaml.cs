﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarSalesProjectPartB
{
    /// <summary>
    /// Interaction logic for Q4.xaml
    /// </summary>
    public partial class Q4 : UserControl
    {
        public Q4()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

            DateTime? date1 = startDatePicker.SelectedDate;
            DateTime? date2 = endDatePicker.SelectedDate;
            string model = modelTextBox.Text;

            if (date1 != null && date2 != null && model != "") {
                using (Entities ctx = new Entities())
                {
                    grid.ItemsSource = ctx.TotalSalesByModelByDate(date1, date2, model).ToList();
                }
            }
            else
            {
                MessageBox.Show("Please select dates and/or enter model");
            }

        }
    }
}
