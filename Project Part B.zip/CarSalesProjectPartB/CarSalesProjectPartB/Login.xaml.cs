﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarSalesProjectPartB
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            using(Entities ctx = new Entities())
            {
                GetEmployeeEntry_Result em = ctx.GetEmployeeEntry(UserNameTextBox.Text, PasswordBox.Password).FirstOrDefault();
                
                if(em == null)
                {
                    MessageBox.Show("Please enter correct login details");
                }
                else
                {
                    string role = em.Role;
                    if (role == "Admin")
                    {
                        MainWindow mw = new MainWindow();
                        mw.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Reports restricted to Admins");
                    }
                }
            }
        }
    }
}
