SELECT        YEAR(Cars_Sold.Date_Sold) as SalesYear, MONTH(Cars_Sold.Date_Sold) as SalesMonth, SUM(Cars_Sold.Sale_Price)
FROM            CarModel INNER JOIN
                         IndividualCar ON CarModel.ModelID = IndividualCar.Model_ID INNER JOIN
                         Cars_Sold ON IndividualCar.CarID = Cars_Sold.Car_For_Sale_Id
						 WHERE MONTH(Cars_Sold.Date_Sold) = 4
						 GROUP BY YEAR(Cars_Sold.Date_Sold), MONTH(Cars_Sold.Date_Sold)
						 