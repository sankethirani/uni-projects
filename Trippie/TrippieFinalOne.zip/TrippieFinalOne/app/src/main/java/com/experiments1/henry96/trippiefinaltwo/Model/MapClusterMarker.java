package com.experiments1.henry96.trippiefinaltwo.Model;

import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.ClusterItem;

public class MapClusterMarker implements ClusterItem {
    private final LatLng mPosition;
    private String mTitle;
    private String mSnippet;
    private BitmapDescriptor icon;
    private float rotation;

    public MapClusterMarker(MarkerOptions mo){
        this.mPosition = mo.getPosition();
        this.mTitle = mo.getTitle();
        this.mSnippet = mo.getSnippet();
        this.icon = mo.getIcon();
        this.rotation = mo.getRotation();
    }

    @Override
    public LatLng getPosition() {
        return mPosition;
    }

    @Override
    public String getTitle() {
        return mTitle;
    }

    @Override
    public String getSnippet() {
        return mSnippet;
    }

    BitmapDescriptor getIcon(){
        return icon;
    }

    float getRotation(){
        return rotation;
    }
}
