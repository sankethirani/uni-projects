package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.experiments1.henry96.trippiefinaltwo.Fragment.ChangePhotoDialog;
import com.experiments1.henry96.trippiefinaltwo.Helper.FilePaths;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.InputValidation;
import com.experiments1.henry96.trippiefinaltwo.Model.Address;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.github.abdularis.civ.CircleImageView;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener,
        DatePickerDialog.OnDateSetListener, ChangePhotoDialog.OnPhotoReceivedListener {

    private static final String TAG = "RegisterActivity";
    private Button btnRegister;
    private EditText etEmail, etFName, etLName, etAddress;
    private EditText etDOB;
    private ProgressBar progressBar;
    private Intent intent;

    private DatePickerDialog dtpDate;
    private Calendar mDateOfBirth;

    private Uri mSelectedImageUri;
    private CircleImageView imgProfile;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore db;
    private FirebaseDatabase firebaseDatabase;
    private InputValidation inputValidation;

    private byte[] mBytes;
    private double progress;
    private static final double MB_THRESHOLD = 5.0, MB = 1000000.0;

    private TextView[] compulsoryTextViews;

    private User user;
    private Address address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        init();
        setUpAppBar();
        initObjects();
        initListeners();
        createDatePicker();

        // Initialize the SDK
        Places.initialize(getApplicationContext(), getString(R.string.google_places_key));
    }

    private void setUpAppBar() {
        Toolbar myToolbar = findViewById(R.id.myToolbar);
        TextView mTitle = myToolbar.findViewById(R.id.tvmTitle);
        mTitle.setText(getString(R.string.text_register));
        setSupportActionBar(myToolbar);
        ActionBar actionBar = this.getSupportActionBar();
        Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 223) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                address = new Address(place.getAddress(), new GeoPoint(Objects.requireNonNull(place.getLatLng()).latitude, place.getLatLng().longitude));
                ((EditText) findViewById(R.id.set_address_field)).setText(Objects.requireNonNull(place.getAddress()).replace(", New Zealand", ""));
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i(TAG, Objects.requireNonNull(status.getStatusMessage()));
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    private void createDatePicker() {
        mDateOfBirth = Calendar.getInstance();
        dtpDate = new DatePickerDialog(this, this, mDateOfBirth.get(Calendar.YEAR), mDateOfBirth.get(Calendar.MONTH), mDateOfBirth.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        mDateOfBirth.set(Calendar.YEAR, year);
        mDateOfBirth.set(Calendar.DATE, dayOfMonth);
        mDateOfBirth.set(Calendar.MONTH, month);
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.UK);
        Calendar minimumAge = Calendar.getInstance();
        minimumAge.add(Calendar.YEAR, -18);
        if (mDateOfBirth.before(minimumAge)) {
            etDOB.setError(null);
            String date = df.format(mDateOfBirth.getTime());
            Log.e(TAG, "Task Date:" + Helpers.showTime(mDateOfBirth, "dd/MM/yyyy"));
            etDOB.setText(date);
        } else {
            //validate code
            etDOB.setFocusableInTouchMode(true);
            etDOB.setError("You must be 18 or over to use this app!");
            etDOB.requestFocus();
            etDOB.setFocusableInTouchMode(false);
            etDOB.setInputType(InputType.TYPE_NULL);
        }
    }

    private void initListeners() {
        btnRegister.setOnClickListener(this);
        etDOB.setOnClickListener(this);
        imgProfile.setOnClickListener(this);
        findViewById(R.id.set_address_field).setOnClickListener(view -> {
            Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, Arrays.asList(Place.Field.LAT_LNG, Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS)).setCountry("NZ").setTypeFilter(TypeFilter.ADDRESS).build(this);
            startActivityForResult(intent, 223);
        });
    }

    private void initObjects() {
        firebaseAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
    }

    private void init() {
        btnRegister = findViewById(R.id.btnCompleteDelivery);
        etEmail = findViewById(R.id.edit_email);
//        etPassword = findViewById(R.id.edit_password);
//        etCPassword = findViewById(R.id.edit_confirm_password);
        etFName = findViewById(R.id.edit_fname);
        etLName = findViewById(R.id.edit_lname);
        etAddress = findViewById(R.id.set_address_field);
//        etMobile = findViewById(R.id.edit_mobile);
        imgProfile = findViewById(R.id.iv_profilepicture);
        progressBar = findViewById(R.id.progressBar);
        etDOB = findViewById(R.id.edit_dob);
        intent = getIntent();

        inputValidation = new InputValidation(this);

        compulsoryTextViews = new TextView[]{etEmail, etFName, etLName,
                etAddress, etDOB};

        //SKH button was clickable without entering an information therefore I added this line of code
        btnRegister.setEnabled(false);

        TextWatcher disabledFieldWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                checkAllFieldsFilled();
            }
        };

        for (TextView tv : compulsoryTextViews) tv.addTextChangedListener(disabledFieldWatcher);

//        setMaxLengthForMobileNumber();
    }

//    private void setMaxLengthForMobileNumber() {
//        InputFilter filter = (source, start, end, dest, dstart, dend) -> {
//            for (int i = start; i < end; ++i) {
//                if (!Pattern.compile("[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890]*").matcher(String.valueOf(source.charAt(i))).matches()) {
//                    return "";
//                }
//            }
//
//            return null;
//        };
//
//    }
//

    public void setDate(View view) {
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnCompleteDelivery:
                postDataToDB();
                break;
            case R.id.edit_dob:
                dtpDate.show();
                break;
            case R.id.iv_profilepicture:
                ChangePhotoDialog dialog = new ChangePhotoDialog();
                dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
                break;
        }
    }

    private void checkAllFieldsFilled() {
        boolean isFilled = true;

        for (TextView tv : compulsoryTextViews) {
            if (tv.getText().toString().isEmpty()) {
                isFilled = false;
                break;
            }
        }
        if (isFilled) isFilled = mSelectedImageUri != null;


        btnRegister.setEnabled(isFilled);
        btnRegister.setText(isFilled ? getString(R.string.text_register) : getString(R.string.fill_all_fields));
        btnRegister.setBackgroundResource(isFilled ? R.drawable.custom_button_blue : R.drawable.custom_button_disabled);


    }

    private void postDataToDB() {
        String email = etEmail.getText().toString().trim();
//        String password = etPassword.getText().toString().trim();
        String fName = etFName.getText().toString().trim();
        String lName = etLName.getText().toString().trim();
        String mobile = intent.getStringExtra("phone_number");

        registerUser(email, fName, lName, address, mobile);

    }

    private void registerUser(String email, final String fName, final String lName, final Address address, final String mobile) {

        /* Validate Email here */

        if (!inputValidation.isEditTextEmailValid(email)) {
//            Helpers.showToast(this, "");
//            etEmail.setFocusableInTouchMode(true);
            etEmail.setError("Your Email is Invalid! Please Enter it again!");
            etEmail.requestFocus();
//            etEmail.setFocusableInTouchMode(false);
            etEmail.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            return;
        }

        Helpers.showDialog(progressBar);

//        firebaseAuth.createUserWithEmailAndPassword(email, password)
//                .addOnSuccessListener(authResult -> {
//                            sendVerificationEmail();
        Log.e(TAG, "addOnCompleteListener: isSuccessful:" + Objects.requireNonNull(firebaseAuth.getCurrentUser()).getUid());
        FirebaseUser usercur = firebaseAuth.getCurrentUser();
        user = new User();
        user.setFirstNm(fName);
        user.setLastNm(lName);
        user.setPhone(mobile);
        user.setAddress(address);
        user.setUserId(usercur.getUid());
        user.setDateofbirth(mDateOfBirth.getTime());
        user.setCreateDate(Calendar.getInstance().getTime());
        user.setLastActiveDate(Calendar.getInstance().getTime());
        user.setStatus(true);
        user.setNumberOfRatings(0);
        user.setRating(4.5);
        user.setEmail(email.trim());
        user.setDriver(false);

        if (mSelectedImageUri != null) {
            uploadNewPhoto(mSelectedImageUri);
        } else {
            user.setImage("https://firebasestorage.googleapis.com/v0/b/trippiefinaltwo.appspot.com/o/images%2Fusers%2FDummyuser%2Fuser.png?alt=media&token=ae4ccf78-38f4-4ff3-966a-e377a34edd82");
            addUserToFirebase();
        }
//                        }
//                )
//                .addOnFailureListener(e -> {
//                    Log.e(TAG, Objects.requireNonNull(e.getMessage()));
//                    String message = e.getMessage();
//                    Helpers.showToast(RegisterActivity.this, message.substring(message.indexOf('[') + 1).replace("]", ""));
//                    Helpers.hideDialog(progressBar);
//                });
    }

    private void addUserToFirebase() {
        //SKH add user info to realtime database for chatting
        addUserToRealtimeDatabase();
        db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid()).set(user, SetOptions.merge())
                .addOnCompleteListener(task -> {

                    Log.e(TAG, "collection + document + onComplete");
                    Helpers.hideDialog(progressBar);
                    Log.e(TAG, "Dialog Hide");
//                    firebaseAuth.signOut();
                    Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    RegisterActivity.this.finish();
//                    Helpers.redirectLoginScreen(TAG, RegisterActivity.this);

                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "onFailure");
                    Helpers.hideDialog(progressBar);
                    Log.e(TAG, "Dialog Hide");
//                    firebaseAuth.signOut();
//                    Helpers.redirectLoginScreen(TAG, RegisterActivity.this);
                    Helpers.showToast(RegisterActivity.this, "Something went wrong! Please try again");

                });
    }

    //SKH save some information about the user to the realtime database. Reduces number of database reads when displaying a user's chats
    private void addUserToRealtimeDatabase() {
        HashMap<String, Object> userHash = new HashMap<>();
        userHash.put("username", user.getFirstNm());
        userHash.put("profile_image", user.getImage());
        firebaseDatabase.getReference().child("users").child(user.getUserId()).setValue(userHash).addOnFailureListener(e -> {
            Helpers.hideDialog(progressBar);
            Helpers.showToast(RegisterActivity.this, "Error connecting to the database");
        });
    }

//    private void sendVerificationEmail() {
//        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//        if (user != null) {
//            user.sendEmailVerification()
//                    .addOnCompleteListener(task -> {
//                        if (task.isSuccessful()) {
//                            Helpers.showToast(RegisterActivity.this, "Please verify your email address!");
//                        }
//                    });
//        }
//    }

    @Override
    public void getImagePath(Uri imagePath, String tag) {
        if (!TextUtils.isEmpty(imagePath.toString())) {
            mSelectedImageUri = imagePath;
            Log.d(TAG, "getImagePath: got the image uri: " + mSelectedImageUri);
            Picasso.get().load(imagePath).into(imgProfile);
            checkAllFieldsFilled();
        }
    }

    public void uploadNewPhoto(Uri imageUri) {
        Log.d(TAG, "uploadNewPhoto: uploading new profile photo to firebase storage.");
        BackgroundImageResize resize = new BackgroundImageResize(this);
        resize.execute(imageUri);
    }

    public static class BackgroundImageResize extends AsyncTask<Uri, Integer, byte[]> {

        private WeakReference<RegisterActivity> registerActivityWeakReference;
        Bitmap mBitmap;

        BackgroundImageResize(RegisterActivity context) {
            registerActivityWeakReference = new WeakReference<>(context);
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected byte[] doInBackground(Uri... params) {
            Log.d(TAG, "doInBackground: started.");

            if (mBitmap == null) {
                InputStream iStream = null;

                Log.d(TAG, "Bitmap == null");
                try {
                    iStream = registerActivityWeakReference.get().getContentResolver().openInputStream(params[0]);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                if (iStream != null) {
                    ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
                    int bufferSize = 1024;
                    byte[] buffer = new byte[bufferSize];

                    int len;
                    try {
                        while ((len = iStream.read(buffer)) != -1) {
                            byteBuffer.write(buffer, 0, len);
                        }
                        iStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    return byteBuffer.toByteArray();
                }
                return null;

            } else {
                int size = mBitmap.getRowBytes() * mBitmap.getHeight();
                ByteBuffer byteBuffer = ByteBuffer.allocate(size);
                mBitmap.copyPixelsToBuffer(byteBuffer);
                byte[] bytes = byteBuffer.array();
                byteBuffer.rewind();
                return bytes;
            }
        }


        @Override
        protected void onPostExecute(byte[] bytes) {

            RegisterActivity activity = registerActivityWeakReference.get();
            if (registerActivityWeakReference == null || activity.isFinishing()) return;

            Helpers.showDialog(activity.progressBar);
            activity.mBytes = bytes;
            //execute the upload
            activity.executeUploadTask();
        }
    }

    private void executeUploadTask() {
        FilePaths filePaths = new FilePaths();
        final StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child(filePaths.FIREBASE_IMAGE_STORAGE + "/" + Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid()
                        + "/profile_image"); //just replace the old image with the new one

        if (mBytes.length / MB < MB_THRESHOLD) {

/*            StorageMetadata metadata = new StorageMetadata.Builder()
                    .setContentType("image/jpg")
                    .setContentLanguage("en") //see nodes below
                    .setCustomMetadata("Mitch's special meta data", "JK nothing special here")
                    .setCustomMetadata("location", "Iceland")
                    .build();*/
            UploadTask uploadTask = storageReference.putBytes(mBytes); //without metadata

            uploadTask.addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                Log.d(TAG, "onSuccess: firebase download url : " + uri.toString());
                if (user != null) {
                    user.setImage(uri.toString());
                    addUserToFirebase();
                }

            })).addOnFailureListener(exception -> {
                Helpers.showToast(RegisterActivity.this, "could not upload photo");
                Helpers.hideDialog(progressBar);
            }).addOnProgressListener(taskSnapshot -> {
                double currentProgress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                if (currentProgress > (progress + 15)) {
                    progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                    Log.d(TAG, "onProgress: Upload is " + progress + "% done");
                }
            })
            ;
        } else {
            Helpers.showToast(this, "Image is too Large");
            Helpers.hideDialog(progressBar);
        }

    }


}
