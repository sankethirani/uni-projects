package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.PersonMeetingDriver;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static android.provider.DocumentsContract.EXTRA_INITIAL_URI;


public class CreateTrippieSecondStepFragment extends Fragment implements AddPhotoCreateTrippieInterface {

    private View v;
    private TextView pickupDateTextView,deliveryDateTextView;
    private DialogFragment pickupTimePicker,deliveryTimePicker;
    private boolean isPickupTimeBox;
    private Date pickupDate, deliveryDate;
    private Button nextPageButton;
    private LinearLayout someoneElseDetails;
    private RadioGroup rg;
    private ImageView imageHolder;
    private List<FrameLayout> tempImageViewHolders;
    private FloatingActionButton plusButton, minusButton;
    private TextView[] compulsoryEditTexts;
    private EditText[] optionalEditTexts;
    private int minimumTravelTime;
    private Calendar pickupStartingTime, deliveryStartingTime;
    private CreateTrippieFourthStepFragment fourthStepFragment;
    private static final int PICK_MAIN_IMAGE_REQUEST = 6124, PICK_CAMERA_IMAGE_REQUEST = 5473, MY_CAMERA_PERMISSION_CODE = 2789;
    private List<Uri> mainImageUris;
    private RadioButton meButton;

    public CreateTrippieSecondStepFragment(CreateTrippieFourthStepFragment fourthStepFragment){
        this.fourthStepFragment = fourthStepFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_create_trippie_second_step, container, false);
        initialiseLayout();
        initialiseListeners();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).setViewCreated(1);
    }

    void relistTrippieAfterLayoutInitialised(Trippie trippie) {
        compulsoryEditTexts[0].setText(trippie.getTitle());
        compulsoryEditTexts[1].setText(trippie.getDescription());
        compulsoryEditTexts[2].setText(Helpers.addTrailingZerosToCurrency(trippie.getItemValue()));
        compulsoryEditTexts[3].setText(trippie.getInstructions());
        if(trippie.getMeetingDriverPickup() == PersonMeetingDriver.Me.getNumericType()){
            meButton.setChecked(true);
        }
        else{
            v.findViewById(R.id.someone_else_pickup_button).performClick();
            optionalEditTexts[0].setText(trippie.getPersonMeetingPickupName());
            optionalEditTexts[1].setText(trippie.getPersonMeetingPickupPhone());
        }
    }

    private void initialiseLayout(){
        tempImageViewHolders = new ArrayList<>();
        pickupDateTextView = v.findViewById(R.id.pickup_date_text);
        deliveryDateTextView = v.findViewById(R.id.delivery_date_text);
        nextPageButton = v.findViewById(R.id.create_trippie_second_page_next_button);
        meButton = v.findViewById(R.id.me_button);
        meButton.setChecked(true);
        someoneElseDetails = v.findViewById(R.id.someone_else_fields);
        rg = v.findViewById(R.id.meeting_driver_pickup_group);
        imageHolder = v.findViewById(R.id.first_image_holder);
        FrameLayout firstListingImageHolder = v.findViewById(R.id.first_listing_image_holder);
        LinearLayout listingImagesHolder = v.findViewById(R.id.listing_images_holder);

        plusButton = (FloatingActionButton) getLayoutInflater().inflate(R.layout.myfab, listingImagesHolder,false);
        plusButton.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(Objects.requireNonNull(getContext()),R.color.main_colour_blue)));
        FrameLayout.LayoutParams plusLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        plusLayoutParams.setMargins(0,0,20,30);
        plusLayoutParams.width = plusLayoutParams.height = (int)(25 * getResources().getDisplayMetrics().density);
        plusButton.setScaleType(ImageView.ScaleType.CENTER);
        plusButton.setLayoutParams(plusLayoutParams);

        firstListingImageHolder.addView(plusButton);
        compulsoryEditTexts = new TextView[]{v.findViewById(R.id.title_edit_text),v.findViewById(R.id.description_edit_text),v.findViewById(R.id.value_edit_text),v.findViewById(R.id.delivery_instructions_edit_text),pickupDateTextView,deliveryDateTextView};
        optionalEditTexts = new EditText[]{v.findViewById(R.id.someone_else_name_text),v.findViewById(R.id.someone_else_number)};
        mainImageUris = new ArrayList<>();
    }

    private void initialiseListeners(){
        pickupDateTextView.setOnClickListener(c -> {
            if(!deliveryDateTextView.getText().toString().isEmpty()){
                pickupStartingTime.setTime(deliveryDate);
                pickupStartingTime.add(Calendar.MINUTE, 0-minimumTravelTime);
            }
            else if(pickupDateTextView.getText().toString().isEmpty()) initialiseTimeFields();


            pickupTimePicker.show(getChildFragmentManager(),"TimePicker");
            isPickupTimeBox = true;
        });
        deliveryDateTextView.setOnClickListener(c -> {
            if(!pickupDateTextView.getText().toString().isEmpty()) {
                deliveryStartingTime.setTime(pickupDate);
                deliveryStartingTime.add(Calendar.MINUTE,minimumTravelTime + 1);
            }
            else if(deliveryDateTextView.getText().toString().isEmpty()) initialiseTimeFields();

            deliveryTimePicker.show(getChildFragmentManager(),"TimePicker");
            isPickupTimeBox = false;
        });
        nextPageButton.setOnClickListener(c -> ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(2,true));
        rg.setOnCheckedChangeListener((radioGroup, i) -> {
            someoneElseDetails.setVisibility(((RadioButton)rg.findViewById(i)).getText().toString().contains("Someone else") ? View.VISIBLE : View.GONE); //toggle visibility of someone else's details based on radio button
            checkAllFieldsFilled();
        });
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void afterTextChanged(Editable editable) { checkAllFieldsFilled(); }
        };
        for(TextView et : compulsoryEditTexts) et.addTextChangedListener(tw);
        for(EditText et: optionalEditTexts) et.addTextChangedListener(tw);
        plusButton.setOnClickListener(c -> new AddPhotoCreateTrippie(this).showNow(getChildFragmentManager(),"photoDialog"));
    }

    private void initialiseTimeFields(){
        pickupStartingTime = Calendar.getInstance();
        pickupStartingTime.add(Calendar.HOUR, 2);
        pickupTimePicker = new TimePickerFragment(this, pickupStartingTime);
        deliveryStartingTime = Calendar.getInstance();
        deliveryStartingTime.setTime(pickupStartingTime.getTime());
        deliveryStartingTime.add(Calendar.MINUTE,minimumTravelTime);
        deliveryTimePicker = new TimePickerFragment(this, deliveryStartingTime);
    }

    private void checkAllFieldsFilled(){
        boolean allFilledOut = true;
        if(someoneElseDetails.getVisibility() == View.VISIBLE){
            for(EditText et : optionalEditTexts) if(et.getText().toString().isEmpty()) allFilledOut = false; //if "someone else" is selected, check if all optional fields are filled}
            if(optionalEditTexts[1].getText().toString().length() < 9) allFilledOut = false;
        }
        if(allFilledOut) for(TextView et : compulsoryEditTexts) if(et.getText().toString().isEmpty()) allFilledOut = false; //check if all compulsory fields are filled
        if(mainImageUris.isEmpty()) allFilledOut = false;
        if(!allFilledOut){
            nextPageButton.setEnabled(false);
            nextPageButton.setText(R.string.fill_all_fields);
            nextPageButton.setBackgroundResource(R.drawable.custom_button_disabled);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).disableTabs(2);
        }
        else {
            nextPageButton.setEnabled(true);
            nextPageButton.setText(R.string.next_button_text);
            nextPageButton.setBackgroundResource(R.drawable.custom_button_blue);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(2,false);
            fourthStepFragment.getTrippie().setTitle(((TextView)v.findViewById(R.id.title_edit_text)).getText().toString());
            fourthStepFragment.getTrippie().setDescription(((TextView)v.findViewById(R.id.description_edit_text)).getText().toString());
            fourthStepFragment.getTrippie().setItemValue(Double.parseDouble(((TextView)v.findViewById(R.id.value_edit_text)).getText().toString()));
            fourthStepFragment.getTrippie().setInstructions(((TextView)v.findViewById(R.id.delivery_instructions_edit_text)).getText().toString());
            if(someoneElseDetails.getVisibility() == View.VISIBLE){
                fourthStepFragment.getTrippie().setPersonMeetingPickupName(optionalEditTexts[0].getText().toString());
                fourthStepFragment.getTrippie().setPersonMeetingPickupPhone(optionalEditTexts[1].getText().toString());
            }
            fourthStepFragment.getTrippie().setMeetingDriverPickup(someoneElseDetails.getVisibility() == View.VISIBLE ? PersonMeetingDriver.Someone_else.getNumericType() : PersonMeetingDriver.Me.getNumericType());
            fourthStepFragment.setMainImageFilePaths(mainImageUris);
        }
    }

    void getPickedDateTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        //int hours = 96;
        //calendar.add(Calendar.HOUR_OF_DAY, hours);
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
        String strDate = formatter.format(date);
        Calendar minimumPickupTime = Calendar.getInstance(), minimumDeliveryTime = Calendar.getInstance();
        minimumPickupTime.add(Calendar.MINUTE,119);
        minimumDeliveryTime.setTime(minimumPickupTime.getTime());
        minimumDeliveryTime.add(Calendar.MINUTE,minimumTravelTime);

        String travelTime = String.valueOf(minimumTravelTime);
        if(minimumTravelTime >= 60){
            int hours = (int)Math.floor(minimumTravelTime / 60);
            travelTime = hours + " hours and " + (minimumTravelTime - hours * 60);
        }

        if (isPickupTimeBox) {
            if(date.after(minimumPickupTime.getTime())) {
                calendar.add(Calendar.MINUTE, minimumTravelTime - 1);
                if (!deliveryDateTextView.getText().toString().isEmpty() && (deliveryDate.before(date) || deliveryDate.before(calendar.getTime()))) {
                    setErrorOnDateFields(pickupDateTextView,"Pickup time must be at least " + travelTime + " minutes before delivery time!");
                } else {
                    pickupDateTextView.setError(null);
                    pickupDateTextView.setText(strDate);
                    pickupDate = date;
                    fourthStepFragment.getTrippie().setPickupTime(pickupDate);
                }
            }
            else{
                setErrorOnDateFields(pickupDateTextView,"Pickup time must be at least two hours in the future!");
            }
        } else {

            //if(date.after(minimumPickupTime.getTime())) {
            if(date.after(new Date())){
                calendar.add(Calendar.MINUTE, 0 - minimumTravelTime);
                if (!pickupDateTextView.getText().toString().isEmpty() && (pickupDate.after(date) || pickupDate.after(calendar.getTime()))) {
                    setErrorOnDateFields(deliveryDateTextView, "Delivery time must be at least " + travelTime + " minutes after pickup time!");
                } else if (pickupDateTextView.getText().toString().isEmpty() && date.before(minimumDeliveryTime.getTime())) {
                    setErrorOnDateFields(deliveryDateTextView,"Not enough time allocated for the journey! Please make sure you allow at least two hours for pickup and " + travelTime + " minutes for delivery.");
                } else {
                    deliveryDateTextView.setError(null);
                    deliveryDateTextView.setText(strDate);
                    deliveryDate = date;
                    fourthStepFragment.getTrippie().setDeliveryTime(deliveryDate);
                }
            }
            else{
                setErrorOnDateFields(deliveryDateTextView,"Delivery time must be in the future! Please make sure you allow at least two hours for pickup and " + travelTime + " minutes for delivery.");
            }
        }
    }

    private void setErrorOnDateFields(TextView field, String message){
        field.setFocusableInTouchMode(true);
        field.requestFocus();
        field.setError(message);
        field.setFocusableInTouchMode(false);
    }

    void setMinimumTravelTime(int minutes){
        this.minimumTravelTime = minutes;
        pickupDateTextView.setText("");
        deliveryDateTextView.setText("");
        //initialiseTimeFields();
    }

    public void openFileChooser() {
        Intent imageSelectIntent = new Intent();
        imageSelectIntent.setType("image/*");
        imageSelectIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { //if we're on API 26 or higher
            imageSelectIntent.putExtra(EXTRA_INITIAL_URI, "/storage/emulated/0/"); //place user in /storage/emulated/0/ by default
        }
        imageSelectIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        startActivityForResult(imageSelectIntent, PICK_MAIN_IMAGE_REQUEST);
    }

    public void openCamera() {
        if (Objects.requireNonNull(getContext()).checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
        }
        else
        {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, PICK_CAMERA_IMAGE_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(getContext(), "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, PICK_CAMERA_IMAGE_REQUEST);
            }
            else
            {
                Toast.makeText(getContext(), "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(data != null && (data.getData() != null || data.getExtras() != null && data.getExtras().get("data") != null)) {
            Uri imageUri = null;
            if (requestCode == PICK_MAIN_IMAGE_REQUEST) {
                imageUri = data.getData();
            } else if (requestCode == PICK_CAMERA_IMAGE_REQUEST) {
                Bitmap photo = (Bitmap) Objects.requireNonNull(data.getExtras()).get("data");
                imageUri = Helpers.returnUriFromBitmap(photo, "capturedimage");
            }
            if (imageUri != null) addPicturesToTrippie(imageUri);
        }
    }

    private void addPicturesToTrippie(@NonNull Uri imageUri){
        minusButton = (FloatingActionButton) getLayoutInflater().inflate(R.layout.myfab, (ViewGroup) imageHolder.getParent(),false);
        minusButton.setImageDrawable(ContextCompat.getDrawable(Objects.requireNonNull(getContext()),R.drawable.ic_remove_white_24dp));
        minusButton.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(),R.color.text_colour_red)));
        FrameLayout.LayoutParams minusLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        minusLayoutParams.setMargins(0,30,20,0);
        minusLayoutParams.width = minusLayoutParams.height = (int)(25 * getResources().getDisplayMetrics().density);
        minusButton.setScaleType(ImageView.ScaleType.CENTER);
        minusButton.setLayoutParams(minusLayoutParams);

        mainImageUris.add(imageUri);

        if(mainImageUris.size() == 3) plusButton.hide();
        doAfterPicturesLoaded(imageUri);

    }

    private void doAfterPicturesLoaded(Uri imageUri){
        FrameLayout fl = new FrameLayout(Objects.requireNonNull(getContext()));
        LinearLayout listingImagesHolder = v.findViewById(R.id.listing_images_holder);
        if(imageHolder.getDrawable().getConstantState() == Objects.requireNonNull(ContextCompat.getDrawable(getContext(), R.drawable.ic_upload_up_arrow_outline_in_circular_button)).getConstantState()) {
            Picasso.get().load(imageUri).into(imageHolder);
            v.findViewById(R.id.listing_image_label).setVisibility(View.GONE);
            if(((ViewGroup)imageHolder.getParent()).indexOfChild(minusButton) == -1) ((ViewGroup) imageHolder.getParent()).addView(minusButton);
        } else {
            ImageView iv = new ImageView(getContext());
            fl.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.height = lp.width = (int) (100 * Resources.getSystem().getDisplayMetrics().density);
            iv.setLayoutParams(lp);
            fl.addView(iv);
            fl.addView(minusButton);

            tempImageViewHolders.add(fl);
            listingImagesHolder.addView(fl);
            Picasso.get().load(imageUri).into(iv);

        }
        minusButton.setOnClickListener(button ->{
            if(mainImageUris.size() == 1) mainImageUris.clear();
            else mainImageUris.remove(imageUri);

            if(button.getParent() != imageHolder.getParent()) {
                listingImagesHolder.removeView(fl);
                tempImageViewHolders.remove(fl);
            }
            else {
                imageHolder.setImageDrawable(ContextCompat.getDrawable(getContext(), R.drawable.ic_upload_up_arrow_outline_in_circular_button));
                if(mainImageUris.size() == 1 && tempImageViewHolders.size() > 0){
                    for(FrameLayout tempFl : tempImageViewHolders) listingImagesHolder.removeView(tempFl);
                    tempImageViewHolders.clear();
                    Picasso.get().load(imageUri).into(imageHolder);
                }
            }

            if(mainImageUris.size() == 2) plusButton.show();
            else if(mainImageUris.size() == 0){
                ViewGroup parent = (ViewGroup)imageHolder.getParent();
                parent.removeView(parent.getChildAt(parent.getChildCount() - 1));
            }

        });

        checkAllFieldsFilled();
    }
}
