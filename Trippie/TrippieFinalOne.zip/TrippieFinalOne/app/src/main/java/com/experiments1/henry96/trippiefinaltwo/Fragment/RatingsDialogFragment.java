package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.FirebaseFunctionsException;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;

public class RatingsDialogFragment extends DialogFragment {
    View view;
    private LinearLayout optionLayout;
    private RelativeLayout buttonHolder;
    private Button submitButton;
    private RadioGroup rgOptions;
    private User userToRate;
    private boolean isDriver;
    private MaterialRatingBar materialRatingBar;
    private String trippieId;

    private FirebaseFunctions mFunctions;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ratings_dialog, container, false);

        initialiseLayout();
        setListeners();
        return view;
    }

    RatingsDialogFragment(User userToRate, boolean isDriver, String trippieId) {
        this.userToRate = userToRate;
        this.isDriver = isDriver;
        this.trippieId = trippieId;
    }

    @Override
    public void onResume() {
        super.onResume();
        Window window = Objects.requireNonNull(getDialog()).getWindow();
        int width = (int) (260 * getResources().getDisplayMetrics().density);
        int height = (int)(450 * getResources().getDisplayMetrics().density);
        Objects.requireNonNull(window).setLayout(width,height);
    }

    private void initialiseLayout() {
        mFunctions = FirebaseFunctions.getInstance();
        optionLayout = view.findViewById(R.id.options_layout);
        buttonHolder = view.findViewById(R.id.button_holder);
        TextView userName = view.findViewById(R.id.tv_username);
        ImageView profilePhoto = view.findViewById(R.id.iv_profilepicture);
        submitButton = view.findViewById(R.id.btn_submit);
        rgOptions = view.findViewById(R.id.rg_options);
        materialRatingBar = view.findViewById(R.id.addRatingBar);

        materialRatingBar.setOnRatingChangeListener((ratingBar, rating) -> {
            if(isDriver) {
                optionLayout.setVisibility(rating < 5 && rating > 0.0 ? View.VISIBLE : View.GONE);
                if (optionLayout.getVisibility() == View.GONE) rgOptions.clearCheck();
            }
            setSubmitButtonEnabled(rating > 0.0 && (!isDriver || rating == 5 || rating < 5 && rgOptions.getCheckedRadioButtonId() != -1)); //only enable submit button if the rating is between 0.5 and 5, and if less than 5 there has to be an option selected
        });

        // load userToRate data
        userName.setText(String.format(getString(R.string.name_concatenation),userToRate.getFirstNm(),userToRate.getLastNm()));
        Picasso.get()
                .load(userToRate.getImage())
                .fit()
                .centerCrop()
                .into(profilePhoto);
    }

    private void setListeners() {
        submitButton.setOnClickListener(v -> {
            materialRatingBar.setEnabled(false);
            rgOptions.setEnabled(false);
            submitButton.setEnabled(false); submitButton.setText("");
            RelativeLayout loadingCircle = (RelativeLayout) getLayoutInflater().inflate(R.layout.loading_circle, buttonHolder,false);
            buttonHolder.addView(loadingCircle);

            int selectedComplaint = 0;
            switch(rgOptions.getCheckedRadioButtonId()){
                case R.id.first_option:  selectedComplaint = 1; break;
                case R.id.second_option: selectedComplaint = 2; break;
                case R.id.third_option:  selectedComplaint = 3; break;
                case R.id.fourth_option: selectedComplaint = 4; break;
            }

            updateRatings(materialRatingBar.getRating(), selectedComplaint);
        });

        rgOptions.setOnCheckedChangeListener((radioGroup, i) -> { if(i != -1)setSubmitButtonEnabled(true); });
    }

    private void setSubmitButtonEnabled(boolean enabled){
        submitButton.setEnabled(enabled);
        submitButton.setText(enabled ? R.string.submit_button_text : R.string.fill_all_fields);
        submitButton.setBackgroundResource(enabled ? R.drawable.custom_button_blue : R.drawable.custom_button_disabled);
    }

    private void updateRatings(double value, int selectedComplaint) {
        Map<String, Object> data = new HashMap<>();
        data.put("isDriver", isDriver);
        data.put("inputRating", value);
        data.put("userToRateId", userToRate.getUserId());
        data.put("selectedComplaint", selectedComplaint);
        data.put("trippieId", trippieId);

        mFunctions.getHttpsCallable("ratings").call(data).continueWith(task -> (String) Objects.requireNonNull(task.getResult()).getData()).addOnCompleteListener(task -> {
            if(!task.isSuccessful()){
                Exception e = task.getException();
                if (e instanceof FirebaseFunctionsException) {
                    FirebaseFunctionsException ffe = (FirebaseFunctionsException) e;
                    FirebaseFunctionsException.Code code = ffe.getCode();
                    Object details = ffe.getDetails();
                    Log.d("error", code + " " + details);
                }
            }
            else{
                Objects.requireNonNull(getActivity()).finish();
            }
        });
    }
}
