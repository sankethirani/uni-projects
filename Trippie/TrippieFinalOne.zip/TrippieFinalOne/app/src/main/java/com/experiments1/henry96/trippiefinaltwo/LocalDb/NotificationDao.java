package com.experiments1.henry96.trippiefinaltwo.LocalDb;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NotificationDao {

    @Insert
    public long addNotification(Notification note);

    @Update
    public void updateNotificatione(Notification note);

    @Delete
    public void deleteNotification(Notification note);

    @Query("Select * From notification_table order by notificationId desc")
    LiveData<List<Notification>> getAllNotifications();

    @Query("Select * From notification_table where notificationId=:notiId")
    Notification getNotificationById(Integer notiId);

}
