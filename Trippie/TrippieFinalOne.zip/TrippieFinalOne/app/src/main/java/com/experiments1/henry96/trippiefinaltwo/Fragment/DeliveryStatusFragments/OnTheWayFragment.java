package com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.R;


public class OnTheWayFragment extends Fragment implements View.OnClickListener {

    private final int resourceID = R.layout.fragment_on_the_way_status;
//    private TextView tvDestination;
    private Button btnOntheWay;
    private String deliveryLocation;
    private onTheWayFragmentClickListeners onTheWayFragmentClickListeners;


    public interface onTheWayFragmentClickListeners {
        public void onTheWayClick();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);
//        tvDestination = v.findViewById(R.id.tvDestination);
        btnOntheWay = v.findViewById(R.id.btnOnTheWay);
        btnOntheWay.setOnClickListener(this);
        if (getArguments() != null) {
            deliveryLocation = getArguments().getString("destinationLocation");
//            tvDestination.setText(String.format(getString(R.string.delivery_location_driver),deliveryLocation.replace(", New Zealand","")));
        }
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        onTheWayFragmentClickListeners = (OnTheWayFragment.onTheWayFragmentClickListeners) getActivity();


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnOnTheWay:
                onTheWayFragmentClickListeners.onTheWayClick();
                break;
        }
    }
}
