package com.experiments1.henry96.trippiefinaltwo.Helper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.room.TypeConverter;

import com.experiments1.henry96.trippiefinaltwo.Ui.EnterPhoneActivity;
import com.google.common.base.Strings;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class Helpers {


    // Show Toast
    public static void showToast(Context context, String msg) {
        Toast myToast = Toast.makeText(context, msg, Toast.LENGTH_SHORT);
        myToast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
        myToast.show();
    }


    // Return Resource Image ID
    public static int getResoureImageID(Context context, String imageName) {
        return context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
    }

    // Return Resource Name By ID
    public static String getResoureNameByID(Context context, int resourceID) {
        return context.getResources().getResourceEntryName(resourceID);
    }

    public static void setupUI(View view, final Activity activity) {

        // Set up touch listener for non-text box views to hide keyboard.
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    try {
                        hideSoftKeyboard(activity);
                    } catch (Exception ex) {
                        Log.e("Error_Keyboard", ex.getMessage());
                    }

                    return false;
                }
            });
        }

        //If a layout container, iterate over children and seed recursion.
        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView, activity);
            }
        }
    }

    public static Calendar getTime(String time) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
        try {
            cal.setTime(sdf.parse(time));// all done
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return cal;
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }

    public static String showTime(Calendar calendar, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);  // 12:25 PM
        return simpleDateFormat.format(calendar.getTime());
    }

    public static String showTime(Date date, String format) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);  // 12:25 PM
        return simpleDateFormat.format(date);
    }


    public static String getDatabasePath(String fileNname, Context context) {
        return context.getDatabasePath(fileNname).getAbsolutePath();
    }

    //encode Image
    public static byte[] encodeImage(ImageView imageView) {
        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache();
        Bitmap bitmap = imageView.getDrawingCache();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] data = baos.toByteArray();
        return data;
    }

    public static void showDialog(ProgressBar mprogressBar) {
        mprogressBar.setVisibility(View.VISIBLE);

    }

    public static void hideDialog(ProgressBar mprogressBar) {
        if (mprogressBar.getVisibility() == View.VISIBLE) {
            mprogressBar.setVisibility(View.INVISIBLE);
        }
    }

    public static void redirectLoginScreen(String TAG, Activity activity) {
        Log.d(TAG, "redirectLoginScreen: redirecting to login screen.");
        Intent intent = new Intent(activity, EnterPhoneActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();
    }

    public static String[] filenameExtensionSplitter(String filename) {
        String[] filenamePieces = filename.split("\\.");
        String extension = "." + filenamePieces[filenamePieces.length - 1];
        StringBuilder filenameStem = new StringBuilder();
        for (String filenamePiece : filenamePieces) {
            filenameStem.append(filenamePiece);
        }
        return new String[]{filenameStem.toString(), extension};
    }

    public static String addTrailingZerosToCurrency(Double price) {
        String priceString = Double.toString(price);
        String[] partsArray = priceString.split("\\.");
        int length = partsArray[1].length();
        priceString += Strings.repeat("0", length > 2 ? 0 : 2 - length); //if there are not two numbers after the decimal point, add 0s until there are
        return priceString;
    }

    @TypeConverter
    public static Calendar toCalendar(Long l) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(l);
        return c;
    }

    @TypeConverter
    public static Long fromCalendar(Calendar c) {
        return c == null ? null : c.getTime().getTime();
    }


    public static String Key_Trippie = "trippie";
    public static String Key_Job = "Job";
    public static String Key_Driver_Accept = "Driver";
    public static String Key_Job_Decline = "Job_Decline";
    public static String Key_Trippie_Refund = "Trippie_Refund";

    //    public_String
    public static String convertString(String str) {
        String temp = str.substring(0, 1).toUpperCase() + str.toLowerCase().substring(1);
        return temp.replace("_", " ");
    }

    public static String capitalizeFully(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        String[] words = str.split("\\s+");
        String capitaliseWord = "";
        for (String w : words) {
            if (w.length() > 1) {
                capitaliseWord += w.substring(0, 1).toUpperCase() + w.substring(1).toLowerCase() + " ";
            }
        }

        return capitaliseWord.trim();
    }

    public static Uri returnUriFromBitmap(Bitmap bitmap, String title) {
        File tempDir = Environment.getExternalStorageDirectory();
        tempDir = new File(tempDir.getAbsolutePath() + "/temp/");
        if (tempDir.exists() || tempDir.mkdir()) {
            File tempFile;
            try {
                tempFile = File.createTempFile(title, ".jpg", tempDir);

                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                byte[] bitmapData = bytes.toByteArray();

                //write the bytes in file
                FileOutputStream fos = new FileOutputStream(tempFile);
                fos.write(bitmapData);
                fos.flush();
                fos.close();
                return Uri.fromFile(tempFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static Bitmap decodeToBase64(String imageS) {
        byte[] decodedByte = Base64.decode(imageS, 0);
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }

}
