package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.app.Person;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.opengl.Visibility;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.PackageType;
import com.experiments1.henry96.trippiefinaltwo.Helper.PersonMeetingDriver;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;

import java.util.Objects;

import static android.app.Activity.RESULT_OK;
import static android.provider.DocumentsContract.EXTRA_INITIAL_URI;


public class CreateTrippieThirdStepFragment extends Fragment {

    private View v;
    private RelativeLayout vetClearanceLayout, vaccinationLayout;
    private RadioGroup rg;
    private LinearLayout someoneElseFields, signatureRequiredFields;
    private EditText someoneElseName, someoneElseNumber, vetClearanceText, vaccinationText;
    private TextView signatureText, signatureHiddenText;
    private CreateTrippieFourthStepFragment fourthStepFragment;
    private int imageRequestHolder;
    private static final int PICK_VET_IMAGE_REQUEST = 1377;
    private Uri imageUri;
    private RadioButton nobodyButton, meButton;
    private Button nextButton;
    private CheckBox signatureCheckBox;

    public CreateTrippieThirdStepFragment(CreateTrippieFourthStepFragment fourthStepFragment){
        this.fourthStepFragment = fourthStepFragment;
    }

    void relistTrippieAfterLayoutInitialised(Trippie trippie) {
        if(trippie.getMeetingDriverDelivery() == PersonMeetingDriver.Someone_else.getNumericType()){
            ((RadioButton)v.findViewById(R.id.someone_else_radio_button)).setChecked(true);
            someoneElseName.setText(trippie.getPersonMeetingDeliveryName());
            someoneElseNumber.setText(trippie.getPersonMeetingDeliveryPhone());
        }
        else ((RadioButton)v.findViewById(trippie.getMeetingDriverDelivery() == PersonMeetingDriver.Nobody.getNumericType() ? R.id.nobody_button : R.id.someone_else_radio_button)).setChecked(true);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_create_trippie_third_step, container, false);
        initialiseLayout();
        initialiseOnClicks();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).setViewCreated(2);
    }

    private void initialiseLayout(){
        vetClearanceLayout = v.findViewById(R.id.vet_clearance_upload_layout);
        vaccinationLayout = v.findViewById(R.id.vaccination_upload_layout);
        rg = v.findViewById(R.id.meeting_driver_delivery_group);
        meButton = v.findViewById(R.id.me_delivery_button);
        someoneElseFields = v.findViewById(R.id.someone_else_delivery_fields);
        someoneElseName = v.findViewById(R.id.someone_else_name_delivery_text);
        someoneElseNumber = v.findViewById(R.id.someone_else_number_delivery);
        vetClearanceText = v.findViewById(R.id.vet_clearance_image);
        vaccinationText = v.findViewById(R.id.vaccination_image);
        nextButton = v.findViewById(R.id.create_trippie_third_page_next_button);
        nobodyButton = v.findViewById(R.id.nobody_button);
        signatureCheckBox = v.findViewById(R.id.signature_required_checkbox);
        signatureRequiredFields = v.findViewById(R.id.signature_required_fields);
        signatureText = v.findViewById(R.id.signature_text);
        signatureHiddenText = v.findViewById(R.id.signature_checkbox_hidden);
    }

    private void initialiseOnClicks(){
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void afterTextChanged(Editable editable) { checkAllFieldsFilled(); }
        };
        someoneElseName.addTextChangedListener(tw);
        someoneElseNumber.addTextChangedListener(tw);
        rg.setOnCheckedChangeListener((radioGroup, i) -> {
            boolean someoneElseChecked = radioGroup.getCheckedRadioButtonId() == R.id.someone_else_radio_button;
            someoneElseFields.setVisibility(someoneElseChecked ? View.VISIBLE : View.GONE);
            hideAndShowSignatureCheckBox(rg.getCheckedRadioButtonId() != nobodyButton.getId());
            checkAllFieldsFilled();
        });
        vetClearanceText.setOnClickListener(c -> openFileChooser());
        vaccinationText.setOnClickListener(c -> openFileChooser());
        nextButton.setOnClickListener(c -> ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(3,true));
    }

    private void hideAndShowSignatureCheckBox(boolean showCheckBox){
        signatureRequiredFields.setVisibility(setVisible(showCheckBox));
        signatureText.setVisibility(setVisible(showCheckBox));
        if(signatureRequiredFields.getVisibility() == View.GONE) signatureCheckBox.setChecked(false);
    }

    private int setVisible(boolean visible){
        return visible ? View.VISIBLE : View.GONE;
    }

    private void toggleSignatureCheckBox(boolean setEnabled, PackageType packageType){
        if(setEnabled){
            fourthStepFragment.signatureRequiredPackageType(false,packageType);
            signatureCheckBox.setEnabled(true);
            signatureCheckBox.setChecked(false);
            signatureCheckBox.setOnCheckedChangeListener((compoundButton, b) ->{
                fourthStepFragment.signatureRequiredPackageType(b,packageType);
                if (isAdded() && isVisible() && isResumed()) { fourthStepFragment.getTrippie().setSignatureRequired(signatureCheckBox.isChecked()); fourthStepFragment.prepareTrippie(); } //if value is changed while fragment is on screen then update details page
            });
        }
        else{
            signatureCheckBox.setOnCheckedChangeListener(null);
            fourthStepFragment.signatureRequiredPackageType(false,packageType);
            if (isAdded() && isVisible() && isResumed()) { fourthStepFragment.prepareTrippie(); } //if value is changed while fragment is on screen then update details page
            signatureCheckBox.setChecked(true);
            signatureCheckBox.setEnabled(false);
        }
        signatureHiddenText.setVisibility(setVisible(!setEnabled));
        signatureCheckBox.setVisibility(setVisible(setEnabled));
        signatureCheckBox.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(Objects.requireNonNull(getContext()), signatureCheckBox.isEnabled() ? R.color.main_colour_blue : R.color.text_colour_grey)));
    }

    void setPackageType(PackageType packageType){

        switch (packageType){
            case Item:
                toggleSignatureCheckBox(true,packageType);
                vetClearanceLayout.setVisibility(View.GONE);
                vaccinationLayout.setVisibility(View.GONE);
                break;
            case Pet:
                toggleSignatureCheckBox(false,packageType);
                vetClearanceLayout.setVisibility(View.GONE);
                vaccinationLayout.setVisibility(View.VISIBLE);
                break;
            case Livestock:
                toggleSignatureCheckBox(false,packageType);
                vetClearanceLayout.setVisibility(View.VISIBLE);
                vaccinationLayout.setVisibility(View.GONE);
                break;
        }

        if(!meButton.isChecked()) {meButton.setChecked(true);}
        nobodyButton.setVisibility(packageType == PackageType.Item ? View.VISIBLE : View.GONE);
        fourthStepFragment.getTrippie().setCategory(packageType.name());
        fourthStepFragment.getTrippie().setSignatureRequired(signatureCheckBox.isChecked());
    }

    void setAnimalString(String animalString){
        if(animalString.matches("Dog|Cat|Rabbit")) vaccinationLayout.setVisibility(View.VISIBLE);
        else vaccinationLayout.setVisibility(View.GONE);
    }

    public void checkAllFieldsFilled(){
        boolean isFilled = true;
        if(someoneElseFields.getVisibility() == View.VISIBLE){
            if (someoneElseName.getText().toString().isEmpty() || someoneElseNumber.getText().toString().isEmpty() || someoneElseNumber.getText().toString().length() < 9) isFilled = false;
        }
        if(vetClearanceLayout.getVisibility() == View.VISIBLE) {
            if (vetClearanceText.getText().toString().isEmpty()) isFilled = false;
        }
        else if(vaccinationLayout.getVisibility() == View.VISIBLE){
            if(vaccinationText.getText().toString().isEmpty()) isFilled = false;
        }

        nextButton.setEnabled(isFilled);

        if(!isFilled) {
            nextButton.setText(R.string.fill_all_fields);
            nextButton.setBackgroundResource(R.drawable.custom_button_disabled);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).disableTabs(3);
        } else {
            if(vetClearanceLayout.getVisibility() == View.VISIBLE || vaccinationLayout.getVisibility() == View.VISIBLE)  fourthStepFragment.setSupplementaryImageFilepath(imageUri);

            if(meButton.isChecked()) fourthStepFragment.getTrippie().setMeetingDriverDelivery(PersonMeetingDriver.Me.getNumericType());
            else if(someoneElseFields.getVisibility() == View.VISIBLE){
                fourthStepFragment.getTrippie().setMeetingDriverDelivery(PersonMeetingDriver.Someone_else.getNumericType());
                fourthStepFragment.getTrippie().setPersonMeetingDeliveryName(someoneElseName.getText().toString());
                fourthStepFragment.getTrippie().setPersonMeetingDeliveryPhone(someoneElseNumber.getText().toString());
            }
            else fourthStepFragment.getTrippie().setMeetingDriverDelivery(PersonMeetingDriver.Nobody.getNumericType());

            nextButton.setText(R.string.next_button_text);
            nextButton.setBackgroundResource(R.drawable.custom_button_blue);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(3,false);
        }
    }

    private void openFileChooser() {
        imageRequestHolder = PICK_VET_IMAGE_REQUEST;
        Intent imageSelectIntent = new Intent();
        imageSelectIntent.setType("image/*");
        imageSelectIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { //if we're on API 26 or higher
            imageSelectIntent.putExtra(EXTRA_INITIAL_URI, "/storage/emulated/0/"); //place user in /storage/emulated/0/ by default
        }
        imageSelectIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        startActivityForResult(imageSelectIntent, PICK_VET_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == imageRequestHolder && resultCode == RESULT_OK
                && data != null && data.getData() != null) {

            if (requestCode == PICK_VET_IMAGE_REQUEST) {
                imageUri = data.getData();
                if (vetClearanceLayout.getVisibility() == View.VISIBLE) vetClearanceText.setText(imageUri.getLastPathSegment());
                else vaccinationText.setText(imageUri.getLastPathSegment());
                checkAllFieldsFilled();
            }
        }
    }
}
