package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.AlertDialog;
import android.graphics.Point;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.experiments1.henry96.trippiefinaltwo.Adapter.CreateTrippieFragmentAdapter;
import com.experiments1.henry96.trippiefinaltwo.Fragment.CreateTrippieFirstStepFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.CreateTrippieFourthStepFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.CreateTrippieSecondStepFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.CreateTrippieThirdStepFragment;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;

public class CreateTrippieActivity extends AppCompatActivity {
    public CreateTrippieFragmentAdapter adapter;
    private ViewPager mViewPager;
    LinearLayout tabs;
    private boolean[] toggles, viewCreated;
    private CreateTrippieFirstStepFragment firstPage;
    private CreateTrippieSecondStepFragment secondPage;
    private Trippie trippie;
    private boolean isRelist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_trippie_new);

        isRelist = getIntent().getBooleanExtra("reList", false);

        if(isRelist){
            Gson gson = new Gson();
            trippie = gson.fromJson(getIntent().getStringExtra("trippie"),Trippie.class);
        }

        mViewPager = findViewById(R.id.pager);
        mViewPager.setOffscreenPageLimit(5);

        TabLayout tabLayout = findViewById(R.id.tabDots);
        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        tabLayout.setupWithViewPager(mViewPager, true);
        tabLayout.setTabRippleColor(null);

        CreateTrippieFourthStepFragment fourthPage = new CreateTrippieFourthStepFragment();
        CreateTrippieThirdStepFragment thirdPage = new CreateTrippieThirdStepFragment(fourthPage);
        secondPage = new CreateTrippieSecondStepFragment(fourthPage);
        firstPage = new CreateTrippieFirstStepFragment(secondPage,thirdPage,fourthPage);
        if(isRelist) fourthPage.setThumbnailLocationForRelist(trippie.getThumbnailUrl());

        adapter = new CreateTrippieFragmentAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adapter.add(firstPage);
        adapter.add(secondPage);
        adapter.add(thirdPage);
        adapter.add(fourthPage);

        mViewPager.setAdapter(adapter);
        tabs = ((LinearLayout)tabLayout.getChildAt(0));
        viewCreated = new boolean[tabs.getChildCount()];
        toggles = new boolean[tabs.getChildCount()];
        toggles[0] = true;
        for(int i = 1; i < tabs.getChildCount(); i++){
            tabs.getChildAt(i).setClickable(false);
            toggles[i] = false;
        }
        mViewPager.getLayoutParams().height = size.y - tabLayout.getMinimumHeight();

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) { }
            @Override public void onPageScrollStateChanged(int state) { }
            @Override
            public void onPageSelected(int position) {
                if (!toggles[position]) mViewPager.setCurrentItem(position - 1, true);
                else if (position == 2) {thirdPage.checkAllFieldsFilled(); fourthPage.prepareTrippie();} //TODO: remove this line when all fields are able to automatically update the details page
            }
        });

    }

    public void setViewCreated(int position){
        viewCreated[position] = true;
        boolean allViewsCreated = true;
        for(boolean b : viewCreated) if(!b) allViewsCreated = false;
        if(allViewsCreated && isRelist){
            firstPage.relistTrippieAfterLayoutInitialised(trippie);
        }
    }

    public void enableTab(int position, boolean changeTab){
        toggles[position] = true;
        if(changeTab) mViewPager.setCurrentItem(position);
        tabs.getChildAt(position).setClickable(true);
    }

    public void disableTabs(int position){
        toggles[position] = false;
        tabs.getChildAt(position).setClickable(false);
    }

    @Override
    public void onBackPressed(){
        if(firstPage.containsData()) new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert).setTitle("Quit creating Trippie?")
                .setMessage("Are you sure you want to return to the home page? Your Trippie creation progress will be lost.")
                .setPositiveButton("Yes", (dialogInterface, i) -> finish())
                .setNegativeButton("No", (dialogInterface, i) -> dialogInterface.dismiss())
                .create()
                .show();
        else finish();
    }
}