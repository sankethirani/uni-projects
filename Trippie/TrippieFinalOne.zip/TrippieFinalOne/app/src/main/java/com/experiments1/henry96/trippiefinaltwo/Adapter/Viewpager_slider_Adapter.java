package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.experiments1.henry96.trippiefinaltwo.Helper.Slider;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Objects;

public class Viewpager_slider_Adapter extends PagerAdapter {
    private Context context;
    private ArrayList<Slider> items;
    private boolean isPreview;

    public Viewpager_slider_Adapter(Context context, ArrayList<Slider> sliders) {
        this.context = context;
        this.items = sliders;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = Objects.requireNonNull(inflater).inflate(R.layout.custom_viewpage_item, container, false);

        //set items in view
        Slider sldCurrent = items.get(position);

        ImageView img = v.findViewById(R.id.imgview);

        if(!isPreview) {
            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference sr = storage.getReference();
            Log.e("PictureName", sldCurrent.getPicture());
            sr.child("images/trippies/" + sldCurrent.getPicture()).getDownloadUrl().addOnSuccessListener(uri -> {
                Picasso.get()
                        .load(uri)
                        .fit()
                        .centerCrop()
                        .into(img, new Callback() {
                            @Override
                            public void onSuccess() { ((ShimmerFrameLayout) ((ViewGroup)container.getParent()).findViewById(R.id.slider_shimmer_layout)).hideShimmer();}

                            @Override public void onError(Exception e) {}
                        });

            });
        }
        else{
            ((ShimmerFrameLayout) ((ViewGroup)container.getParent()).findViewById(R.id.slider_shimmer_layout)).hideShimmer();
            Picasso.get().load(sldCurrent.getPicture()).fit().centerCrop().into(img);
        }


        container.addView(v);
        return v;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return (view == object);
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    public void setIsPreview(boolean isPreview) {
        this.isPreview = isPreview;
    }
}
