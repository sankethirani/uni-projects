package com.experiments1.henry96.trippiefinaltwo.Model;

import android.content.Intent;

public class UserOfferDetail {

    private Double offerPrice;
    private int offerCount;

    public UserOfferDetail(Double offerPrice, int offerCount) {
        this.offerPrice = offerPrice;
        this.offerCount = offerCount;
    }

    public UserOfferDetail() {
    }

    public Double getOfferPrice() {
        return offerPrice;
    }

    public void setOfferPrice(Double offerPrice) {
        this.offerPrice = offerPrice;
    }

    public int getOfferCount() {
        return offerCount;
    }

    public void setOfferCount(int offerCount) {
        this.offerCount = offerCount;
    }
}
