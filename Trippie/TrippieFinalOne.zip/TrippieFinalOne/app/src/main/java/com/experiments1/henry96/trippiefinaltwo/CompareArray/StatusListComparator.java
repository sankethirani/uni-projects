package com.experiments1.henry96.trippiefinaltwo.CompareArray;

import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;

import java.util.Comparator;

public class StatusListComparator implements Comparator<StatusDetail> {
    @Override
    public int compare(StatusDetail o1, StatusDetail o2) {
        return o1.getPosition() - o2.getPosition();
    }
}
