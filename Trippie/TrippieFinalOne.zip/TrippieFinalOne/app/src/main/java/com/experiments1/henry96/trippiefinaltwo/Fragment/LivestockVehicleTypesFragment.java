package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.R;


public class LivestockVehicleTypesFragment extends Fragment implements VehicleInterface{

    private CreateTrippieFirstStepFragment originalFragment;
    private View v;
    private RadioGroup rg;
    private int sizeFee, litresPerHundredKm, animalQuantity;
    private RadioButton[] buttons;
    private boolean isRelist = false;
    private String size, animalString;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_livestock_vehicle_types, container, false);
        initialiseLayout();
        initialiseOnClicks();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(isRelist){
            switch(size){
                case "Stock Truck"  : buttons[0].performClick(); break;
                case "Large Trailer": buttons[1].performClick(); break;
                case "Trailer"      : buttons[2].performClick(); break;
                case "Pickup Truck" : buttons[3].performClick(); break;
            }
            setAnimalQuantity(animalString, animalQuantity);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        View x = ((View)v.getParent());

        x.setTag(x.getVisibility());
        x.getViewTreeObserver().addOnGlobalLayoutListener(() -> { //fixes an issue where not selecting a vehicle, then changing to horse and back will keep the next page button enabled
            int newVis = x.getVisibility();
            if((int) x.getTag() != newVis){
                x.setTag(x.getVisibility());
                if(x.getVisibility() == View.VISIBLE) {
                    if (rg.getCheckedRadioButtonId() == -1) reinitialiseMainLayout();
                    else findVehicleSpecs(rg,rg.getCheckedRadioButtonId());
                }
            }
        });
    }

    private void initialiseLayout(){
        rg = v.findViewById(R.id.livestock_size_radio_group);
        buttons = new RadioButton[] {v.findViewById(R.id.stock_truck_button),v.findViewById(R.id.large_trailer_button),v.findViewById(R.id.trailer_button),v.findViewById(R.id.pick_up_truck_button)};
    }

    private void initialiseOnClicks(){
        rg.setOnCheckedChangeListener((radioGroup, i) -> { if(i != -1) findVehicleSpecs(radioGroup,i); });
    }

    private void reinitialiseMainLayout(){
        originalFragment.setNextPageButtonEnabled(false);
        originalFragment.setVehicleSpecs(0,0,"",true);
    }

    private void findVehicleSpecs(RadioGroup radioGroup, int checkedId){
        String sizeString = ((RadioButton)radioGroup.findViewById(checkedId)).getText().toString();
        switch(sizeString){
            case "Stock Truck"  : sizeFee = 200; litresPerHundredKm = 18; break;
            case "Large Trailer": sizeFee =  50; litresPerHundredKm = 12; break;
            case "Trailer"      : sizeFee =  30; litresPerHundredKm = 11; break;
            case "Pickup Truck" : sizeFee =  20; litresPerHundredKm = 10; break;
        }
        originalFragment.setVehicleSpecs(sizeFee,litresPerHundredKm,sizeString,true);
    }

    LivestockVehicleTypesFragment(CreateTrippieFirstStepFragment originalFragment){
        this.originalFragment = originalFragment;
    }

    public int setAnimalQuantity(String animalString, int animalQuantity){
        int[] quantityArray = new int[]{0,0,0,0};
        switch(animalString){
            case "Sheep"             : quantityArray = new int[]{50,10,6,5}; break;
            case "Goat":  case "Calf": quantityArray = new int[]{45, 5,3,3}; break;
            case "Cattle"            : quantityArray = new int[]{19, 2,1,1}; break;
        }
        for(int i = 3; i >= 0; i--){
            if(animalQuantity > quantityArray[i]){
                buttons[i].setVisibility(View.GONE);
                if(buttons[i].isChecked()) rg.clearCheck();
                if(rg.getCheckedRadioButtonId() == -1) reinitialiseMainLayout();
                if(i == 0) return quantityArray[0];
            }
            else{
                buttons[i].setVisibility(View.VISIBLE);
            }
        }
        return -1;
    }

    public void setRelistVehicleSize(String size){
        this.isRelist = true;
        this.size = size;
    }

    public void setRelistAnimalQuantity(String animalString, int animalQuantity){
        this.animalString = animalString;
        this.animalQuantity = animalQuantity;
    }
}