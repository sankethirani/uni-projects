package com.experiments1.henry96.trippiefinaltwo.NotificationService;

import android.util.Log;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.LocalDb.Notification;
import com.experiments1.henry96.trippiefinaltwo.LocalDb.Repository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Calendar;
import java.util.Objects;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMessagingServ";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        if (remoteMessage.getNotification() != null) {
            String title = remoteMessage.getNotification().getTitle();
            String body = remoteMessage.getNotification().getBody();


            String trippieid_type_tname = remoteMessage.getData().get("trippieid_type_tname");
            String imageurl_driverid = remoteMessage.getData().get("imageurl_driverid");

            String[] listinfo = trippieid_type_tname.split("-@-");
            String[] listinfo2 = imageurl_driverid.split("-@-");


            String data = listinfo[0]; //trippieiD
            String data1 = listinfo[1]; //type
            String data2 = listinfo2[0]; //imageurl
            String data3 = listinfo[2]; //trippie name
            String data4 = listinfo2[1]; //driverid


            Calendar today = Calendar.getInstance();

            Notification notification = new Notification(data1, title, body, Helpers.fromCalendar(today), data, data2, data3);
            Repository repository = new Repository(getApplication());
            long id = repository.insertNote(notification);


            NotificationHelper.displayNotification(getApplicationContext(), title, body, data, data1, id, data4);


        }
    }

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        Log.d("NEW_TOKEN", s);
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            DocumentReference userref = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()));
            userref.update("token", s);
        } catch (Exception ex) {
//            Log.e(TAG, ex.getMessage());
        }

    }
}
