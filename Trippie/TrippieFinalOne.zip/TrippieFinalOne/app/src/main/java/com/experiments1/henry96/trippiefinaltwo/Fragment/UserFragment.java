package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.DriverRegistrationActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.EditUserActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.EnterPhoneActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.LicenceDetailsActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.VehicleDetailsActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ViewDocumentActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;


public class UserFragment extends Fragment implements View.OnClickListener {
    private static final String TAG = "UserFragment";
    private static final int REQUEST_CODE_EDIT_USER_INFO = 101;

    private Button btnLogout;
    private LinearLayout linearInformation, linearLicense, linearVehicleInfo, linearResetpassword, linearDriverRegister, linearAboutTrippie;
    private Activity activity;
    private TextView tvName;
    private MaterialRatingBar tvUserRating, tvDriverRating;
    private ImageView imgProfile;
    private ProgressBar progressBar;

    private FirebaseFirestore db;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_user, container, false);
        init(v);
        initListener();
        return v;

    }

    private void init(View v) {
        btnLogout = v.findViewById(R.id.btnlogout);
        linearInformation = v.findViewById(R.id.linearUserinfo);
        linearLicense = v.findViewById(R.id.linearLicenseinfo);
        linearVehicleInfo = v.findViewById(R.id.linearVehicleinfo);
        linearResetpassword = v.findViewById(R.id.linearResetPassword);
        linearDriverRegister = v.findViewById(R.id.linearDriverinfo);
        linearAboutTrippie = v.findViewById(R.id.linearAboutTrippie);
        tvName = v.findViewById(R.id.tvName);
        tvUserRating = v.findViewById(R.id.userRatingStars);
        tvDriverRating = v.findViewById(R.id.driverRatingStars);
        imgProfile = v.findViewById(R.id.iv_profilepicture);
        progressBar = v.findViewById(R.id.progressBar);

    }

    private void initListener() {
        btnLogout.setOnClickListener(this);
        linearInformation.setOnClickListener(this);
        linearLicense.setOnClickListener(this);
        linearVehicleInfo.setOnClickListener(this);
        linearResetpassword.setOnClickListener(this);
        linearDriverRegister.setOnClickListener(this);
        linearAboutTrippie.setOnClickListener(this);
    }

    private void signOut() {
        FirebaseAuth.getInstance().signOut();
        //SKH change the Intent to take the user to the enter phone number screen when the user logs out
        Intent LoginIntent = new Intent(getActivity(), EnterPhoneActivity.class);
        LoginIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(LoginIntent);
        Objects.requireNonNull(getActivity()).finish();
    }

    private void getUserDetail() {
        Helpers.showDialog(progressBar);
        DocumentReference docRef = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        docRef.get().addOnSuccessListener(documentSnapshot -> {

            User user = documentSnapshot.toObject(User.class);
            if(user!=null && user.isDriver()){
                tvDriverRating.setVisibility(View.VISIBLE);
                db.collection("drivers").document(user.getUserId()).get().addOnSuccessListener(snapshot ->
                        tvDriverRating.setRating(Objects.requireNonNull(snapshot.getDouble("rating")).floatValue()));
            }
            tvUserRating.setRating((float)Objects.requireNonNull(user).getRating());
            tvName.setText(String.format(getString(R.string.name_concatenation),user.getFirstNm(),user.getLastNm()));
            Picasso.get()
                    .load(user.getImage())
                    .placeholder(R.drawable.null_image)
                    .fit()
                    .centerCrop()
                    .into(imgProfile);
            Helpers.hideDialog(progressBar);
            linearDriverRegister.setEnabled(true);

            int visibility = !user.isDriver() ? View.GONE : View.VISIBLE;
            linearLicense.setVisibility(visibility);
            linearVehicleInfo.setVisibility(visibility);
            linearDriverRegister.setVisibility(View.VISIBLE); //TODO: change input to be "!visibility" once testing is done
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        db = FirebaseFirestore.getInstance();
        getUserDetail();

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        activity = getActivity();
    }

    private void showEditUserInfo() {
        Intent userInfo = new Intent(activity, EditUserActivity.class);
        activity.startActivityForResult(userInfo, REQUEST_CODE_EDIT_USER_INFO);
    }

    private void showDriverRegistration() {
        Intent intent = new Intent(activity, DriverRegistrationActivity.class);
        startActivity(intent);
    }

    private void showVehicles() {
        Intent intent = new Intent(activity, VehicleDetailsActivity.class);
        startActivity(intent);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        getUserDetail();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnlogout:
                signOut();
                break;
            case R.id.linearUserinfo:
                showEditUserInfo();
                break;
            case R.id.linearDriverinfo:
                showDriverRegistration();
                break;
            case R.id.linearLicenseinfo:
                Intent intent = new Intent(activity, LicenceDetailsActivity.class);
                startActivity(intent);
                break;
            case R.id.linearVehicleinfo:
                showVehicles();
                break;
            case R.id.linearAboutTrippie:
                Intent aboutTrippieIntent = new Intent(getContext(), ViewDocumentActivity.class);
                aboutTrippieIntent.putExtra("Title","About");
                startActivity(aboutTrippieIntent);
                break;
        }
    }
}
