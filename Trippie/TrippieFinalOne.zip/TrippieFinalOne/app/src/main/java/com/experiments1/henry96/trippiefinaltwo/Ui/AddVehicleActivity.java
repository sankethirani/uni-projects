package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment.VehicleDetailsFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.GetPhotoUriFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.Model.Vehicle;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import static com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment.VehicleDetailsFragment.*;


public class AddVehicleActivity extends AppCompatActivity implements GetPhotoUriFragment.PhotoDialogListener {

    private EditText etRegistration, etYear, etRegistrationImg, etInsuranceImg, etInsuranceExpiryDate;
    private Spinner etBodyType, etInsuranceType;
    private AutoCompleteTextView etMake, etModel, etColour;
    private CheckBox chkSmokeFree, chkHasAgreed;
    private Button btnSubmit;
    private Uri imageUri;
    private GetPhotoUriFragment dialog;
    private EditText[] fields;
    private Map<String, Uri> uriMap;
    private ProgressBar progressBar;
    Map<String, Vehicle> originalVehicleList;
    private List<VehicleList.VehicleData> vehicleDataList;
    private Date insuranceExpiryDate;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private String userId;
    private Vehicle vehicle;
    private Driver driver;
    private int numberOfAsyncTasks;
    @Override

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_driver_registration_vehicle);

        firebaseAuth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        db = FirebaseFirestore.getInstance();
        setUserId();

        dialog = new GetPhotoUriFragment();
        dialog.isActivity = true;
        initialiseLayout();
        setOnClickListeners();
        uriMap = new HashMap<>();
        vehicle = new Vehicle();


    }

    public void initialiseLayout() {

        chkSmokeFree = findViewById(R.id.chk_smore_free);
        chkHasAgreed = findViewById(R.id.chk_has_agreed);
        chkHasAgreed.setVisibility(View.GONE);

        etRegistration = findViewById(R.id.et_registration_no);
        etBodyType = findViewById(R.id.et_body_type);
        etMake = findViewById(R.id.et_make);
        etModel = findViewById(R.id.et_model);
        etYear = findViewById(R.id.et_year);
        etColour = findViewById(R.id.et_colour);
        etInsuranceType = findViewById(R.id.et_insurance_type);
        etInsuranceImg = findViewById(R.id.et_insurance_img);
        etRegistrationImg = findViewById(R.id.et_registration_img);
        etInsuranceExpiryDate = findViewById(R.id.insurance_expiry_date);

        // string lists for spinner and autocomplete textview adapters
        String[] bodyTypeList = getResources().getStringArray(R.array.body_type);
        String[] insuranceTypeList = getResources().getStringArray(R.array.insurance_type);
        String[] colourList = getResources().getStringArray(R.array.colours);

        // set spinner and string adapters
        etColour.setAdapter(createStringAdapter(this, colourList));
        etBodyType.setAdapter(createSpinnerAdapter(this, bodyTypeList));
        etInsuranceType.setAdapter(createSpinnerAdapter(this, insuranceTypeList));

        btnSubmit = findViewById(R.id.btn_submit);
        btnSubmit.setEnabled(false);
        progressBar = findViewById(R.id.progressBar);

        // array of fields
        fields = new EditText[] {
                etRegistration, etMake, etModel, etYear, etColour, etInsuranceExpiryDate
        };

        // get the driver document while the user is filling up the fields
        DocumentReference driverRef = db.collection("drivers").document(userId);
        driverRef.get().addOnSuccessListener(documentSnapshot -> {
            driver = documentSnapshot.toObject(Driver.class);
            originalVehicleList = driver.getVehicleList();
        });
    }



    private void setOnClickListeners() {
        chkSmokeFree.setOnClickListener(c -> {
            if(!chkSmokeFree.isChecked()) {
                Helpers.showToast(getApplicationContext(), "A vehicle must be smoke-free.");
            }
        });

        btnSubmit.setOnClickListener(view1 -> {
            if(chkSmokeFree.isChecked()) {
                Helpers.showDialog(progressBar);
                uploadPhoto();
            } else {
                Helpers.showToast(this,"Your vehicle must be smoke-free.");
            }
        });

        etRegistrationImg.setOnClickListener(view -> {
            dialog.viewId = R.id.et_registration_img;
            dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etInsuranceImg.setOnClickListener(view -> {
            dialog.viewId = R.id.et_insurance_img;
            dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etBodyType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLACK);
                }
                setVehicleDataListByBodyType(etBodyType.getSelectedItem().toString());
                checkFields();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        etMake.setOnItemClickListener((parent, view, position, id) -> {

            etModel.setAdapter(createStringAdapter(getApplicationContext(), getVehicleDataListByType("model")));
            etModel.setEnabled(true);
        });


        etInsuranceType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLACK);
                }
                checkFields();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        etYear.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus && !etYear.getText().toString().isEmpty()) {
                int year = Integer.parseInt(etYear.getText().toString());
                // check if vehicle year is less than 1950 or is more than 2 years than the current year.
                int maximumYear = Calendar.getInstance().get(Calendar.YEAR) + 2;
                if((year < 1980) || (year  > maximumYear)) {
                    etYear.setError("Year must be between 1980 and " + maximumYear + ".");
                }
            }
        });

        etRegistration.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus && !etRegistration.getText().toString().isEmpty()) {
                // minimum length of licence number should be 2
                if(etRegistration.getText().toString().length() < 2)
                    etRegistration.setError("The minimum character is 2.");
            }
        });

        etInsuranceExpiryDate.setOnClickListener(c -> setDate((EditText) c));

        TextWatcher tw = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void afterTextChanged(Editable editable) {
                checkFields();
            }

        };

        for (EditText et : fields) {
            et.addTextChangedListener(tw);
        }
    }

    private void setDate(EditText et) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(Objects.requireNonNull(this), createOnDateListener(et), year, month, day);
        dialog.show();
    }

    // create new OnDateSetListener by supplying the text view you want to set
    private DatePickerDialog.OnDateSetListener createOnDateListener(EditText et) {


        return (DatePicker datePicker, int year, int month, int day) -> {
            String date = day + "/" + (month + 1) + "/" + year;


            // derive date from calendar data
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(year, month, day);
            Date selectedDate = selectedCalendar.getTime();

            // current calendar
            Calendar nowCalendar = Calendar.getInstance();
            nowCalendar.setTime(Calendar.getInstance().getTime());

            if (et == etInsuranceExpiryDate) {
                if (selectedDate.after(Calendar.getInstance().getTime())) {
                    insuranceExpiryDate = selectedDate;
                    et.setText(date);
                } else {
                    Helpers.showToast(this, "Invalid issue date. Cannot be a past date.");
                    et.setText("");
                }
            }
        };
    }


    @Override
    public void getImagePath(Uri imagePath, int id) {
        imageUri = imagePath;
        String title = imagePath.getLastPathSegment();
        switch (id) {
            case R.id.et_registration_img:
                uriMap.put("registration", imagePath);
                etRegistrationImg.setText(title);
                break;
            case R.id.et_insurance_img:
                uriMap.put("insurance", imagePath);
                etInsuranceImg.setText(title);
                break;
        }
        checkFields();
    }

    private void checkFields() {
        boolean isFilled = true;

        if(uriMap.size() < 2) {
            isFilled = false;
        }
        if (etBodyType.getSelectedItemPosition() == 0) {
            isFilled = false;
        }

        if (etInsuranceType.getSelectedItemPosition() == 0) {
            isFilled = false;
        }

        for(EditText et: fields) {
            if(et.getText().toString().isEmpty()) {
                isFilled = false;
                break;
            }
        }

        if(etYear.getError() != null || etYear.getText().toString().length() != 4){
            isFilled = false;
        }
        if(etRegistration.getError() != null || etRegistration.getText().toString().length() < 2){
            isFilled = false;
        }

        if(isFilled) {
            btnSubmit.setBackgroundResource(R.drawable.custom_button_blue);
            btnSubmit.setEnabled(true);
            btnSubmit.setText("Submit");
            updateVehicleDetails();
        } else {
            btnSubmit.setBackgroundResource(R.drawable.custom_button_disabled);
            btnSubmit.setEnabled(false);
            btnSubmit.setText(R.string.fill_all_fields);
        }
    }

    private void updateVehicleDetails() {

        vehicle.setRegistrationNo(etRegistration.getText().toString());
        vehicle.setBodyType(etBodyType.getSelectedItem().toString());
        vehicle.setMake(etMake.getText().toString());
        vehicle.setModel(etModel.getText().toString());
        vehicle.setYear(Integer.parseInt(etYear.getText().toString()));
        vehicle.setColour(etColour.getText().toString());
        vehicle.setInsuranceType(etInsuranceType.getSelectedItem().toString());
        vehicle.setSmokeFree(chkSmokeFree.isChecked());
        vehicle.setInsuranceExpiryDate(insuranceExpiryDate);
    }

    private void uploadPhoto() {
        StorageReference storageRef = storage.getReference();
        numberOfAsyncTasks = uriMap.size();

        for(Map.Entry<String, Uri> entry : uriMap.entrySet()) {
            String key = entry.getKey();
            Uri uri = entry.getValue();

            final StorageReference imageRef;
            imageRef = storageRef.child("images/drivers/" + userId + "/vehicles/" + vehicle.getRegistrationNo() + "/" + key);

            UploadTask uploadTask = imageRef.putFile(uri);
            uploadTask.addOnSuccessListener(taskSnapshot -> {
                numberOfAsyncTasks--;
                if (numberOfAsyncTasks == 0) {
                    uploadVehicle();
                }
            });
        }
    }

    private void setUserId() {
        userId = firebaseAuth.getCurrentUser().getUid();
    }

    private void uploadVehicle() {

        DocumentReference driverRef = db.collection("drivers").document(userId);

        // set creation date for vehicle
        vehicle.setCreationDate(Calendar.getInstance().getTime());

        originalVehicleList = driver.getVehicleList();
        originalVehicleList.put(vehicle.getRegistrationNo(), vehicle);

        // update the list of vehicles
        driverRef.update("vehicleList", originalVehicleList);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("Your vehicle has been added to your account.")
                .setPositiveButton("Ok", (dialogInterface, i) -> {
                    Helpers.hideDialog(progressBar);
                    finish();
                })
                .create()
                .show();
    }

    // get vehicle list from firebase based on chosesn boty type
    private void setVehicleDataListByBodyType(String bodyType) {
        db.collection("vehicles").document(bodyType.toLowerCase()).get().addOnSuccessListener(documentSnapshot -> {
            VehicleList list = documentSnapshot.toObject(VehicleList.class);
            if (list != null) {
                vehicleDataList = list.vehicleList;
                // set make autocomplete view
                etMake.setAdapter(createStringAdapter(this, getVehicleDataListByType("make")));

                // clear make and model textviews if different bodytype is chosen
                if(!etMake.getText().toString().equals(bodyType)) {
                    etMake.setText("");
                    etModel.setText("");
                    etMake.setEnabled(true);
                    etModel.setEnabled(false);
                }

            }
        });
    }

    private String[] getVehicleDataListByType(String dataType) {
        Set<String> set = new HashSet<>();
        switch (dataType) {
            case "make":
                for(VehicleList.VehicleData data : vehicleDataList) {
                    set.add(Helpers.capitalizeFully(data.make));
                }
                break;
            case "model":
                for(VehicleList.VehicleData data : vehicleDataList) {
                    set.add(Helpers.capitalizeFully(data.model));
                }
                break;
        }

        String[] list = new String[set.size()];
        list = set.toArray(list);
        return list;
    }
}
