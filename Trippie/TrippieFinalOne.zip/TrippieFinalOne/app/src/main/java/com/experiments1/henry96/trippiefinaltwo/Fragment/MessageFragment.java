package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Model.ChatUserHolder;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.MessageActivity;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import de.hdodenhof.circleimageview.CircleImageView;


public class MessageFragment extends Fragment {
    private View chatsView;
    private RecyclerView userChatsList;

    private DatabaseReference chatsRef, usersRef;
    private FirebaseAuth mAuth;

    private final int resourceID = R.layout.fragment_message;

    //TODO clean up of the code to make it tidier get all classes to the model folder as well as move the adapter to the right place

    public MessageFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        chatsView = inflater.inflate(resourceID, container, false);

        userChatsList = chatsView.findViewById(R.id.userChatsList);
        userChatsList.setLayoutManager(new LinearLayoutManager(getContext()));

        mAuth = FirebaseAuth.getInstance();

        chatsRef = FirebaseDatabase.getInstance().getReference().child("chats").child(mAuth.getUid());
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");
        return chatsView;
    }

    @Override
    public void onStart() {
        super.onStart();
        FirebaseRecyclerOptions options =
                new FirebaseRecyclerOptions.Builder<ChatUserHolder>()
                .setQuery(chatsRef, ChatUserHolder.class)
                .build();

        FirebaseRecyclerAdapter<ChatUserHolder, ChatsViewHolder> adapter = new FirebaseRecyclerAdapter<ChatUserHolder, ChatsViewHolder>(options) {
                @Override
                protected void onBindViewHolder(@NonNull ChatsViewHolder holder, int position, @NonNull ChatUserHolder model) {
                    String userId = getRef(position).getKey();

                    usersRef.child(userId).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                String userImage = dataSnapshot.child("profile_image").getValue().toString();
                                String userName = dataSnapshot.child("username").getValue().toString();

                                holder.userNameTv.setText(userName);
                                Picasso.get().load(userImage).into(holder.profileImage);

                                holder.itemView.setOnClickListener(view -> {
                                    Intent intent = new Intent(getContext(), MessageActivity.class);
                                    intent.putExtra("receiver_id", userId);
                                    intent.putExtra("chat_username", userName);
                                    intent.putExtra("chat_user_image", userImage);
                                    startActivity(intent);
                                });
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }

            @NonNull
            @Override
            public ChatsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_user_chats, parent, false);
                ChatsViewHolder viewHolder = new ChatsViewHolder(view);
                return viewHolder;
            }
        };

        userChatsList.setAdapter(adapter);
        adapter.startListening();
    }

    public void goToCreate()
    {
        Intent intent = new Intent(getActivity().getApplication(), CreateTrippieActivity.class);
        startActivity(intent);
    }

    public static class ChatsViewHolder extends RecyclerView.ViewHolder{
        TextView userNameTv, lastMessageDateTv;
        CircleImageView profileImage;

        public ChatsViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTv = itemView.findViewById(R.id.textChatUserName);
            lastMessageDateTv = itemView.findViewById(R.id.textLastMessageDate);
            profileImage = itemView.findViewById(R.id.profile_image);
        }
    }
}
