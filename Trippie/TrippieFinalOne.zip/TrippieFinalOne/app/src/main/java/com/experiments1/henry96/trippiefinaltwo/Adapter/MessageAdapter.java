package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.experiments1.henry96.trippiefinaltwo.Model.Message;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import java.util.List;
import de.hdodenhof.circleimageview.CircleImageView;
import static android.content.Context.MODE_PRIVATE;
import static com.experiments1.henry96.trippiefinaltwo.Helper.Helpers.decodeToBase64;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder> {
    private List<Message> userMessagesList;
    private FirebaseAuth mAuth;
    private Context mcon;


    public MessageAdapter (List<Message> userMessagesList, Context con){
        this.userMessagesList = userMessagesList;
        mcon = con;
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder{
        public TextView rightMessageTv, leftMessageTv;
        public CircleImageView receiverProfileImage;

        public MessageViewHolder(@NonNull View itemView ){
            super(itemView);
            rightMessageTv = itemView.findViewById(R.id.messageRightText);
            leftMessageTv = itemView.findViewById(R.id.messageLeftText);
            receiverProfileImage = itemView.findViewById(R.id.messageProfilePic);
        }
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_messages, parent, false);

        mAuth = FirebaseAuth.getInstance();
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        String currentUserId = mAuth.getUid();
        Message message = userMessagesList.get(position);

        String messageSenderId = message.getSender();
        String messageType = message.getType();

        if (messageType.equals("text")){
            holder.leftMessageTv.setVisibility(View.INVISIBLE);
            holder.receiverProfileImage.setVisibility(View.INVISIBLE);
            holder.rightMessageTv.setVisibility(View.INVISIBLE);

            if(messageSenderId.equals(currentUserId)){
                holder.rightMessageTv.setVisibility(View.VISIBLE);
                holder.rightMessageTv.setText(message.getMessage());
            }
            else{
                holder.leftMessageTv.setText(message.getMessage());
                if(holder.receiverProfileImage.getDrawable() == null){
                    //retrieve image from SharedPreferences
                    SharedPreferences myPreference = mcon.getSharedPreferences("chatProfileImages",MODE_PRIVATE);
                    String imageS = myPreference.getString(messageSenderId, "");
                    Bitmap imageB;
                    if(!imageS.equals("")) {
                        imageB = decodeToBase64(imageS);
                        holder.receiverProfileImage.setImageBitmap(imageB);
                    }
                    else{
                        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference().child("users")
                                .child(messageSenderId);
                        userRef.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists()){
                                    String userImage = dataSnapshot.child("profile_image").getValue().toString();
                                    Picasso
                                            .get()
                                            .load(userImage)
                                            .placeholder(R.mipmap.ic_launcher)
                                            .into(holder.receiverProfileImage);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Log.e("Connection Cancelled", databaseError.getMessage());
                            }
                        });
                    }
                }
                holder.leftMessageTv.setVisibility(View.VISIBLE);
                holder.receiverProfileImage.setVisibility(View.VISIBLE);
            }
        }
    }



    @Override
    public int getItemCount() {
        return userMessagesList.size();
    }



}
