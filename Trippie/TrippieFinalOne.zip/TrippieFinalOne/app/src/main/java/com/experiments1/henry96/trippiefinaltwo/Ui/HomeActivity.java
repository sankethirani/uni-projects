package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.experiments1.henry96.trippiefinaltwo.Adapter.HomeFragmentAdapter;
import com.experiments1.henry96.trippiefinaltwo.Fragment.HomeFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.MessageFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.NotificationFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippiesFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.UserFragment;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.Calendar;
import java.util.Objects;

public class HomeActivity extends AppCompatActivity {
    private static final String TAG = "HomeActivity";
    private BottomNavigationView bottomNav;
    private ViewPager viewPager;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        init();
//        initObjects();
        setupFm(getSupportFragmentManager(), viewPager);
        initListener();


        updateTokenAndActiveDate();

        if (getIntent().getAction() != null && getIntent().getAction().equalsIgnoreCase("Notification")) {
            viewPager.setCurrentItem(3);
            bottomNav.setSelectedItemId(R.id.nav_notification);
        }

        viewPager.setOffscreenPageLimit(5);
    }

    private void updateTokenAndActiveDate() {
        /* update Token when user is login*/
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        String token = Objects.requireNonNull(task.getResult()).getToken();
                        Log.e(TAG, token);
                        DocumentReference userref = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getUid()));
                        userref.update("token", token);
                        userref.update("lastActiveDate", Calendar.getInstance().getTime());
                    }
                });
    }


    private void init() {
        bottomNav = findViewById(R.id.bottom_navigation);
        viewPager = findViewById(R.id.viewpager);
        db = FirebaseFirestore.getInstance();
    }

    private void initListener() {
        bottomNav.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        viewPager.setCurrentItem(2); //Set Currrent Item When Activity Start
        bottomNav.setSelectedItemId(R.id.nav_home);
        viewPager.addOnPageChangeListener(new PageChange());
    }

    public void setupFm(FragmentManager fragmentManager, ViewPager viewPager) {
        HomeFragmentAdapter Adapter = new HomeFragmentAdapter(fragmentManager);
        //Add All Fragment To List
        Adapter.add(new MessageFragment(), "Messages");
        Adapter.add(new TrippiesFragment(), "Trippies");
        Adapter.add(new HomeFragment(), "Home");
        Adapter.add(new NotificationFragment(), "Notifications");
        Adapter.add(new UserFragment(), "Profile");
        viewPager.setAdapter(Adapter);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.nav_messages:
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.nav_trippies:
                    viewPager.setCurrentItem(1);
                    return true;
                case R.id.nav_home:
                    viewPager.setCurrentItem(2);
                    return true;
                case R.id.nav_notification:
                    viewPager.setCurrentItem(3);
                    return true;
                case R.id.nav_user:
                    viewPager.setCurrentItem(4);
                    return true;

            }
            return false;
        }
    };

    public class PageChange implements ViewPager.OnPageChangeListener {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }

        @Override
        public void onPageSelected(int position) {
            switch (position) {
                case 0:
                    bottomNav.setSelectedItemId(R.id.nav_messages);
                    break;
                case 1:
                    bottomNav.setSelectedItemId(R.id.nav_trippies);
                    break;
                case 2:
                    bottomNav.setSelectedItemId(R.id.nav_home);
                    break;
                case 3:
                    bottomNav.setSelectedItemId(R.id.nav_notification);
                    break;
                case 4:
                    bottomNav.setSelectedItemId(R.id.nav_user);
                    break;
            }
        }
    }
}
