package com.experiments1.henry96.trippiefinaltwo.Helper;



public class FilePaths {

    public FilePaths() {
    }

    public String FIREBASE_IMAGE_STORAGE = "images/users";
    public String FIREBASE_PROJECT_IMAGE_STORAGE = "images/trippies";
    public String FIREBASE_ISSUE_IMAGE_STORAGE = "images/issues";
}
