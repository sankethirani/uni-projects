package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

public class TimePickerFragment extends DialogFragment {

    private Calendar cHolder;
    private CreateTrippieSecondStepFragment originalFragment;
    private int year, month, day;
    private Calendar c;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);
        day = c.get(Calendar.DAY_OF_MONTH);
        TimePickerDialog tp = new TimePickerDialog(getActivity(),myTimeSet,hour,minute,true);
        tp.setCancelable(true);
        DatePickerDialog dp = new DatePickerDialog(Objects.requireNonNull(originalFragment.getActivity()), myDateSet,year, month, day);
        dp.setOnDismissListener(c -> tp.cancel());
        tp.show();
        return dp;
        //return new TimePickerDialog(getActivity(),this,hour,minute,true);
    }

    TimePickerFragment(CreateTrippieSecondStepFragment originalFragment, Calendar startingTime){
        this.originalFragment = originalFragment;
        c = startingTime;
    }

    private Calendar getCalendar(){
        return cHolder;
    }

    private void setCalendar(Calendar cal){
        cHolder = cal;
    }

    private final TimePickerDialog.OnTimeSetListener myTimeSet = new TimePickerDialog.OnTimeSetListener(){

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

            Calendar c = getCalendar();

            c.set(Calendar.HOUR_OF_DAY,hourOfDay);
            c.set(Calendar.MINUTE,minute);
            c.set(Calendar.SECOND,0);
            Date sendDate = c.getTime();
            originalFragment.getPickedDateTime(sendDate);
        }
    };


    private final DatePickerDialog.OnDateSetListener myDateSet = (view, year, month, dayOfMonth) -> {

        //Calendar c = getCalendar();
        Calendar c = Calendar.getInstance();

        c.set(Calendar.YEAR,year);
        c.set(Calendar.MONTH,month);
        c.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        setCalendar(c);
    };
}