package com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.experiments1.henry96.trippiefinaltwo.Helper.CaptureSignatureView;
import com.experiments1.henry96.trippiefinaltwo.R;

public class SignatureDialogFragment extends DialogFragment implements View.OnClickListener {


    private CaptureSignatureView mSig;
    private Button btnCancel, btnSave;
    private onSignatureDialogFragmentListeners onSignatureDialogFragmentListeners;

    public interface onSignatureDialogFragmentListeners {
        void onSaveClickListener(Bitmap bitmap, byte[] signatureBytes);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_signature, container, false);

        LinearLayout mContent = (LinearLayout) v.findViewById(R.id.linearLayout);
        mSig = new CaptureSignatureView(getContext(), null);
        mContent.addView(mSig, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        getDialog().setCanceledOnTouchOutside(false);

        btnSave = v.findViewById(R.id.btnSave);
        btnCancel = v.findViewById(R.id.btnCancel);

        btnSave.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onSignatureDialogFragmentListeners= (SignatureDialogFragment.onSignatureDialogFragmentListeners) getParentFragment();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSave:
                byte[] signatureBytes = mSig.getBytes();
                Bitmap signatureBitmap = mSig.getBitmap();
                onSignatureDialogFragmentListeners.onSaveClickListener(signatureBitmap, signatureBytes);
                dismiss();
                break;
            case R.id.btnCancel:
                dismiss();
                break;
        }
    }
}
