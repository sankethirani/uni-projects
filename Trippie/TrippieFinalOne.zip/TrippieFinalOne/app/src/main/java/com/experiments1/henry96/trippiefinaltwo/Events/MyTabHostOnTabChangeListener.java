package com.experiments1.henry96.trippiefinaltwo.Events;


import android.widget.TabHost;

import androidx.viewpager.widget.ViewPager;

public class MyTabHostOnTabChangeListener implements TabHost.OnTabChangeListener {

    private ViewPager viewPager;
    private TabHost myTabHost;

    public MyTabHostOnTabChangeListener(ViewPager viewPager, TabHost myTabHost){
        this.viewPager  = viewPager;
        this.myTabHost  = myTabHost;
    }


    @Override
    public void onTabChanged(String tabId) {
       viewPager.setCurrentItem(myTabHost.getCurrentTab());
    }
}
