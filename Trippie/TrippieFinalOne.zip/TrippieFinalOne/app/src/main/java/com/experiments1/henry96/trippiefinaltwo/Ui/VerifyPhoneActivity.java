package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.concurrent.TimeUnit;

public class VerifyPhoneActivity extends AppCompatActivity {

    private static final String TAG = "VerifyPhoneActivity";
    private String verificationId, phoneNumber;
    private FirebaseAuth mAuth;
    private EditText codeEditText;
    private TextView phoneNumberLabel;
    private Intent intent;
    private Button verifyPhoneButton;
    private ProgressBar progressBar;
    private FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_phone);

        init();
        initListeners();
        initObjects();
        setUpUI();
        sendVerificationCode(phoneNumber);
    }

    private void init() {
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        codeEditText = findViewById(R.id.code_edit_text);
        phoneNumberLabel = findViewById(R.id.phone_label);
        verifyPhoneButton = findViewById(R.id.verify_phone_button);
        progressBar = findViewById(R.id.progress_bar);

        intent = getIntent();
    }

    private void initListeners() {
        verifyPhoneButton.setOnClickListener(view -> {
            Helpers.showDialog(progressBar);
            String code = codeEditText.getText().toString().trim();
            if (code.isEmpty()){
                codeEditText.setError("Please enter code");
                return;
            }
            verifyCode(code);
        });
    }

    private void initObjects() {
        phoneNumber = intent.getStringExtra("phonenumber");
    }

    private void setUpUI() {
        phoneNumberLabel.setText(phoneNumber);
    }

    private void sendVerificationCode(String phoneNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBack
        );
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationId = s;
        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                codeEditText.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.w(TAG, "onVerificationFailed", e);

            Toast.makeText(VerifyPhoneActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    private void verifyCode (String code){
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()){
                Log.d(TAG, "signInWithCredential:success");
                Helpers.hideDialog(progressBar);
                String currentUserId = mAuth.getUid();
                DocumentReference userRef = db.collection("users").document(currentUserId);
                userRef.get().addOnCompleteListener(task1 -> {
                    if (task1.isSuccessful()){
                        DocumentSnapshot documentSnapshot = task1.getResult();
                        if(!documentSnapshot.exists()){
                            Intent intent = new Intent(VerifyPhoneActivity.this, RegisterActivity.class);
                            intent.putExtra("phone_number", phoneNumber);
                            intent.putExtra("user_id", currentUserId);
                            startActivity(intent);
                        }
                        else{
                            Intent intent = new Intent(VerifyPhoneActivity.this, HomeActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                });
            }
            else{
                Toast.makeText(VerifyPhoneActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
