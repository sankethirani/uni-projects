package com.experiments1.henry96.trippiefinaltwo.Events;


import android.widget.TabHost;

import androidx.viewpager.widget.ViewPager;

public class MyViewPagerOnPageChangeListener implements ViewPager.OnPageChangeListener {

    private TabHost myTabHost;

    public MyViewPagerOnPageChangeListener(TabHost myTabHost){
        this.myTabHost  = myTabHost;
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        myTabHost.setCurrentTab(position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
