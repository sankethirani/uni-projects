package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.PackageType;
import com.experiments1.henry96.trippiefinaltwo.Helper.RetrieveImagePath;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class CreateTrippieFourthStepFragment extends Fragment {

    private View v;
    private Trippie trippie;
    private List<Uri> mainImageUri;
    private Uri supplementaryImageFilepath;
    private Button createButton;
    private FirebaseFirestore database;
    private FirebaseUser currentUser;
    private TrippieDetailFragment trippieDetailFragment;
    private RelativeLayout loadingCircle;
    private FrameLayout createContainer;
    private boolean signatureRequiredForItems, isRelist = false;
    private double originalTrippiePrice;
    private PackageType oldType, newType;
    private String thumbnailLocation;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        int resourceID = R.layout.fragment_create_trippie_fourth_step;
        v = inflater.inflate(resourceID, container, false);
        initialiseFields();
        initialiseOnClicks();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).setViewCreated(3);
    }

    public void setThumbnailLocationForRelist(String location){
        this.thumbnailLocation = location;
        isRelist = true;
    }

    private void initialiseFields(){
        trippie = new Trippie();
        createButton = v.findViewById(R.id.create_trippie_button);
        database = FirebaseFirestore.getInstance();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        trippieDetailFragment = new TrippieDetailFragment(true);
        createContainer = v.findViewById(R.id.create_button_container);
        getChildFragmentManager().beginTransaction().add(R.id.display_trippie_details, trippieDetailFragment).commit();
    }

    private void initialiseOnClicks(){
        createButton.setOnClickListener(c -> {
            createButton.setEnabled(false); createButton.setText("");
            loadingCircle = (RelativeLayout) getLayoutInflater().inflate(R.layout.loading_circle, createContainer, false);
            loadingCircle.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
            createContainer.addView(loadingCircle);
            createTrippie();
        });
    }

    private void createTrippie(){
        String supplementaryImageUrl = null;
        List<String> mainImageUrls = new ArrayList<>();

        if (Objects.requireNonNull(Objects.requireNonNull(mainImageUri.get(0)).getPath()).split("/")[2].endsWith(":")) {
            if(supplementaryImageFilepath != null) supplementaryImageUrl = Objects.requireNonNull(supplementaryImageFilepath.getPath()).split(":")[1];
            for(Uri imageUri : mainImageUri) mainImageUrls.add(Objects.requireNonNull(imageUri.getPath()).split(":")[1]);
        } else {
            if(supplementaryImageFilepath != null) supplementaryImageUrl = RetrieveImagePath.getPath(getContext(), supplementaryImageFilepath);
            for(Uri imageUri : mainImageUri) mainImageUrls.add(RetrieveImagePath.getPath(getContext(),imageUri));
        }

        List<String> images = new ArrayList<>();
        images.add(mainImageUrls.get(0));
        if(supplementaryImageFilepath != null) images.add(supplementaryImageUrl);
        for(int i = 1; i < mainImageUrls.size();i++) images.add(mainImageUrls.get(i));

        List<String> fileNames = new ArrayList<>();

        List<String> listingImageFileNames = new ArrayList<>();

        String userId = currentUser.getUid();
        trippie.setUserId(userId);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference sr = storage.getReference();
        Bitmap thumbImage = null;

        try {
            thumbImage = scaleDown(MediaStore.Images.Media.getBitmap(Objects.requireNonNull(getActivity()).getContentResolver(), mainImageUri.get(0)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        StorageReference imageRef;


        String[] temp = Objects.requireNonNull(mainImageUrls.get(0)).split(getResources().getString(R.string.file_path_splitter));
        temp = temp[temp.length - 1].split("/");
        String[] filenameSplit = Helpers.filenameExtensionSplitter(temp[temp.length - 1]);
        String thumbFileName = userId + "_" + filenameSplit[0] + "_thumb";

        Uri thumbUri = Objects.requireNonNull(returnUriFromBitmap(thumbImage, thumbFileName));

        temp = thumbUri.toString().split("/");
        thumbFileName = temp[temp.length - 1];

        imageRef = sr.child("images/trippies/" + thumbFileName);
        UploadTask thumbUploadTask = imageRef.putFile(thumbUri);
        thumbUploadTask.addOnFailureListener(e -> Log.d("oop", Objects.requireNonNull(e.getMessage())));


        for (int i = 0; i < images.size(); i++) {
            String image = images.get(i);
            Uri file;
            file = Uri.fromFile(new File(Objects.requireNonNull(image)));

            temp = Objects.requireNonNull(images.get(i)).split(getResources().getString(R.string.file_path_splitter));
            temp = temp[temp.length - 1].split("/");
            filenameSplit = Helpers.filenameExtensionSplitter(temp[temp.length - 1]);
            fileNames.add(userId + "_" + filenameSplit[0] + "_" + i + filenameSplit[1]);
            imageRef = sr.child("images/trippies/" + fileNames.get(i));

            UploadTask uploadTask = imageRef.putFile(file);

            uploadTask.addOnFailureListener(fail -> Helpers.showToast(getActivity(), "oops"));
        }

        listingImageFileNames.add(fileNames.get(0));
        for (int i = (supplementaryImageFilepath != null) ? 2 : 1; i < fileNames.size(); i++) listingImageFileNames.add(fileNames.get(i));
        trippie.setListingImage(listingImageFileNames);
        trippie.setThumbnailUrl(thumbFileName);

        //set Trippie active is true
        trippie.setActive(true);

        Calendar calendar = Calendar.getInstance();
        trippie.setPostedDate(calendar.getTime());

        calendar.add(Calendar.DAY_OF_YEAR,14);

        trippie.setExpiryTime(calendar.getTime());

        if (supplementaryImageFilepath != null) trippie.setVetImageUrl(fileNames.get(1));

        DocumentReference newTestTrippieRef = database.collection("trippies").document();
        trippie.setTrippieId(newTestTrippieRef.getId());

        newTestTrippieRef.set(trippie).addOnCompleteListener(task -> { if (task.isSuccessful()) getActivity().finish(); });
    }

    Trippie getTrippie(){
        return trippie;
    }

    public void prepareTrippie() {
        if(oldType != newType || originalTrippiePrice == 0) originalTrippiePrice = trippie.getPrice();
        trippie.setPrice(originalTrippiePrice + (signatureRequiredForItems ? 3 : 0));
        trippieDetailFragment.previewDetailsBeforeCreation(trippie, mainImageUri);
    }

    void signatureRequiredPackageType(boolean required, PackageType type){
        oldType = newType;
        this.newType = type;
        this.signatureRequiredForItems = required;
        if(required) originalTrippiePrice = trippie.getPrice(); //if signature is required or type has changed, set a new default price

    }

    void refreshMapAfterPolyline(){
        trippieDetailFragment.refreshMapAfterPolyline(trippie);
    }

    void setMainImageFilePaths(List<Uri> mainImageUri){
        this.mainImageUri = mainImageUri;
    }

    void setSupplementaryImageFilepath(Uri supplementaryImageFilepath){
        this.supplementaryImageFilepath = supplementaryImageFilepath;
    }


    private Uri returnUriFromBitmap(Bitmap bitmap, String title) {
        File tempDir = Environment.getExternalStorageDirectory();
        tempDir = new File(tempDir.getAbsolutePath() + "/temp/");
        if (tempDir.exists() || tempDir.mkdir()) {
            File tempFile;
            try {
                tempFile = File.createTempFile(title, ".jpg", tempDir);

                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                byte[] bitmapData = bytes.toByteArray();

                //write the bytes in file
                FileOutputStream fos = new FileOutputStream(tempFile);
                fos.write(bitmapData);
                fos.flush();
                fos.close();
                return Uri.fromFile(tempFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private static Bitmap scaleDown(Bitmap realImage) {
        float ratio = Math.min(200f / realImage.getWidth(), 200f / realImage.getHeight());
        int width = Math.round(ratio * realImage.getWidth());
        int height = Math.round(ratio * realImage.getHeight());

        return Bitmap.createScaledBitmap(realImage, width, height, true);
    }
}
