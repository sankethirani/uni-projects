package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.experiments1.henry96.trippiefinaltwo.Adapter.TrippiesFragmentAdapter;
import com.experiments1.henry96.trippiefinaltwo.Events.MyTabHostOnTabChangeListener;
import com.experiments1.henry96.trippiefinaltwo.Events.MyViewPagerOnPageChangeListener;
import com.experiments1.henry96.trippiefinaltwo.Helper.FakeContent;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TrippiesFragment extends Fragment {

    private final int resourceID = R.layout.fragment_trippies;
    private TabHost myTabHost;
    private ViewPager viewPager;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);

        init(v);
        setupTabHost();
        setupViewPager();

        viewPager.addOnPageChangeListener(new MyViewPagerOnPageChangeListener(myTabHost));
        myTabHost.setOnTabChangedListener(new MyTabHostOnTabChangeListener(viewPager, myTabHost));

        return v;
    }

    private void init(View view) {
        viewPager = view.findViewById(R.id.viewPager);
        myTabHost = view.findViewById(R.id.myTabHost);
    }

    private void setupTabHost() {
        myTabHost.setup();
        String[] tabNames = {"Trippies", "Jobs", "Offers"};

        for (String tabName : tabNames) {
            TabHost.TabSpec tabspec;
            tabspec = myTabHost.newTabSpec(tabName);
            View view = LayoutInflater.from(getContext()).inflate(R.layout.custom_tabhost,
                    myTabHost.getTabWidget(), false);
            ImageView imgtabF = view.findViewById(R.id.img_icon);
            ImageView dot = view.findViewById(R.id.dot);
            TextView tvHostName = view.findViewById(R.id.tvHostName);
            tvHostName.setText(tabName);
            imgtabF.setBackgroundResource(Helpers.getResoureImageID(Objects.requireNonNull(getContext()), tabName.toLowerCase()));
            dot.setBackgroundResource(R.drawable.tab_selector);
            tabspec.setIndicator(view);
            tabspec.setContent(new FakeContent(getContext()));
            myTabHost.addTab(tabspec);
        }
    }

    private void setupViewPager() {
        List<Fragment> items = new ArrayList<>();
        items.add(new FragmentTrippies_Trippies());
        items.add(new FragmentTrippies_Jobs());
        items.add(new FragmentTrippies_Offers());

        TrippiesFragmentAdapter adapter = new TrippiesFragmentAdapter(getChildFragmentManager(), items);
        viewPager.setAdapter(adapter);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }


}
