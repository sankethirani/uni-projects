package com.experiments1.henry96.trippiefinaltwo.Model;

import com.experiments1.henry96.trippiefinaltwo.Fragment.UserTypeInterface;

import java.util.Date;
import java.util.Map;

public class Driver implements UserTypeInterface {
    // driverId = userId
    private String driverId;
    // right to work evidence type
    private String rightToWorkType;
    private Date visaExpiryDate;
    // licence details
    private String licenceNo,licenceClass;
    private Date licenceIssueDate,licenceExpiryDate;
    // extra details
    private boolean has120DemeritPoints;
    private String desTrafficViolations,desTrafficAccidents,desCriminalConvictions;
    private boolean isVerified = false;
    private Date creationDate;
    //verification status
    private boolean isLicenceVerified, isRightToWorkVerified = false;


    //rating
    private double rating;
    private int numberOfRatings;

    private Map<String, Vehicle> vehicleList;
    private boolean hasAgreed;

    public Driver() {
    }

    public Driver(String driverId, String rightToWorkType, Date visaExpiryDate, String licenceNo, String licenceClass, Date licenceIssudeDate, Date licenceExpiryDate, boolean has120DemeritPoints, String desTrafficViolations, String desTrafficAccidents, String desCriminalConvictions, boolean isVerified, Date creationDate, boolean isLicenceVerified, boolean isRightToWorkVerified, double rating, int numberOfRatings, Map<String, Vehicle> vehicleList, boolean hasAgreed) {
        this.driverId = driverId;
        this.rightToWorkType = rightToWorkType;
        this.visaExpiryDate = visaExpiryDate;
        this.licenceNo = licenceNo;
        this.licenceClass = licenceClass;
        this.licenceIssueDate = licenceIssudeDate;
        this.licenceExpiryDate = licenceExpiryDate;
        this.has120DemeritPoints = has120DemeritPoints;
        this.desTrafficViolations = desTrafficViolations;
        this.desTrafficAccidents = desTrafficAccidents;
        this.desCriminalConvictions = desCriminalConvictions;
        this.isVerified = isVerified;
        this.creationDate = creationDate;
        this.isLicenceVerified = isLicenceVerified;
        this.isRightToWorkVerified = isRightToWorkVerified;
        this.rating = rating;
        this.numberOfRatings = numberOfRatings;
        this.vehicleList = vehicleList;
        this.hasAgreed = hasAgreed;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getRightToWorkType() {
        return rightToWorkType;
    }

    public void setRightToWorkType(String rightToWorkType) {
        this.rightToWorkType = rightToWorkType;
    }

    public Date getVisaExpiryDate() {
        return visaExpiryDate;
    }

    public void setVisaExpiryDate(Date visaExpiryDate) {
        this.visaExpiryDate = visaExpiryDate;
    }

    public String getLicenceNo() {
        return licenceNo;
    }

    public void setLicenceNo(String licenceNo) {
        this.licenceNo = licenceNo;
    }

    public String getLicenceClass() {
        return licenceClass;
    }

    public void setLicenceClass(String licenceClass) {
        this.licenceClass = licenceClass;
    }

    public Date getLicenceIssueDate() {
        return licenceIssueDate;
    }

    public Date getLicenceExpiryDate() {
        return licenceExpiryDate;
    }

    public void setLicenceExpiryDate(Date licenceExpiryDate) {
        this.licenceExpiryDate = licenceExpiryDate;
    }

    public boolean isHas120DemeritPoints() {
        return has120DemeritPoints;
    }

    public void setHas120DemeritPoints(boolean has120DemeritPoints) {
        this.has120DemeritPoints = has120DemeritPoints;
    }

    public String getDesTrafficViolations() {
        return desTrafficViolations;
    }

    public void setDesTrafficViolations(String desTrafficViolations) {
        this.desTrafficViolations = desTrafficViolations;
    }

    public String getDesTrafficAccidents() {
        return desTrafficAccidents;
    }

    public void setDesTrafficAccidents(String desTrafficAccidents) {
        this.desTrafficAccidents = desTrafficAccidents;
    }

    public String getDesCriminalConvictions() {
        return desCriminalConvictions;
    }

    public void setDesCriminalConvictions(String desCriminalConvictions) {
        this.desCriminalConvictions = desCriminalConvictions;
    }

    public Map<String, Vehicle> getVehicleList() {
        return vehicleList;
    }

    public void setVehicleList(Map<String, Vehicle> vehicleList) {
        this.vehicleList = vehicleList;
    }

    public boolean isHasAgreed() {
        return hasAgreed;
    }

    public void setHasAgreed(boolean hasAgreed) {
        this.hasAgreed = hasAgreed;
    }

    public void setLicenceIssueDate(Date licenceIssueDate) {
        this.licenceIssueDate = licenceIssueDate;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getNumberOfRatings() {
        return numberOfRatings;
    }

    public void setNumberOfRatings(int numberOfRatings) {
        this.numberOfRatings = numberOfRatings;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public boolean isLicenceVerified() {
        return isLicenceVerified;
    }

    public void setLicenceVerified(boolean licenceVerified) {
        isLicenceVerified = licenceVerified;
    }

    public boolean isRightToWorkVerified() {
        return isRightToWorkVerified;
    }

    public void setRightToWorkVerified(boolean rightToWorkVerified) {
        isRightToWorkVerified = rightToWorkVerified;
    }
}
