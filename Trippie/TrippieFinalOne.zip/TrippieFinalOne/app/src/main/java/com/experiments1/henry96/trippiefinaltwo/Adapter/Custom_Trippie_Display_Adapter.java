package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class Custom_Trippie_Display_Adapter extends RecyclerView.Adapter<Custom_Trippie_Display_Adapter.TrippieViewHolder> {

    private ArrayList<Trippie> items;
    private OnItemClickListener mListener;
    private Context context;
    private static final String TAG = "Custom_Trippie_Display_";
    private boolean isjob;


    public Custom_Trippie_Display_Adapter(ArrayList<Trippie> items, Context context) {
        this.items = items;
        this.context = context;
        isjob = false;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    //set Onclick interface
    public interface OnItemClickListener {
        void onItemEditClick(int position);

        void onRelistCLick(int position);

        void onCancelCLick(int position);

        void onEditCLick(int position);

        void onDeleteCLick(int position);
    }

    public void setIsjob(Boolean value) {
        isjob = value;
    }

    @NonNull
    @Override
    public TrippieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_trippie_item, parent, false);
        return new TrippieViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull TrippieViewHolder holder, int position) {
        Trippie currentItem = items.get(position);
//        Log.e(TAG, currentItem.getDeliveryTime().toString());
        if (currentItem != null && currentItem.getTrippieId() != null)
            holder.bind(currentItem, context, isjob);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class TrippieViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private ImageView imgTrippie;
        private TextView tvSourceLocation, tvPickupDate, tvDeliveryDate, tvPrice, tvOffers;
        private ImageView imgStatus, imgUpdate, imgRelist, imgDelete, imgCancel;

        private LinearLayout linearButtons;
        private View view;

        TrippieViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTrippieTitle);
            imgTrippie = itemView.findViewById(R.id.imgTripe);
            tvSourceLocation = itemView.findViewById(R.id.tvSourceLocation);
            tvPickupDate = itemView.findViewById(R.id.tvPickupDate);
            tvDeliveryDate = itemView.findViewById(R.id.tvDeliveryDate);
            imgStatus = itemView.findViewById(R.id.imgStatus);
            tvPrice = itemView.findViewById(R.id.tvPrice);
            imgUpdate = itemView.findViewById(R.id.imgEdit);
            imgRelist = itemView.findViewById(R.id.imgrelist);
            imgDelete = itemView.findViewById(R.id.imgdelete);
            imgCancel = itemView.findViewById(R.id.imgcancel);
            linearButtons = itemView.findViewById(R.id.linearcustom);
            tvOffers = itemView.findViewById(R.id.tvTrippieOffers);
            view = itemView.findViewById(R.id.view);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION)
                    listener.onItemEditClick(position);
            });

            imgUpdate.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION)
                    listener.onEditCLick(position);
            });

            imgRelist.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION)
                    listener.onRelistCLick(position);
            });

            imgDelete.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION)
                    listener.onDeleteCLick(position);
            });

            imgCancel.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION)
                    listener.onCancelCLick(position);
            });
        }

        void bind(Trippie trippie, Context context, boolean isjob) {
            resetLayout();
            if (isjob) {
                linearButtons.setVisibility(View.GONE);
                view.setVisibility(View.GONE);
                tvOffers.setVisibility(View.GONE);
            } else {

                if (trippie.getDriverId() != null) {
                    imgUpdate.setVisibility(View.GONE);
                    if (!(trippie.getStatus().equals(Trippie.Status.customer_accepted) || trippie.getStatus().equals(Trippie.Status.on_The_Way_To_Pick_Up)))
                        imgCancel.setVisibility(View.GONE);
                    if (trippie.getStatus().equals(Trippie.Status.delivered))
                        itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.disabled));
                }
                if (trippie.getOffers() != null && !trippie.getOffers().isEmpty()) {
                    imgDelete.setVisibility(trippie.getCancelled() ? View.VISIBLE : View.GONE);
                } else if (trippie.getExpiryTime().before(new Date())) {
                    imgRelist.setVisibility(View.GONE);
                }


                if (imgCancel.getVisibility() == View.VISIBLE && trippie.getCancelled()) {
                    imgCancel.setVisibility(View.GONE);
                    imgUpdate.setVisibility(View.GONE);
                    itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.disabled));
                }
            }

            tvTitle.setText(trippie.getTitle());
            tvSourceLocation.setText(trippie.getPickupAddress());
            String formattedPrice = String.valueOf(Math.round(trippie.getPrice()));
            tvPrice.setTextSize(formattedPrice.length() > 2 ? 14 : 20);
            tvPrice.setText(String.format(context.getString(R.string.currency), formattedPrice));

            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.UK);
            tvPickupDate.setText(dateFormat.format(trippie.getPickupTime()));
            tvDeliveryDate.setText(dateFormat.format(trippie.getDeliveryTime()));
//            Log.e(TAG, trippie.getPickupTime().toString());

            if (trippie.getStatus() == null) {
                imgStatus.setImageResource(Helpers.getResoureImageID(context, "ic_pending"));
                if (trippie.getOffers() != null) {
//                    String size = String.valueOf(trippie.getOffers().size());
                    //fix as it will be show the inactive as well
                    ArrayList<Offer> offers = new ArrayList<>(trippie.getOffers().values());
                    int count = numberOfActiveOffers(offers);
                    tvOffers.setText(String.valueOf(count));
                } else {
                    tvOffers.setText("0");
                }
            } else if (trippie.getStatus().equals(Trippie.Status.delivered)) {
                imgStatus.setImageResource(Helpers.getResoureImageID(context, "ic_check"));
                tvOffers.setVisibility(View.GONE);
            } else {
                tvOffers.setVisibility(View.GONE);
                imgStatus.setImageResource(Helpers.getResoureImageID(context, "ic_inprogress"));
            }

            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference sr = storage.getReference();
            sr.child("images/trippies/" + trippie.getThumbnailUrl()).getDownloadUrl().addOnSuccessListener(uri -> Picasso.get()
                    .load(uri)
                    .placeholder(R.drawable.null_image)
                    .fit()
                    .centerCrop()
                    .into(imgTrippie));

        }

        private void resetLayout() {
            linearButtons.setVisibility(View.VISIBLE);
            view.setVisibility(View.VISIBLE);
            tvOffers.setVisibility(View.VISIBLE);
            imgUpdate.setVisibility(View.VISIBLE);
            imgCancel.setVisibility(View.VISIBLE);
            itemView.setBackgroundColor(Color.TRANSPARENT);
            imgDelete.setVisibility(View.VISIBLE);
            imgRelist.setVisibility(View.VISIBLE);
        }

        private int numberOfActiveOffers(ArrayList<Offer> offers) {
            int count = 0;
            for (Offer item : offers) {
                if (item.isActive()) {
                    count++;
                }
            }
            return count;
        }
    }
}
