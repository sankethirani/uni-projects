package com.experiments1.henry96.trippiefinaltwo.Ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.auth.FirebaseAuth;

public class SplashActivity extends AppCompatActivity {

    private long splashTime = 500L;
    private Handler myHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        myHandler = new Handler();
        myHandler.postDelayed(goToPhoneActivity(),splashTime);
    }

    private Runnable goToPhoneActivity(){
        return () -> {
            Intent phoneActivityIntent = new Intent(getApplicationContext(), FirebaseAuth.getInstance().getCurrentUser() == null ? EnterPhoneActivity.class : HomeActivity.class);
            startActivity(phoneActivityIntent);
            finish();
        };

    }
}
