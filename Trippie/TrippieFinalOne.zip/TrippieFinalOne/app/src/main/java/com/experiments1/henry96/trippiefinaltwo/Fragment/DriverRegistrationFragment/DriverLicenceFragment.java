package com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Fragment.GetPhotoUriFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.DriverRegistrationActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Objects;


public class DriverLicenceFragment extends Fragment implements GetPhotoUriFragment.PhotoDialogListener {

    private OnFragmentInteractionListener mListener;
    private CheckBox chkViolation, chkAccident, chkConviction, chkFullLicence, chkDemeritPoints;

    private Button btContinue;
    private View view;
    private DriverRegistrationActivity activity;
    private EditText etFrontLicence, etBackLicence, etEvidence, etLicenceNo, etVisaExpiration, etLicenceIssueDate, etLicenceExpiration, etViolation, etAccident, etConviction;
    private Spinner etLicenceClass;
    private Date visaExpiryDate, licenceIssueDate, licenceExpiryDate;
    private RadioGroup rgEvidence;
    private GetPhotoUriFragment dialog;
    private Map<String, Uri> uriMap;
    private  int numberOfAsyncTasks;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_driver_registration_licence, container, false);


        initialiseLayout();
        setOnClickListeners();
        activity = (DriverRegistrationActivity) getActivity();
        uriMap = Objects.requireNonNull(activity).getUriMap();
        dialog = new GetPhotoUriFragment();

        return view;
    }

    private void initialiseLayout() {
        // checkboxes
        chkViolation = view.findViewById(R.id.checkbox_violation);
        chkAccident = view.findViewById(R.id.checkbox_accident);
        chkConviction = view.findViewById(R.id.checkbox_conviction);
        chkFullLicence = view.findViewById(R.id.chk_full_licence);
        chkDemeritPoints = view.findViewById(R.id.checkbox_demerit_points);

        // edit text
        etViolation = view.findViewById(R.id.text_violation);
        etAccident = view.findViewById(R.id.text_accident);
        etConviction = view.findViewById(R.id.text_conviction);
        etFrontLicence = view.findViewById(R.id.front_licence);
        etBackLicence = view.findViewById(R.id.back_licence);
        etEvidence = view.findViewById(R.id.evidence);
        etLicenceNo = view.findViewById(R.id.et_licence_no);
        etVisaExpiration = view.findViewById(R.id.visa_expiration_date);
        etLicenceExpiration = view.findViewById(R.id.expiration_date_licence);
        etLicenceIssueDate = view.findViewById(R.id.issue_date_licence);
        etLicenceClass = view.findViewById(R.id.et_licence_class);


        // Set adapter for for spinner
        String[] licenceClassList = getResources().getStringArray(R.array.driver_class);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Objects.requireNonNull(getActivity()), R.layout.layout_spinner_item, licenceClassList) {
            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);
                return view;
            }

            @Override
            public boolean isEnabled(int position) {
                // disables hint
                return position != 0;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        etLicenceClass.setAdapter(adapter);
        etLicenceClass.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLACK);
                }
                checkFields();
            }

            @Override public void onNothingSelected(AdapterView<?> adapterView) { }
        });


        // radio group
        rgEvidence = view.findViewById(R.id.rg_evidence);

        btContinue = view.findViewById(R.id.btn_submit);

        // hide all edit text fields
        etViolation.setVisibility(View.GONE);
        etAccident.setVisibility(View.GONE);
        etConviction.setVisibility(View.GONE);
        etVisaExpiration.setVisibility(View.GONE);
    }

    private void setOnClickListeners() {
        chkViolation.setOnClickListener(c -> {
            etViolation.setVisibility(chkViolation.isChecked() ? View.VISIBLE : View.GONE);
            checkFields();
        });
        chkAccident.setOnClickListener(c -> {
            etAccident.setVisibility(chkAccident.isChecked() ? View.VISIBLE : View.GONE);
            checkFields();
        });
        chkConviction.setOnClickListener(c -> {
            etConviction.setVisibility(chkConviction.isChecked() ? View.VISIBLE : View.GONE);
            checkFields();
        });

        chkFullLicence.setOnClickListener(c -> checkFields());

        btContinue.setOnClickListener(view -> {
            activity.setMaxSwipe(0);
            activity.nextPage();
            numberOfAsyncTasks = uriMap.size();
            uploadPhoto();
        });

        rgEvidence.setOnCheckedChangeListener((radioGroup, i) -> etVisaExpiration.setVisibility(i == R.id.rb_ctizen_resident ? View.GONE : View.VISIBLE));

        etFrontLicence.setOnClickListener(view -> {
            dialog.viewId = R.id.front_licence;
            dialog.show(DriverLicenceFragment.this.getChildFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etBackLicence.setOnClickListener(view -> {
            dialog.viewId = R.id.back_licence;
            dialog.show(DriverLicenceFragment.this.getChildFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etEvidence.setOnClickListener(view -> {
            dialog.viewId = R.id.evidence;
            dialog.show(DriverLicenceFragment.this.getChildFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etVisaExpiration.setOnClickListener(c -> setDate((EditText) c));
        etLicenceExpiration.setOnClickListener(c -> setDate((EditText) c));
        etLicenceIssueDate.setOnClickListener(c -> setDate((EditText) c));


        // these are listeners to validate text input when changed
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override public void afterTextChanged(Editable editable) {
                checkFields();
            }
        };

        etViolation.addTextChangedListener(tw);
        etAccident.addTextChangedListener(tw);
        etConviction.addTextChangedListener(tw);
        etVisaExpiration.addTextChangedListener(tw);
        etLicenceExpiration.addTextChangedListener(tw);
        etLicenceIssueDate.addTextChangedListener(tw);
        etLicenceNo.addTextChangedListener(tw);
        etLicenceNo.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus && etLicenceNo.getText().toString().length() < 8) {
                etLicenceNo.setError("Invalid licence number.");
            }
        });

    }


    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    // create new OnDateSetListener by supplying the text view you want to set
    private DatePickerDialog.OnDateSetListener createOnDateListener(EditText et) {


        return (DatePicker datePicker, int year, int month, int day) -> {
            String date = day + "/" + (month + 1) + "/" + year;


            // derive date from calendar data
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(year, month, day);
            Date selectedDate = selectedCalendar.getTime();

            // current calendar
            Calendar nowCalendar = Calendar.getInstance();
            nowCalendar.setTime(Calendar.getInstance().getTime());

            if (et == etLicenceIssueDate) {
                if(nowCalendar.get(Calendar.YEAR) - year > 20) {
                    Helpers.showToast(getContext(), "Invalid issue date. Cannot be set beyond year " + (nowCalendar.get(Calendar.YEAR) - 20));
                    et.setText("");
                } else if (selectedDate.before(Calendar.getInstance().getTime())) {
                    licenceIssueDate = selectedDate;
                    et.setText(date);
                } else {
                    Helpers.showToast(getContext(), "Invalid issue date. Cannot be a future date.");
                    et.setText("");
                }
            } else if (year - nowCalendar.get(Calendar.YEAR) > 20){
                Helpers.showToast(getContext(), "Invalid expiry date. Cannot be set beyond year " + (nowCalendar.get(Calendar.YEAR) + 20));
                et.setText("");
            } else if (selectedDate.after(Calendar.getInstance().getTime())){
                if (et == etLicenceExpiration) licenceExpiryDate = selectedDate;
                else if (et == etVisaExpiration) visaExpiryDate = selectedDate;
                et.setText(date);
            }
            else{
                Helpers.showToast(getContext(), "Invalid expiry date. Cannot be a past date.");
                et.setText("");
            }
        };
    }


    private void setDate(EditText et) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(Objects.requireNonNull(getContext()), createOnDateListener(et), year, month, day);
        dialog.show();
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void getImagePath(Uri imagePath, int id) {
        String title = imagePath.getLastPathSegment();
        switch (id) {
            case R.id.front_licence:
                uriMap.put("frontLicence", imagePath);
                etFrontLicence.setText(title);
                break;
            case R.id.back_licence:
                uriMap.put("backLicence", imagePath);
                etBackLicence.setText(title);
                break;
            case R.id.evidence:
                uriMap.put("evidence", imagePath);
                etEvidence.setText(title);
                break;
        }
        checkFields();
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


    private void checkFields() {
        boolean isFilled = true;

        // Get the selected radio button
        int id = rgEvidence.getCheckedRadioButtonId();
        RadioButton selectedRB = rgEvidence.findViewById(id);

        // checkbox and their descriptions
        if (chkViolation.isChecked() && etViolation.getText().toString().isEmpty()) {
            isFilled = false;
        }
        else if (chkAccident.isChecked() && etAccident.getText().toString().isEmpty()) {
            isFilled = false;
        }
        else if (chkConviction.isChecked() && etConviction.getText().toString().isEmpty()) {
            isFilled = false;
        }
        // checking licence details
        else if (etLicenceNo.getText().toString().length() < 8 || etLicenceClass.getSelectedItemPosition() == 0 || etLicenceIssueDate.getText().toString().isEmpty() || etLicenceExpiration.getText().toString().isEmpty()) {
            isFilled = false;
        }
        else if (!selectedRB.getText().toString().equals("NZ/AU Citizen or Resident") && etVisaExpiration.getText().toString().isEmpty()) {
            isFilled = false;
        }
        // user needs to upload three images.
        else if (uriMap.size() < 3) {
            isFilled = false;
        }

        if (isFilled) {
            if (chkFullLicence.isChecked()) {
                btContinue.setEnabled(true);
                btContinue.setBackgroundResource(R.drawable.custom_button_blue);
                btContinue.setText(getResources().getString(R.string.continue_button));
                activity.setMaxSwipe(1);
                updateDriverDetails();
            } else {
                btContinue.setText(getResources().getString(R.string.full_licence_required_text));
                btContinue.setEnabled(false);
                btContinue.setBackgroundResource(R.drawable.custom_button_disabled);
            }
        } else {
            activity.setMaxSwipe(0);
            btContinue.setEnabled(false);
            btContinue.setBackgroundResource(R.drawable.custom_button_disabled);
            btContinue.setText(R.string.fill_all_fields);
        }
    }


    private void updateDriverDetails() {
        Driver driver = activity.getDriver();

        // extra details
        driver.setDesTrafficViolations(chkViolation.isChecked() ? etViolation.getText().toString() : null);
        driver.setDesTrafficAccidents(chkAccident.isChecked() ? etAccident.getText().toString() : null);
        driver.setDesCriminalConvictions(chkConviction.isChecked() ? etConviction.getText().toString() : null);
        driver.setHas120DemeritPoints(chkDemeritPoints.isChecked());
        if(driver.getNumberOfRatings() == 0) driver.setRating(4.5);


        // Get the selected radio button
        int id = rgEvidence.getCheckedRadioButtonId();
        RadioButton selectedRB = rgEvidence.findViewById(id);

        // set the date and evidence type
        driver.setVisaExpiryDate(selectedRB.getText().toString().equals("NZ/AU Citizen or Resident") ? null : visaExpiryDate);
        driver.setRightToWorkType(selectedRB.getText().toString());

        // licence details
        driver.setLicenceNo(etLicenceNo.getText().toString());
        driver.setLicenceClass(etLicenceClass.getSelectedItem().toString());
        driver.setLicenceIssueDate(licenceIssueDate);
        driver.setLicenceExpiryDate(licenceExpiryDate);

    }

    private void uploadPhoto() {
        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        String userId = FirebaseAuth.getInstance().getUid();

        for(Map.Entry<String, Uri> entry : uriMap.entrySet()) {
            String key = entry.getKey();
            Uri uri = entry.getValue();
            final StorageReference imageRef;

            imageRef = storageRef.child("images/drivers/" + userId + "/" + key);

            UploadTask uploadTask = Objects.requireNonNull(imageRef).putFile(uri);
            uploadTask.addOnSuccessListener(taskSnapshot -> imageRef.getDownloadUrl().addOnSuccessListener(uri1 -> {
                numberOfAsyncTasks--;
                if(numberOfAsyncTasks == 0) {
                    activity.setDriverImagesUploaded(true);
                }
            }));
        }
    }
}

