package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.experiments1.henry96.trippiefinaltwo.Adapter.CreateTrippieFragmentAdapter;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments.DeliveredFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments.OnTheWayFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments.PickedUpFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments.PickingUpFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments.TrippieBeenDeliveredFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.FilePaths;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.NotificationService.NotificationInRetrofitIns;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.experiments1.henry96.trippiefinaltwo.Model.Trippie.Status;

public class DeliveryStatusActivity extends AppCompatActivity implements PickedUpFragment.onPickupFragmentClickListener,
        PickingUpFragment.onPickingUpFragmentClickListener, OnTheWayFragment.onTheWayFragmentClickListeners, DeliveredFragment.DeliveredFragmentClickListener {
    private static final String TAG = "DeliveryStatusActivity";
    private FirebaseFirestore db;
    private Trippie trippie;
    private DocumentReference docRef;
    private String trippieId, userToken;

    private String customerPhoneNo;

    private PickedUpFragment pickedUpFragment;
    private DeliveredFragment deliveredFragment;

    private byte[] mBytes;
    private double progress;
    private static final double MB_THRESHOLD = 5.0, MB = 1000000.0;
    private FrameLayout linearLayout;
    FragmentManager fragmentManager;
    private ArrayList<Fragment> fragments;
    private int currentIdx;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_status);

        setFinishOnTouchOutside(true);
        init();
        loadData();
    }

    private void init() {
        linearLayout = findViewById(R.id.frameContent);
        fragmentManager = getSupportFragmentManager();
        fragments = new ArrayList<>();
        currentIdx = 0;
        trippieId = getIntent().getStringExtra("TrippieId");
        db = FirebaseFirestore.getInstance();
        docRef = db.collection("trippies").document(trippieId);
    }

    private void loadData() {
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            trippie = documentSnapshot.toObject(Trippie.class);
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            db.collection("users").document(trippie.getUserId()).get().addOnSuccessListener(documentSnapshot1 -> {
                user = documentSnapshot1.toObject(User.class);

                if (!Objects.requireNonNull(trippie).getStatus().equals(Status.delivered)) {
                    //get Customer Phone Number
                    customerPhoneNo = Objects.requireNonNull(user).getPhone();


                    PickingUpFragment pickingUpFragment = new PickingUpFragment();
                    Bundle pickingUpBundle = new Bundle();
                    pickingUpBundle.putString("pickUpDestination", trippie.getPickupAddress());
                    pickingUpFragment.setArguments(pickingUpBundle);
                    fragments.add(pickingUpFragment);

                    pickedUpFragment = new PickedUpFragment();
                    Bundle pickedUpBundle = new Bundle();
                    pickedUpBundle.putString("customer", user.getFirstNm());
                    pickedUpFragment.setArguments(pickedUpBundle);
                    fragments.add(pickedUpFragment);

                    OnTheWayFragment onTheWayFragment = new OnTheWayFragment();
                    Bundle onTheWayBundle = new Bundle();
                    onTheWayBundle.putString("destinationLocation", trippie.getDeliveryAddress());
                    onTheWayFragment.setArguments(onTheWayBundle);
                    fragments.add(onTheWayFragment);


                    deliveredFragment = new DeliveredFragment();
                    Bundle deliveredBundle = new Bundle();
                    deliveredBundle.putBoolean("signatureStatus", trippie.getSignatureRequired());
                    deliveredBundle.putString("customer", user.getFirstNm());
                    deliveredFragment.setArguments(deliveredBundle);
                    fragments.add(deliveredFragment);

                    getServiceProviderToken(trippie.getUserId());

                    switch (Status.valueOf(trippie.getStatus().toString()).ordinal()) {
                        case 0:
                            fragmentTransaction.replace(R.id.frameContent, pickingUpFragment).commit();
                            currentIdx = 0;
                            break;
                        case 1:
                            fragmentTransaction.replace(R.id.frameContent, pickedUpFragment).commit();
                            currentIdx = 1;
                            break;
                        case 2:
                            fragmentTransaction.replace(R.id.frameContent, onTheWayFragment).commit();
                            currentIdx = 2;
                            break;
                        case 3:
                            fragmentTransaction.replace(R.id.frameContent, deliveredFragment).commit();
                            currentIdx = 3;
                            break;
                        default:
                    }

                } else {
                    fragmentTransaction.replace(R.id.frameContent, new TrippieBeenDeliveredFragment()).commit();
                }
            });

        });
    }

    private void getServiceProviderToken(String userId) {
        DocumentReference docRef = db.collection("users").document(userId);
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            userToken = documentSnapshot.getString("token");
            Log.e(TAG, userToken);
        });
    }

    //Picking up Fragment Callbacks
    @Override
    public void onPickingupClick() {
        sendNotification("Your Tripster is on the way to the pick up location!", Status.on_The_Way_To_Pick_Up.toString());
//        fragmentManager.beginTransaction().replace(R.id.frameContent, fragments.get(++currentIdx)).commit();
        finish();
    }

    //Picked up Fragment Callbacks
    @Override
    public void onCompletedPickupClick() {

        if (pickedUpFragment.getmSelectedImageUris() != null && pickedUpFragment.getmSelectedImageUris().size() >= 2) {
            sendNotification("Your Trippie has been picked up!", Status.picked_Up.toString());
            int size = pickedUpFragment.getmSelectedImageUris().size();
            int index = 0;
            for (int i = size - 1; i >= size - 2; --i) {
                Log.e(TAG, i + "");

                uploadNewPhoto(pickedUpFragment.getmSelectedImageUris().get(i), Status.picked_Up.toString(), ++index);
            }
//            fragmentManager.beginTransaction().replace(R.id.frameContent, fragments.get(++currentIdx)).commit();

        } else {
            Helpers.showToast(getApplicationContext(), "Please upload 2 photos of the Trippie");
        }

    }

    @Override
    public void onCallClick() {
        makePhoneCall();
    }

    @Override
    public void onMessageClick() {
        activeMessage();
    }


    //On The Way Fragment Callbacks
    @Override
    public void onTheWayClick() {
        sendNotification("Your Tripster is on the way to the delivery location!", Status.on_The_Way_To_Delivery.toString());
//        fragmentManager.beginTransaction().replace(R.id.frameContent, fragments.get(++currentIdx)).commit();
        finish();
    }

    //Completed Delivery Fragment Callbacks
    @Override
    public void onSubmitTrippie() {

        if (trippie.getSignatureRequired() && deliveredFragment.getSignaturebytes() == null) {
            Helpers.showToast(getApplicationContext(), "Please add a signature!");
            return;
        }

        if (deliveredFragment.getmSelectedImageUris() != null && deliveredFragment.getmSelectedImageUris().size() >= 2) {
            sendNotification("Your Trippie has been delivered!", Status.delivered.toString());

            if (trippie.getSignatureRequired())
                executeUploadTaskBytes(deliveredFragment.getSignaturebytes(), Status.delivered.toString(), "signature");

            int size = deliveredFragment.getmSelectedImageUris().size();
            int index = 0;
            for (int i = size - 1; i >= size - 2; --i) {
                Log.e(TAG, i + "");
                uploadNewPhoto(deliveredFragment.getmSelectedImageUris().get(i), Status.delivered.toString(), ++index);
            }

            Helpers.showToast(getApplicationContext(), "You've done your job!");
            getIntent().putExtra("TrippieId", trippieId);


        } else {
            Helpers.showToast(getApplicationContext(), "Please upload 2 photos of the Trippie");
        }

    }

    private void sendNotification(String mbody, String status) {
        Helpers.showToast(getApplicationContext(), "Sending notification");

        String title = "Delivery Progress: [" + trippie.getTitle() + "]";
        String body = mbody;

        int position = Status.valueOf(status).ordinal();
        String trippieid_type_tname = trippieId + "-@-" + Helpers.Key_Driver_Accept + "-@-" + trippie.getTitle();
        String imageurl_driverid = trippie.getThumbnailUrl() + "-@-" + FirebaseAuth.getInstance().getUid();
        Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(userToken, title, body,
                trippieid_type_tname, imageurl_driverid);

        int finalPosition = position;
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                if (response.isSuccessful()) {

                    docRef.update("status", status);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
                    StatusDetail statusDetail = new StatusDetail(status,
                            dateFormat.format(Calendar.getInstance().getTime()), finalPosition);

                    docRef.update("statusDetails." + status, statusDetail);

                    Helpers.showToast(getApplicationContext(), "Notification has been sent to the user!");
                }
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                Helpers.showToast(getApplicationContext(), "Offer failed to send!");
                Log.e(TAG, Objects.requireNonNull(t.getMessage()));
            }
        });
    }


    //Upload Image
    public void uploadNewPhoto(Uri imageUri, String status, int index) {
        Log.d(TAG, "uploadNewPhoto: uploading new profile photo to FireBase storage.");
        BackgroundImageResize resize = new BackgroundImageResize(this, status, index);
        resize.execute(imageUri);
    }

    public static class BackgroundImageResize extends AsyncTask<Uri, Integer, byte[]> {

        private WeakReference<DeliveryStatusActivity> registerActivityWeakReference;
        Bitmap mBitmap;
        private String Status;
        private int index;


        BackgroundImageResize(DeliveryStatusActivity context, String status, int index) {
            registerActivityWeakReference = new WeakReference<>(context);
            Status = status;
            this.index = index;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected byte[] doInBackground(Uri... params) {
            Log.d(TAG, "doInBackground: started.");

            if (mBitmap == null) {
                InputStream iStream = null;

                Log.d(TAG, "Bitmap == null");
                try {
                    iStream = registerActivityWeakReference.get().getContentResolver().openInputStream(params[0]);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                if (iStream != null) {
                    ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
                    int bufferSize = 1024;
                    byte[] buffer = new byte[bufferSize];

                    int len;
                    try {
                        while ((len = iStream.read(buffer)) != -1) {
                            byteBuffer.write(buffer, 0, len);
                        }
                        iStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    return byteBuffer.toByteArray();
                }
                return null;

            } else {
                int size = mBitmap.getRowBytes() * mBitmap.getHeight();
                ByteBuffer byteBuffer = ByteBuffer.allocate(size);
                mBitmap.copyPixelsToBuffer(byteBuffer);
                byte[] bytes = byteBuffer.array();
                byteBuffer.rewind();
                return bytes;
            }
        }


        @Override
        protected void onPostExecute(byte[] bytes) {

            DeliveryStatusActivity activity = registerActivityWeakReference.get();
            if (registerActivityWeakReference == null || activity.isFinishing()) return;

//            Helpers.showDialog(activity.progressBar);
            activity.mBytes = bytes;
            //execute the upload
            activity.executeUploadTask(Status, index);
        }
    }

    private void executeUploadTask(String status, int index) {
        FilePaths filePaths = new FilePaths();
        final StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child(filePaths.FIREBASE_PROJECT_IMAGE_STORAGE + "/" + Objects.requireNonNull(trippieId)
                        + "/" + trippieId + "_" + status + "_" + index);

        if (mBytes.length / MB < MB_THRESHOLD) {
            UploadTask uploadTask = storageReference.putBytes(mBytes);


            uploadTask.addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                Log.d(TAG, "onSuccess: firebase download url : " + uri.toString());
                docRef.update("statusDetails." + status + ".imageLinks.Images" + index, uri.toString());
                finish();

            })).addOnFailureListener(exception -> Helpers.showToast(DeliveryStatusActivity.this, "could not upload photo")).addOnProgressListener(taskSnapshot -> {
                double currentProgress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                if (currentProgress > (progress + 15)) {
                    progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                    Log.d(TAG, "onProgress: Upload is " + progress + "% done");
                }
            })
            ;
        } else {
            Helpers.showToast(this, "Image is too Large");
        }

    }

    private void executeUploadTaskBytes(byte[] bytes, String status, String type) {
        FilePaths filePaths = new FilePaths();
        final StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child(filePaths.FIREBASE_PROJECT_IMAGE_STORAGE + "/" + Objects.requireNonNull(trippieId)
                        + "/" + trippieId + "_" + status + "_" + type);

        if (bytes.length / MB < MB_THRESHOLD) {
            UploadTask uploadTask = storageReference.putBytes(bytes);

            uploadTask.addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                Log.d(TAG, "onSuccess: FireBase download url : " + uri.toString());
                docRef.update("statusDetails." + status + ".imageLinks.Images" + type, uri.toString());
            })).addOnFailureListener(exception -> Helpers.showToast(DeliveryStatusActivity.this, "could not upload photo")).addOnProgressListener(taskSnapshot -> {
                double currentProgress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                if (currentProgress > (progress + 15)) {
                    progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                    Log.d(TAG, "onProgress: Upload is " + progress + "% done");
                }
            })
            ;
        } else {
            Helpers.showToast(this, "Image is too Large");
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void makePhoneCall() {
        String number = customerPhoneNo;
        if (number != null && number.length() > 0) {
            String dial = "tel:" + number;
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
        } else {
            Helpers.showToast(getApplicationContext(), "User has no phone number");
        }
    }

    private void activeMessage() {
        Intent intent = new Intent(getApplicationContext(), MessageActivity.class);
        intent.putExtra("chat_username", user.getFirstNm());
        intent.putExtra("chat_user_image", user.getImage());
        intent.putExtra("receiver_id", user.getUserId());
        startActivity(intent);
    }
}
