package com.experiments1.henry96.trippiefinaltwo.Model;

public class demomodel {
    public String name;
}
