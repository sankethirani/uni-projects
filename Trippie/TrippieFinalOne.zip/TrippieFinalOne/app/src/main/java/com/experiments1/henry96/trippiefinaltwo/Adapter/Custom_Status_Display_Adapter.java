package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;

import java.util.ArrayList;


public class Custom_Status_Display_Adapter extends RecyclerView.Adapter<Custom_Status_Display_Adapter.StatusDetailViewHolder> {

    private ArrayList<StatusDetail> items;
    private OnItemClickListener mListener;
    private Context context;
    private static final String TAG = "Custom_Status_Display";


    public Custom_Status_Display_Adapter(ArrayList<StatusDetail> items, Context context) {
        this.items = items;
        this.context = context;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    //set Onclick interface
    public interface OnItemClickListener {
        void onItemEditClick(int position);
    }


    @NonNull
    @Override
    public StatusDetailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_trippie_status_item, parent, false);
        return new StatusDetailViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull StatusDetailViewHolder holder, int position) {
        StatusDetail currentItem = items.get(position);
        if (currentItem != null) {
            holder.bind(currentItem, context);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class StatusDetailViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTime, tvStatusDetail;

        StatusDetailViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvStatusDetail = itemView.findViewById(R.id.tvStatusDetail);

        }

        void bind(StatusDetail offer, Context context) {
            tvTime.setText(offer.getCreatedTime());
            if(offer.getStatus()!=null){
                tvStatusDetail.setText(Helpers.convertString( offer.getStatus()));

                if(offer.getStatus().equals(Trippie.Status.customer_accepted.toString())){
                    tvStatusDetail.setText("Job accepted");
                }
            }


        }
    }
}
