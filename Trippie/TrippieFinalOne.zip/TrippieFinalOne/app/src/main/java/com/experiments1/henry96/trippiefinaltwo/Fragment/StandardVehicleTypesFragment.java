package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.R;

import java.util.Arrays;


public class StandardVehicleTypesFragment extends Fragment implements VehicleInterface{

    private boolean isPetVersion;
    private RadioButton bikeButton;
    private RadioGroup rg;
    private int sizeFee, litresPerHundredKm, animalQuantity;
    private View v;
    private CreateTrippieFirstStepFragment originalFragment;
    private RadioButton[] buttons;
    private String size, animalString;
    private boolean isRelist = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_standard_vehicle_types, container, false);
        initialiseLayout();
        setOnClickListeners();
        if (isPetVersion) bikeButton.setVisibility(View.GONE);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(isRelist){
            switch(size){
                case "Small"  : bikeButton.performClick(); break;
                case "Medium" : buttons[2].performClick(); break;
                case "Large"  : buttons[1].performClick(); break;
                case "X-Large": buttons[0].performClick(); break;
            }

            if(isPetVersion) setAnimalQuantity(animalString,animalQuantity);
        }
    }

    private void initialiseLayout(){
        bikeButton = v.findViewById(R.id.bike_button);
        rg = v.findViewById(R.id.size_radio_group);
        buttons = new RadioButton[]{v.findViewById(R.id.large_truck_button),v.findViewById(R.id.truck_button),v.findViewById(R.id.car_button),bikeButton};
    }

    private void setOnClickListeners(){
        rg.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i != -1){
                String sizeString = ((RadioButton)radioGroup.findViewById(i)).getText().toString();
                switch(sizeString){ //check which radio button was pressed
                    case "Small"  :  sizeFee =  6; litresPerHundredKm =  4; break;
                    case "Medium" :  sizeFee =  9; litresPerHundredKm =  8; break;
                    case "Large"  :  sizeFee = 20; litresPerHundredKm = 12; break;
                    case "X-large":  sizeFee = 30; litresPerHundredKm = 15; break;
                }
                originalFragment.setVehicleSpecs(sizeFee,litresPerHundredKm,sizeString,isPetVersion); //return vehicle size statistics back to original fragment
            }
        });
    }

    StandardVehicleTypesFragment(boolean isPetVersion,CreateTrippieFirstStepFragment originalFragment) {
        this.isPetVersion = isPetVersion;
        this.originalFragment = originalFragment;
    }

    public int setAnimalQuantity(String animalString, int animalQuantity){
        int maxQuantity = 0;
        switch(animalString){
            case "Rabbit":                                   maxQuantity = 12; break;
            case "Dog"   : case "Large Bird" :               maxQuantity =  2; break;
            case "Bird"  : case "Other":                     maxQuantity =  4; break;
            case "Cat"   :                                   maxQuantity =  3; break;

        }
        boolean tooManyAnimals = animalQuantity > maxQuantity;
        if(tooManyAnimals) for (RadioButton button : buttons) clearRadioButton(button);
        else{
            switch(animalString){
                case "Dog": case "Large Bird": maxQuantity = 1; break;
                case "Cat":                    maxQuantity = 2; break;
                case "Rabbit":                 maxQuantity = 4; break;
            }
            for (RadioButton button : buttons)
                if (button != bikeButton || !isPetVersion) {
                    int buttonIndex = Arrays.asList(buttons).indexOf(button);
                    boolean miniTooManyAnimals = animalString.matches("Dog|Cat|Large Bird|Rabbit") && animalQuantity > maxQuantity && buttonIndex > 1 || animalString.equals("Rabbit") && animalQuantity > 10 && buttonIndex > 0;
                    if (miniTooManyAnimals) clearRadioButton(button);
                    else button.setVisibility(View.VISIBLE);
                }
        }
        return tooManyAnimals ? maxQuantity : -1;
    }

    private void clearRadioButton(RadioButton radioButton){
        radioButton.setVisibility(View.GONE);
        if (radioButton.isChecked()) rg.clearCheck();
        if(rg.getCheckedRadioButtonId() == -1) {
            originalFragment.setNextPageButtonEnabled(false);
            originalFragment.setVehicleSpecs(0, 0, "", true);
        }
    }

    public void setRelistVehicleSize(String size){
        isRelist = true;
        this.size = size;
    }

    public void setRelistAnimalQuantity(String animalString, int animalQuantity){
        this.animalString = animalString;
        this.animalQuantity = animalQuantity;
    }
}