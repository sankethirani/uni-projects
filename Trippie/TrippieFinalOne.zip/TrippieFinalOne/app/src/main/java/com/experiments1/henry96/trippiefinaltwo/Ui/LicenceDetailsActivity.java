package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.Group;
import androidx.core.content.ContextCompat;

import com.experiments1.henry96.trippiefinaltwo.Fragment.GetPhotoUriFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment.VehicleDetailsFragment.createSpinnerAdapter;

public class LicenceDetailsActivity extends AppCompatActivity implements GetPhotoUriFragment.PhotoDialogListener {
    private EditText etLicenceNo, etIssueDate, etExpiryDate, etFrontLicence, etBackLicence, etLicenceOverlay;
    private Spinner etLicenceClass;
    private Driver driver;
    private Group uploadGroup, detailsGroup;
    private Button editButton;
    private TextView tvVerificationStatus;
    private Date issueDate, expiryDate;
    private Uri imageUri;
    private GetPhotoUriFragment dialog;
    private Map<String, Uri> uriMap;
    private  int numberOfAsyncTasks;
    FirebaseFirestore db;
    FirebaseAuth auth;
    FirebaseStorage storage;
    ProgressBar progressBar;

    public LicenceDetailsActivity() {
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_licence_info);
        initialiseLayout();
        uploadGroup.setVisibility(View.GONE);
        setOnClickListeners();
    }

    private void initialiseLayout() {
        etLicenceNo = findViewById(R.id.et_licence_no);
        etLicenceClass = findViewById(R.id.et_licence_class);
        etIssueDate = findViewById(R.id.et_issue_date);
        etExpiryDate = findViewById(R.id.et_expiry_date);
        etFrontLicence = findViewById(R.id.front_licence);
        etBackLicence = findViewById(R.id.back_licence);
        etLicenceOverlay = findViewById(R.id.etLicence);
        editButton = findViewById(R.id.edit_button);
        progressBar = findViewById(R.id.progressBar);

        tvVerificationStatus = findViewById(R.id.tv_verification_status);
        uploadGroup = findViewById(R.id.upload_licence_group);
        detailsGroup = findViewById(R.id.licence_details_group);

        // Set adapter for for class spinner
        String[] licenceClassList = getResources().getStringArray(R.array.driver_class);
        etLicenceClass.setAdapter(createSpinnerAdapter(this, licenceClassList));
        etLicenceClass.setEnabled(false);

        dialog = new GetPhotoUriFragment();
        dialog.isActivity = true;
        uriMap = new HashMap<>();


        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();

        DocumentReference ref = db.collection("drivers").document(auth.getCurrentUser().getUid());
        ref.get().addOnSuccessListener(documentSnapshot -> {
            driver = documentSnapshot.toObject(Driver.class);
            etLicenceNo.setText(driver.getLicenceNo());
            etLicenceOverlay.setText(driver.getLicenceClass());
            etLicenceClass.setSelection(Arrays.asList(licenceClassList).indexOf(driver.getLicenceClass()));
            String pattern = "MMMM dd, yyyy";
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
            Log.i("Issue Date", driver.getLicenceIssueDate().toString());
            etIssueDate.setText(dateFormat.format(driver.getLicenceIssueDate()));
            etExpiryDate.setText(dateFormat.format(driver.getLicenceExpiryDate()));
            tvVerificationStatus.setText(driver.isLicenceVerified() ? "Verified" : "Unverified");
            tvVerificationStatus.setTextColor(driver.isLicenceVerified() ? ContextCompat.getColor(this, R.color.text_colour_green) : ContextCompat.getColor(this, R.color.red_500));

            // save current dates
            issueDate = driver.getLicenceIssueDate();
            expiryDate = driver.getLicenceExpiryDate();
        });
    }

    private void setOnClickListeners() {
        editButton.setOnClickListener(c -> {
            if(editButton.getText().toString().toLowerCase().equals("edit")) {
                uploadGroup.setVisibility(View.VISIBLE);
                for(int id : detailsGroup.getReferencedIds()) {
                    findViewById(id).setEnabled(true);
                }
                etLicenceOverlay.setVisibility(View.GONE);
                etIssueDate.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_calendar, 0);
                etExpiryDate.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_calendar, 0);
                editButton.setText("Submit");
            } else {
                Helpers.showDialog(progressBar);
                uploadPhoto();
            }
        });

        // set selected item text to black
        etLicenceClass.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLACK);
                }
            }
            @Override public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        etIssueDate.setOnClickListener(c -> setDate((EditText) c));
        etExpiryDate.setOnClickListener(c -> setDate((EditText) c));

        etFrontLicence.setOnClickListener(view -> {
            dialog.viewId = R.id.front_licence;
            dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etBackLicence.setOnClickListener(view -> {
            dialog.viewId = R.id.back_licence;
            dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
        });

    }

    private void setDate(EditText et) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(Objects.requireNonNull(this), createOnDateListener(et), year, month, day);
        dialog.show();
    }

    // create new OnDateSetListener by supplying the text view you want to set
    private DatePickerDialog.OnDateSetListener createOnDateListener(EditText et) {


        return (DatePicker datePicker, int year, int month, int day) -> {
            String date = day + "/" + (month + 1) + "/" + year;


            // derive date from calendar data
            Calendar c = Calendar.getInstance();
            c.set(year, month, day);
            Date tempDate = c.getTime();

            if (et == etIssueDate) {
                Calendar d = Calendar.getInstance();
                d.setTime(Calendar.getInstance().getTime());
                if (tempDate.before(Calendar.getInstance().getTime()) || (d.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR))) {
                    Log.i("D Time", String.valueOf(d.get(Calendar.DAY_OF_YEAR)));
                    Log.i("C Time", String.valueOf(c.get(Calendar.DAY_OF_YEAR)));
                    issueDate = tempDate;
                    et.setText(date);
                } else {
                    Helpers.showToast(this, "Invalid issue date. Cannot be a future date.");
                    et.setText("");
                }
            }
            else if (tempDate.after(Calendar.getInstance().getTime())){
                if(et == etExpiryDate) expiryDate = tempDate;
                et.setText(date);
            }
            else{
                Helpers.showToast(this, "Invalid expiry date. Cannot be a past date.");
                et.setText("");
            }
        };
    }

    @Override
    public void getImagePath(Uri imagePath, int id) {
        imageUri = imagePath;
        String title = imagePath.getLastPathSegment();
        switch (id) {
            case R.id.front_licence:
                uriMap.put("frontLicence", imagePath);
                etFrontLicence.setText(title);
                break;
            case R.id.back_licence:
                uriMap.put("backLicence", imagePath);
                etBackLicence.setText(title);
                break;
        }
    }

    private void uploadPhoto() {

        StorageReference storageRef = storage.getReference();

        numberOfAsyncTasks = uriMap.size();

        for(Map.Entry<String, Uri> entry : uriMap.entrySet()) {
            String key = entry.getKey();
            Uri uri = entry.getValue();
            final StorageReference imageRef;

            switch(key){
                case "frontLicence": case "backLicence":  imageRef = storageRef.child("images/drivers/" + auth.getUid() + "/" + key);break;
                default: imageRef = null;
            }

            UploadTask uploadTask = Objects.requireNonNull(imageRef).putFile(uri);
            uploadTask.addOnSuccessListener(taskSnapshot -> {
                numberOfAsyncTasks--;
                if(numberOfAsyncTasks == 0) {
                    uploadDriver();
                }
            });
        }
    }

    private void uploadDriver() {
        DocumentReference userRef = db.collection("drivers").document(auth.getUid());
        userRef.update("licenceNo", etLicenceNo.getText().toString(),
                "licenceClass", etLicenceClass.getSelectedItem().toString(),
                "licenceIssueDate", issueDate,
                "licenceExpiryDate", expiryDate);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("You have successfully updated your licence details.")
                .setPositiveButton("Ok", (dialogInterface, i) -> {
                    Helpers.hideDialog(progressBar);
                    Objects.requireNonNull(this).finish();
                })
                .create()
                .show();
    }

    // creates adapter for dropdown views
    public static SpinnerAdapter createSpinnerAdapter(Context context, String[] list) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Objects.requireNonNull(context), R.layout.layout_spinner_item,list ) {
            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);

                return view;
            }

            @Override
            public boolean isEnabled(int position) {
                // disables hint
                return position != 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(R.id.tv_spinner);
                // do whatever you want with this text view
                textView.setTextSize(18);
                return view;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }
}
