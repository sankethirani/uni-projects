package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippieDetailFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippieOnTheWayFragment;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class ShowTrippiesInJobPageActivity extends AppCompatActivity implements TrippieOnTheWayFragment.OnTheWayOnClickListener {

    private String trippieId;
    private Fragment secondFragment;
    private Trippie trippie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_trippies_in_trippie_page);

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        trippieId = getIntent().getStringExtra("TrippieId");
        TrippieDetailFragment detailFragment = new TrippieDetailFragment(false);
        Bundle bundle = new Bundle();
        bundle.putString("TrippieId", trippieId);
        detailFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.linearContain, detailFragment);

        DocumentReference docRef = db.collection("trippies").document(trippieId);
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            trippie = documentSnapshot.toObject(Trippie.class);
            Bundle bundle1 = new Bundle();
            if (trippie.getStatus() != null) {
                secondFragment = new TrippieOnTheWayFragment();
                if (trippie.getStatusDetails() != null) {
                    bundle1.putString("TrippieId", trippieId);
                    bundle1.putString("define", "driver");
                }
            }
            secondFragment.setArguments(bundle1);
            fragmentTransaction.replace(R.id.linearTrippieDetail, secondFragment).commit();
        });
    }

    @Override
    public void onUpdateItemClick() {
        Intent showStatusIntent = new Intent(this, DeliveryStatusActivity.class);
        showStatusIntent.putExtra("TrippieId", trippieId);
        startActivity(showStatusIntent);
    }
}
