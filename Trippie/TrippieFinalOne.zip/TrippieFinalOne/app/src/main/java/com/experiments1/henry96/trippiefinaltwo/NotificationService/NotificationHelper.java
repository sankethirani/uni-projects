package com.experiments1.henry96.trippiefinaltwo.NotificationService;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.HomeActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInTrippiePageActivity;

class NotificationHelper {

    private static final String CHANNEL_ID = "Trippie_Project";
    private static final String CHANNEL_NAME = "Trippie Final";
    private static final String CHANNEL_DESC = "Trippie App Notifications";

    static void displayNotification(Context context, String title, String body, String trippieid, String type, long notificationId,String driverID) {

        //When click to notification
        Intent intent = null;
        intent = new Intent(context, HomeActivity.class);
        intent.setAction("Notification");
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 100, intent, PendingIntent.FLAG_CANCEL_CURRENT);

        //Acepted Button
        Intent yesIntent = new Intent(context, NotificationReceiver.class);
        int id = (int) notificationId;
        yesIntent.setAction("Accepted");
        yesIntent.putExtra("notificationId", id);
        yesIntent.putExtra("trippie", trippieid);
        yesIntent.putExtra("driverid", driverID);
        PendingIntent pendingIntentAccept = PendingIntent.getBroadcast(context, 100, yesIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        //View Offers Button
        Intent viewOfferIntent = new Intent(context, ShowTrippiesInTrippiePageActivity.class);
        viewOfferIntent.putExtra("TrippieId", trippieid);
        PendingIntent pendingIntentOffers = PendingIntent.getActivity(context, 100, viewOfferIntent, PendingIntent.FLAG_CANCEL_CURRENT);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(CHANNEL_DESC);
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

        if(type.equalsIgnoreCase(Helpers.Key_Trippie)){
//            mBuilder.addAction(android.R.drawable.stat_notify_more, "Accept", pendingIntentAccept);
            mBuilder.addAction(android.R.drawable.ic_notification_clear_all, "View Offers", pendingIntentOffers);
        }



        NotificationManagerCompat mNotificationMgr = NotificationManagerCompat.from(context);

        mNotificationMgr.notify(id, mBuilder.build());

    }

}
