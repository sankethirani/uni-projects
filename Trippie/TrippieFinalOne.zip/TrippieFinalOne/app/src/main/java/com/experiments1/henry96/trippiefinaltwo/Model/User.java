package com.experiments1.henry96.trippiefinaltwo.Model;


import com.experiments1.henry96.trippiefinaltwo.Fragment.UserTypeInterface;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

//17/09/2019 Henry Create User Class
public class User implements UserTypeInterface {
    private String userId, firstNm, lastNm, phone, image, token;
    private Date dateofbirth, createDate, lastActiveDate;
    private boolean status, isDriver;
    private double rating;
    private int numberOfRatings;
    private Address address;
    private Map<String, UserOfferDetail> listTrippieOffers;
    private String email;


    public User(String userId, String firstNm, String lastNm, Date dateofbirth, String phone, String image, Date createDate, Date lastActiveDate,
                boolean status, double rating, int numberOfRatings, boolean isDriver, Address address, String token, String email) {
        this.userId = userId;
        this.firstNm = firstNm;
        this.lastNm = lastNm;
        this.dateofbirth = dateofbirth;
        this.phone = phone;
        this.image = image;
        this.createDate = createDate;
        this.lastActiveDate = lastActiveDate;
        this.status = status;
        this.rating = rating;
        this.numberOfRatings = numberOfRatings;
        this.isDriver = isDriver;
        this.address = address;
        this.token = token;
        listTrippieOffers = new HashMap<>();
        this.email = email;

    }

    public User() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstNm() {
        return firstNm;
    }

    public void setFirstNm(String firstNm) {
        this.firstNm = firstNm;
    }

    public String getLastNm() {
        return lastNm;
    }

    public void setLastNm(String lastNm) {
        this.lastNm = lastNm;
    }

    public Date getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(Date dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLastActiveDate() {
        return lastActiveDate;
    }

    public void setLastActiveDate(Date lastActiveDate) {
        this.lastActiveDate = lastActiveDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public boolean isDriver() {
        return isDriver;
    }

    public void setDriver(boolean driver) {
        isDriver = driver;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Map<String, UserOfferDetail> getListTrippieOffers() {
        return listTrippieOffers;
    }

    public void setListTrippieOffers(Map<String, UserOfferDetail> listTrippieOffers) {
        this.listTrippieOffers = listTrippieOffers;
    }

    public int getNumberOfRatings() {
        return numberOfRatings;
    }

    public void setNumberOfRatings(int numberOfRatings) {
        this.numberOfRatings = numberOfRatings;
    }
}
