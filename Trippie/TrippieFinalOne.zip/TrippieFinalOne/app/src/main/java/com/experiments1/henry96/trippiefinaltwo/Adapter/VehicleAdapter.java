package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Model.Vehicle;
import com.experiments1.henry96.trippiefinaltwo.R;

import java.util.List;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.VehicleViewHolder> {
    private  List<Vehicle> vehicleList;

    // constructor
    public VehicleAdapter(List<Vehicle> vehicleList) {
        this.vehicleList = vehicleList;
    }

    public static class VehicleViewHolder extends RecyclerView.ViewHolder {
        private TextView tvMakeModel, tvRegistrationNo, tvColour, tvYear, tvBodyType;

        public VehicleViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMakeModel = itemView.findViewById(R.id.tv_make_model);
            tvRegistrationNo = itemView.findViewById(R.id.tv_registration_no);
            tvColour = itemView.findViewById(R.id.tv_colour);
            tvYear = itemView.findViewById(R.id.tv_year);
            tvBodyType = itemView.findViewById(R.id.tv_bodytype);
        }
    }

    @NonNull
    @Override
    public VehicleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_vehicle_item, parent, false);
        VehicleViewHolder vh = new VehicleViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull VehicleViewHolder holder, int position) {
        Vehicle currentVehicle = vehicleList.get(position);
        holder.tvMakeModel.setText(currentVehicle.getMake() + " " + currentVehicle.getModel());
        holder.tvBodyType.setText(currentVehicle.getBodyType());
        holder.tvColour.setText(currentVehicle.getColour());
        holder.tvRegistrationNo.setText(currentVehicle.getRegistrationNo());
        holder.tvYear.setText(String.valueOf(currentVehicle.getYear()));
    }

    @Override
    public int getItemCount() {
        return vehicleList.size();
    }


}
