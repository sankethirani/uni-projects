package com.experiments1.henry96.trippiefinaltwo.Fragment;


import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Custom_Trippie_Display_Adapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.NotificationService.NotificationInRetrofitIns;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.EditTrippieActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInTrippiePageActivity;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Source;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.FirebaseFunctionsException;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FragmentTrippies_Trippies extends Fragment {
    private static final String TAG = "FragmentTrippies_Tripie";
    private RecyclerView rvTrippies;
    private Custom_Trippie_Display_Adapter custom_trippie_display;
    private ArrayList<Trippie> trippies;

    private FirebaseFirestore db;
    private FirebaseFunctions mFunctions;

    private ListenerRegistration listenerRegistration;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_trippie_trippies, container, false);
        rvTrippies = v.findViewById(R.id.rvTrippies);
        db = FirebaseFirestore.getInstance();
        mFunctions = FirebaseFunctions.getInstance();
        return v;
    }


    @Override
    public void onStart() {
        super.onStart();
        trippies = new ArrayList<>();
        custom_trippie_display = new Custom_Trippie_Display_Adapter(trippies, getContext());
        rvTrippies.setLayoutManager(new LinearLayoutManager(getContext()));
        rvTrippies.setAdapter(custom_trippie_display);

        listenerRegistration = db.collection("trippies")
                .whereEqualTo("userId", FirebaseAuth.getInstance().getCurrentUser().getUid())
//                .whereEqualTo("active", true)
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    if (e != null) {
                        Log.d(TAG, e.toString());
                        return;
                    }
                    if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()) {
                        trippies.clear();
                        List<Trippie> trippielist = queryDocumentSnapshots.toObjects(Trippie.class);
                        Log.e(TAG, trippielist.size() + "");
                        for (Trippie item : trippielist) {
                            if (item.isActive()) {
                                trippies.add(item);
                            }
                        }
                        //do the reminder here
                        setOnClickToTrippieItem();
                        custom_trippie_display.notifyDataSetChanged();
                    } else {
                        Log.e(TAG, "Errors Happened");
                    }
                });
    }

    @Override
    public void onStop() {
        super.onStop();
        listenerRegistration.remove();
    }

    private void setOnClickToTrippieItem() {
        custom_trippie_display.setOnItemClickListener(new Custom_Trippie_Display_Adapter.OnItemClickListener() {
            @Override
            public void onItemEditClick(int position) {
                Trippie trippie = trippies.get(position);
                Intent sendToDisplayTrippieIntent = new Intent(getActivity(), ShowTrippiesInTrippiePageActivity.class);
                sendToDisplayTrippieIntent.putExtra("TrippieId", trippie.getTrippieId());
                sendToDisplayTrippieIntent.putExtra("expired", trippie.getExpiryTime() != null && trippie.getExpiryTime().compareTo(Timestamp.now().toDate()) < 0);
                startActivity(sendToDisplayTrippieIntent);
            }

            //Do your Relist here here!
            @Override
            public void onRelistCLick(int position) {
//                Helpers.showToast(getContext(), "onRelistCLick");
                Trippie trippie = trippies.get(position);
                Intent intent = new Intent(getContext(), CreateTrippieActivity.class);
                intent.putExtra("reList", true);
                addTrippieToIntentAndStart(trippie, intent);
            }

            //Do your cancel here!
            @Override
            public void onCancelCLick(int position) {
//                Helpers.showToast(getContext(), "onCancelCLick");
                Trippie trippie = trippies.get(position);

                new AlertDialog.Builder(getActivity())
                        .setTitle("Warning!")
                        .setMessage("Are you sure you want to cancel " + trippie.getTitle() + "?")

                        .setPositiveButton("Yes", (dialogInterface, i) -> cancelTrippie(trippie.getTrippieId())
                                .addOnSuccessListener(s -> {
                                            new AlertDialog.Builder(getActivity())
                                                    .setTitle("Punishment 😈")
                                                    .setMessage("Your punishment will be $" + Helpers.addTrailingZerosToCurrency((double)(Math.round(Double.parseDouble(s) * 100) / 100)) + "!").show();
                                            /*TODO: send notification on accepting price to Tripster so it will disable their ability to continue the Trippie*/
                                            sendRefundNotification(s, trippie);
                                        }
                                )
                        )
                        .setNegativeButton("No", null)
                        .create()
                        .show();
            }

            @Override
            public void onEditCLick(int position) {
                Trippie trippie = trippies.get(position);
                Intent intent = new Intent(getContext(), EditTrippieActivity.class);
                addTrippieToIntentAndStart(trippie, intent);
            }

            @Override
            public void onDeleteCLick(int position) {
//                Helpers.showToast(getContext(), "onDeleteCLick");
                Trippie trippie = trippies.get(position);
                new AlertDialog.Builder(getActivity())
                        .setTitle("Warning!")
                        .setMessage("Are you sure you want to delete " + trippie.getTitle() + "?")

                        .setPositiveButton("Yes", (dialogInterface, i) -> inActivetrippie(trippie))
                        .setNegativeButton("No", null)
                        .create()
                        .show();
            }
        });
    }


    private void sendRefundNotification(String refundPrice, Trippie trippie) {

        if(trippie.getDriverId() != null) {
            db.collection("users").document(trippie.getDriverId()).get().addOnSuccessListener(documentSnapshot -> {
                User driver = documentSnapshot.toObject(User.class);

                Helpers.showToast(getContext(), "Sending notification");
                String title = "Trippie Cancel";
                String body = "Uh-oh! The user has cancelled your Trippie!";
                if(Double.parseDouble(refundPrice) > 0) body += " You will receive " + Helpers.addTrailingZerosToCurrency((double)(Math.round(Double.parseDouble(refundPrice) * 100) / 100)) + " as compensation.";
                String trippieid_type_tname = trippie.getTrippieId() + "-@-" + Helpers.Key_Trippie_Refund + "-@-" + trippie.getTitle();
                String imageurl_driverid = trippie.getThumbnailUrl() + "-@-" + trippie.getDriverId();
                Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(driver.getToken(), title, body,
                        trippieid_type_tname, imageurl_driverid);


                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                        if (response.isSuccessful()) {
                            Helpers.showToast(getActivity(), "Notification has been sent!");
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                        Helpers.showToast(getActivity(), "Notification failed to send!");
                        Log.e(TAG, Objects.requireNonNull(t.getMessage()));
                    }
                });
            });
        }


    }

    private void addTrippieToIntentAndStart(Trippie trippie, Intent intent) {
        Gson gson = new Gson();
        String trippieJson = gson.toJson(trippie);
        intent.putExtra("trippie", trippieJson);
        startActivity(intent);
    }

    private void inActivetrippie(Trippie trippie) {

        deleteTrippie(trippie.getTrippieId()).addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Exception e = task.getException();
                if (e instanceof FirebaseFunctionsException) {
                    FirebaseFunctionsException ffe = (FirebaseFunctionsException) e;
                    FirebaseFunctionsException.Code code = ffe.getCode();
                    Object details = ffe.getDetails();
                    Log.d("error", code + " " + details);
                }
            }
            else{
                custom_trippie_display.notifyDataSetChanged();
            }
        });
    }

    private Task<String> cancelTrippie(String trippieId) {
        return cancel(trippieId).addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Exception e = task.getException();
                if (e instanceof FirebaseFunctionsException) {
                    FirebaseFunctionsException ffe = (FirebaseFunctionsException) e;
                    FirebaseFunctionsException.Code code = ffe.getCode();
                    Object details = ffe.getDetails();
                    Log.d("error", code + " " + details);
                }
            }
        });
    }

    private Task<String> deleteTrippie(String trippieId) {
        // Create the arguments to the callable function.
        Map<String, Object> data = new HashMap<>();
        data.put("trippieId", trippieId);
        data.put("makeInactive", true);

        return mFunctions
                .getHttpsCallable("auth")
                .call(data)
                .continueWith(task -> (String) Objects.requireNonNull(task.getResult()).getData());
    }

    private Task<String> cancel(String trippieId) {
        // Create the arguments to the callable function.
        Map<String, Object> data = new HashMap<>();
        data.put("trippieId", trippieId);
        data.put("makeInactive", true);

        return mFunctions
                .getHttpsCallable("cancellation")
                .call(data)
                .continueWith(task -> String.valueOf(((Map) Objects.requireNonNull(Objects.requireNonNull(task.getResult()).getData())).get("punishment")));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
}



