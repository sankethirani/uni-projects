package com.experiments1.henry96.trippiefinaltwo.Ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.VehicleAdapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.Model.Vehicle;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class VehicleDetailsActivity extends AppCompatActivity {
    private RecyclerView mRecycleView;
    private RecyclerView.Adapter mAdapter;
    private ImageView addButton;
    private RecyclerView.LayoutManager mLayoutManager;
    private List<Vehicle> vehicleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_details);

        addButton = findViewById(R.id.addButton);

        mRecycleView = findViewById(R.id.recycler_view);
        mRecycleView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        getVehicleList();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(vehicleList.size() == 3) {
                    Helpers.showToast(getApplicationContext(),"Sorry, you can only register up to three vehicles.");
                } else {
                    Intent intent = new Intent(getApplicationContext(), AddVehicleActivity.class);
                    startActivity(intent);
                }
            }
        });

    }

    private void getVehicleList() {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        DocumentReference ref = db.collection("drivers").document(auth.getCurrentUser().getUid());
        ref.get().addOnSuccessListener(documentSnapshot -> {
            Driver driver = documentSnapshot.toObject(Driver.class);
            vehicleList = new ArrayList<>();
            if(driver.getVehicleList() != null) {
                for(Map.Entry<String, Vehicle> entry : driver.getVehicleList().entrySet()) {
                    vehicleList.add(entry.getValue());
                }
            } else {
                Helpers.showToast(getApplicationContext(), "You currently don't have a vehicle registered.");
            }


            // set recycler view adapter
            mAdapter = new VehicleAdapter(vehicleList);
            mRecycleView.setLayoutManager(mLayoutManager);
            mRecycleView.setAdapter(mAdapter);
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        // refresh the screen to show new vehicles
        getVehicleList();
    }

}
