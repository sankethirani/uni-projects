package com.experiments1.henry96.trippiefinaltwo.LocalDb;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Notification.class}, version = 2, exportSchema = false)
public abstract class LocalDatabase extends RoomDatabase {
    public abstract NotificationDao notificationDao();

    public static LocalDatabase daInstance;

    public static synchronized LocalDatabase getInstance(Context context) {
        if (daInstance == null) {
            daInstance = Room.databaseBuilder(context.getApplicationContext(), LocalDatabase.class, "NotificationDB")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return daInstance;
    }
}
