package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Viewpager_slider_Adapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.Slider;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.maps.android.PolyUtil;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class TrippieDetailFragment extends Fragment implements OnMapReadyCallback {

    private static final String TAG = "trippieDetailFragment";
    private GoogleMap mMap;
    private Viewpager_slider_Adapter viewpager_slider_adapter;
    private ArrayList<Slider> sliders;
    private View v;
    private Trippie trippie;
    private TextView tvTitle, tvDescription, tvPrice, tvPickupPlace, tvDestination, tvDistance, tvPickupDate,
            tvDeliveryDate, tvSize, tvOffer, tvCurrency, optionalText, tvPriceLabel;
    private boolean isPreview, trippieExpired;
    private EditText editOfferPrice;
    private DateFormat dateFormat;
    private RelativeLayout optionalLayout;
    private ShimmerFrameLayout shimmerFrameLayout;
    private Button optionalButton;

    public TrippieDetailFragment(boolean isPreview) {
        this.isPreview = isPreview;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        try {
            v = inflater.inflate(R.layout.fragment_trippie_info, container, false);
            init(v);
            initSliders(v);
            SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            if (mapFragment == null) {
                FragmentManager fm = getFragmentManager();
                assert fm != null;
                FragmentTransaction ft = fm.beginTransaction();
                mapFragment = SupportMapFragment.newInstance();
                ft.replace(R.id.details_map, mapFragment).commit();
            }
            mapFragment.getMapAsync(this);
        } catch (InflateException ex) {
            Log.e("tag", Objects.requireNonNull(ex.getMessage()));
        }

        return v;
    }

    private void initSliders(View view) {
        sliders = new ArrayList<>();
        viewpager_slider_adapter = new Viewpager_slider_Adapter(getContext(), sliders);
        viewpager_slider_adapter.setIsPreview(isPreview);
        ((ViewPager) view.findViewById(R.id.viewpager)).setAdapter(viewpager_slider_adapter);
    }

    private void init(View v) {
        shimmerFrameLayout = v.findViewById(R.id.shimmer_layout);
        editOfferPrice = v.findViewById(R.id.editOfferPrice);
        tvTitle = v.findViewById(R.id.tvTrippieTitle);
        tvDeliveryDate = v.findViewById(R.id.tvDeliveryDate);
        tvDescription = v.findViewById(R.id.tvDescription);
        tvDestination = v.findViewById(R.id.tvDestination);
        tvCurrency = v.findViewById(R.id.tvCurrency);
        tvDistance = v.findViewById(R.id.tvDistance);
        tvPickupDate = v.findViewById(R.id.tvPickupDate);
        tvPickupPlace = v.findViewById(R.id.tvPickupPlace);
        tvPrice = v.findViewById(R.id.tvTrippiePrice);
        tvSize = v.findViewById(R.id.tvSize);
        optionalText = v.findViewById(R.id.optional_text);
        optionalLayout = v.findViewById(R.id.optional_layout);
        optionalButton = v.findViewById(R.id.optional_button);
        tvOffer = v.findViewById(R.id.tvOffer);
        tvPriceLabel = v.findViewById(R.id.tvpricelabel);

//            case Configuration.SCREENLAYOUT_SIZE_NORMAL:
//            case Configuration.SCREENLAYOUT_SIZE_SMALL:

//        int screenSize = getResources().getConfiguration().screenLayout &
//                Configuration.SCREENLAYOUT_SIZE_MASK;
//        switch (screenSize) {
//            case Configuration.SCREENLAYOUT_SIZE_LARGE:
//            case Configuration.SCREENLAYOUT_SIZE_SMALL:
//                tvPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
//                break;
//            default:
//                changeTextViewSize(20);
//        }


        dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
        if (!isPreview) loadFromDatabase();

        for (TextView textView : new TextView[]{tvPickupPlace, tvDestination}) {
            textView.setHorizontallyScrolling(true);
            textView.setClickable(true);
            textView.setSelected(true);
            textView.setMarqueeRepeatLimit(-1);
        }
    }

    private void changeTextViewSize(int size) {
        tvPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        tvOffer.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        tvPriceLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        editOfferPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
    }

    private void loadFromDatabase() {


        if (getArguments() != null) {

            String id = getArguments().getString("TrippieId");


            FirebaseFirestore db = FirebaseFirestore.getInstance();

            assert id != null;
            DocumentReference docRef = db.collection("trippies").document(id);
            docRef.get().addOnSuccessListener(documentSnapshot -> {
                trippie = documentSnapshot.toObject(Trippie.class);
                if (trippie != null) {
//                    editOfferPrice.setText(String.format(getResources().getString(R.string.currency), String.valueOf(Helpers.addTrailingZerosToCurrency(trippie.getPrice()))));
                    editOfferPrice.setText(String.valueOf(Helpers.addTrailingZerosToCurrency(trippie.getPrice())));
                    showMap(trippie);
                    if (trippie.getListingImage().size() > 0) {
                        Log.e(TAG, "Got Trippie and image got size");
                        for (String link : trippie.getListingImage()) {
                            sliders.add(new Slider("temp.", link));
                            Log.e(TAG, link);
                        }
                    }
                    showCommonTrippieFields(trippie);

                    boolean isCurrentUserTrippieCreator = trippie.getUserId().equals(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());

                    trippieExpired = (trippie.getExpiryTime() != null && trippie.getExpiryTime().compareTo(Timestamp.now().toDate()) < 0);

                    if (trippieExpired && isCurrentUserTrippieCreator) {
                        optionalLayout.setVisibility(View.VISIBLE);
                        optionalButton.setOnClickListener(c -> {
                            Intent intent = new Intent(Objects.requireNonNull(getActivity()).getApplication(), CreateTrippieActivity.class);
                            intent.putExtra("reList", true);
                            Gson gson = new Gson();
                            String trippieJson = gson.toJson(trippie);
                            intent.putExtra("trippie", trippieJson);
                            startActivity(intent);
                        });
                    }

                    String action = getArguments().getString("Action");

                    if (!isCurrentUserTrippieCreator) {
                        if (action != null && action.equalsIgnoreCase("DriverOffer") && !trippieExpired) {
                            editOfferPrice.setVisibility(View.VISIBLE);
                            tvOffer.setVisibility(View.VISIBLE);
                            tvCurrency.setVisibility(View.VISIBLE);

                            String driverId = getArguments().getString("driverID");

                            if (driverId != null && trippie.getOffers() != null && trippie.getOffers().get(driverId) != null) {
                                String driverofferPrice = trippie.getOffers().get(driverId).getPrice().toString();
                                editOfferPrice.setText(driverofferPrice);
                            }
                        }
                    }
                    if (trippie.getStatus() == Trippie.Status.delivered) {
                        String createdTime = Objects.requireNonNull(trippie.getStatusDetails().get("delivered")).getCreatedTime();
                        try {
                            Date tempDate = dateFormat.parse(createdTime);
                            Calendar c = Calendar.getInstance();
                            assert tempDate != null;
                            c.setTime(tempDate);
                            c.add(Calendar.DAY_OF_YEAR, 7);
                            if (c.after(Calendar.getInstance()) && (isCurrentUserTrippieCreator && !trippie.getDriverHasBeenRated() || !isCurrentUserTrippieCreator && !trippie.getUserHasBeenRated())) {
                                db.collection("users").document(isCurrentUserTrippieCreator ? trippie.getDriverId() : trippie.getUserId()).get().addOnSuccessListener(snapshot -> {
                                    User target = snapshot.toObject(User.class);
                                    optionalButton.setText(getResources().getString(R.string.rate_button));
                                    optionalButton.setOnClickListener(v -> {
                                        RatingsDialogFragment ratingsDialogFragment = new RatingsDialogFragment(target, isCurrentUserTrippieCreator, trippie.getTrippieId());
                                        ratingsDialogFragment.setCancelable(false);
                                        ratingsDialogFragment.showNow(getChildFragmentManager(), "rating");
                                    });
                                    optionalText.setText(String.format(getResources().getString(R.string.rate_user_in_details_page), Objects.requireNonNull(target).getFirstNm()));
                                    optionalLayout.setVisibility(View.VISIBLE);
                                });
                            }
                        } catch (ParseException p) {
                            Helpers.showToast(getContext(), "Error parsing date result from database!");
                        }
                    }


                }
            });

        }
    }

    private BitmapDescriptor getMarkerIconFromDrawable(Drawable drawable) {
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void showMap(Trippie t) {
        int pickupDrawable;

        pickupDrawable = t.getFeatured() ? t.getUrgent() ? R.drawable.ic_urgentpin : R.drawable.ic_featuredpin2 : R.drawable.ic_pickuppin;

        LatLng pickup = new LatLng(t.getPickupLocation().getLatitude(), t.getPickupLocation().getLongitude());
        LatLng destination = new LatLng(t.getDeliveryLocation().getLatitude(), t.getDeliveryLocation().getLongitude());

        Context context = getContext();
        if (context != null) {
            mMap.addMarker(new MarkerOptions().position(pickup).icon(getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context, pickupDrawable)))));
            mMap.addMarker(new MarkerOptions().position(destination).icon(getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context, R.drawable.ic_dropoffpin)))));
        }

        PolylineOptions route = new PolylineOptions();
        List<LatLng> points = PolyUtil.decode(t.getPolyline());
        route.addAll(points);
        route.color(ContextCompat.getColor(Objects.requireNonNull(getContext()), R.color.main_colour_blue)).width(7);
        mMap.addPolyline(route);

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for (LatLng point : points) builder.include(point);

        LatLngBounds bounds = builder.build();

        FrameLayout maps = v.findViewById(R.id.details_map);

        int width = maps.getWidth();
        int height = maps.getHeight();
        int padding = (int) (height * 0.20);
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding));

        mMap.setOnMarkerClickListener(marker -> false);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setScrollGesturesEnabled(true);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.getUiSettings().setMapToolbarEnabled(false);

        //restrict the user to zoom out to a maximum of showing the whole country
        mMap.setMinZoomPreference(3.4f);

        //restrict the user to only move the map within the New Zealand region
        LatLng nzNorthEastBounds = new LatLng(-34.36, -175.81);
        LatLng nzSouthWestBounds = new LatLng(-47.35, 166.28);
        LatLngBounds nzBounds = new LatLngBounds(nzSouthWestBounds, nzNorthEastBounds);
        mMap.setLatLngBoundsForCameraTarget(nzBounds);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    void previewDetailsBeforeCreation(Trippie t, List<Uri> listingImageUris) {
        sliders.clear();
        for (Uri listingImageUri : listingImageUris)
            sliders.add(new Slider("22.", listingImageUri.toString()));
        showCommonTrippieFields(t);
    }

    private void showCommonTrippieFields(Trippie t) {
        shimmerFrameLayout.hideShimmer();
        tvTitle.setBackground(null);
        tvTitle.setText(t.getTitle());
        tvDeliveryDate.setBackground(null);
        tvDeliveryDate.setText(dateFormat.format(t.getDeliveryTime()));
        tvDescription.setBackground(null);
        tvDescription.setText(t.getDescription());
        tvDistance.setBackground(null);
        tvDistance.setText(t.getDistanceText());
        tvPickupDate.setBackground(null);
        tvPickupDate.setText(dateFormat.format(t.getPickupTime()));
        tvPickupPlace.setBackground(null);
        tvPickupPlace.setText(t.getPickupAddress().replace(", New Zealand", ""));
        tvDestination.setBackground(null);
        tvDestination.setText(t.getDeliveryAddress().replace(", New Zealand", ""));
        tvPrice.setBackground(null);
        tvPrice.setText(String.format(getResources().getString(R.string.currency), Helpers.addTrailingZerosToCurrency(t.getPrice())));
        tvSize.setBackground(null);
        tvSize.setText(t.getSize());
        editOfferPrice.setBackground(null);
        viewpager_slider_adapter.notifyDataSetChanged();
    }

    public double getOfferPrice() {
        String formattedString = editOfferPrice.getText().toString().replace("$", "");
        return formattedString.isEmpty() ? 0 : Double.parseDouble(formattedString);
    }

    public void setofferPrice(double price) {
        editOfferPrice.setText("king");
    }

    public String getImageUrl() {
        return trippie.getThumbnailUrl();
    }

    public String getTrippieName() {
        return trippie.getTitle();
    }

    void refreshMapAfterPolyline(Trippie t) {
        showMap(t);
    }

    public double getTrippieDefaultPrice() {
        return trippie.getPrice();
    }

    public String getTrippieTitle() {
        if (trippie != null) {
            return trippie.getTitle();
        }
        return "";
    }
}
