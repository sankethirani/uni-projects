package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.experiments1.henry96.trippiefinaltwo.Model.MapClusterMarker;
import com.experiments1.henry96.trippiefinaltwo.Model.MapClusterRenderer;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesDetailActivity;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.maps.android.MarkerManager;
import com.google.maps.android.PolyUtil;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class HomeFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private View v;

    private BitmapDescriptor pickupIcon, deliveryIcon, featuredIcon, urgentIcon, featuredUrgentIcon;

    private FirebaseFirestore db;
    private List<Trippie> trippies;
    private List<ClusterManager<MapClusterMarker>> clusterManagerList;
    private LatLngBounds.Builder builder;
    private boolean[] clusterMarkersProcessed;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Map<String, ?> cached;
    private boolean firstLoad = true, imagesLoaded = false;
    private RelativeLayout loadingCircle;

    private Trippie chosenTrippie;
    private Cluster<MapClusterMarker> clickedCluster;
    private ImageView image;
    private final List<ImageView> imageViews = new ArrayList<>();
    private float clickedXPosition, clickedYPosition;
    private ShimmerFrameLayout shimmerFrameLayout;
    private FloatingActionButton fab;
    private int pickupColour;

    private Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        sharedPreferences = Objects.requireNonNull(getContext()).getApplicationContext().getSharedPreferences("cachedTrippies", Context.MODE_PRIVATE);

        cached = sharedPreferences.getAll();

        try {
            int resourceID = R.layout.activity_maps;
            v = inflater.inflate(resourceID, container, false);
            SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            if (mapFragment == null) {
                FragmentManager fm = getFragmentManager();
                assert fm != null;
                FragmentTransaction ft = fm.beginTransaction();
                mapFragment = SupportMapFragment.newInstance();
                ft.replace(R.id.map, mapFragment).commit();
                db = FirebaseFirestore.getInstance();
            }
            mapFragment.getMapAsync(this);
        } catch (InflateException ex) {
            Log.e("tag", Objects.requireNonNull(ex.getMessage()));
        }
        return v;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        FrameLayout maps = v.findViewById(R.id.map);
        LayoutInflater li = LayoutInflater.from(getContext());
        if(loadingCircle == null || maps.indexOfChild(loadingCircle) == -1) {
            loadingCircle = (RelativeLayout) li.inflate(R.layout.loading_circle, (ViewGroup) maps.getParent(), false);
            maps.addView(loadingCircle);
        }
        else loadingCircle.setVisibility(View.VISIBLE);

        image = v.findViewById(R.id.listing_image);
        shimmerFrameLayout = v.findViewById(R.id.shimmer_view_container);
        trippies = new ArrayList<>();
        editor = sharedPreferences.edit();
        Gson gson = new Gson();

        CollectionReference trippiesRef = db.collection("trippies");

        db.collection("lists").document("trippiesList").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<String> activeTrippieIds = new ArrayList<>();
                Object temp1 = Objects.requireNonNull(task.getResult()).get("activeTrippies");
                if (temp1 instanceof List) for (Object v : ((List<?>) temp1))  activeTrippieIds.add(v.toString());

                if(!cached.isEmpty()) {
                    for (String key : cached.keySet()) {
                        if (activeTrippieIds.isEmpty() || !Objects.requireNonNull(activeTrippieIds).contains(key)) {   //check if cached trippie is still active, if not then remove it
                            editor.remove(key);
                            editor.apply();
                        } else
                            trippies.add(gson.fromJson(Objects.requireNonNull(cached.get(key)).toString(), Trippie.class));
                    }
                }

                if (!Objects.requireNonNull(activeTrippieIds).isEmpty()) {
                    Map<String, Boolean> trippiesDownloaded = new HashMap<>();
                    boolean newTrippies = false;
                    for(String id : activeTrippieIds){ //download new trippies in active trippie list
                        if(!cached.containsKey(id)){
                            newTrippies = true;
                            trippiesDownloaded.put(id,false);
                            trippiesRef.document(id).get().addOnSuccessListener(documentSnapshot -> {
                                Trippie t = documentSnapshot.toObject(Trippie.class);
                                trippies.add(t);
                                trippiesDownloaded.put(id,true);

                                String json = gson.toJson(t);
                                editor.putString(id, json); //save trippie in cache
                                editor.apply();


                                boolean allDownloaded = true;
                                for(boolean b : trippiesDownloaded.values()) if(!b) allDownloaded = false;
                                if(allDownloaded) showPickupLocations();
                            });
                        }
                    }
                    if (!newTrippies) showPickupLocations();
                }
                else showPickupLocations();
            }
        });


        if(getContext() != null) context = getContext();
        assert context != null;
        deliveryIcon = getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context, R.drawable.ic_dropoffpin)));
        pickupIcon = getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context, R.drawable.ic_pickuppin)));
        featuredIcon = getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context, R.drawable.ic_featuredpin2)));
        urgentIcon = getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context,R.drawable.ic_urgentpin)));
        featuredUrgentIcon = getMarkerIconFromDrawable(Objects.requireNonNull(ContextCompat.getDrawable(context,R.drawable.ic_featuredurgentcombinedpin)));

        if(fab == null) {
            fab = (FloatingActionButton) li.inflate(R.layout.myfab, (ViewGroup) maps.getParent(), false);
            FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
            flp.setMargins(0, 0, 50, 50);
            fab.setLayoutParams(flp);
            fab.setOnClickListener(view -> goToPriceEstimate());
            fab.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(Objects.requireNonNull(getContext()), R.color.main_colour_blue)));

            maps.addView(fab);
        }
        else {
            fab.setEnabled(true);
        }

        mMap = googleMap;
        mMap.clear();

        //center camera on Kahurangi National Park while we wait for the database to send us all the Trippies
        final LatLng kahurangiNationalPark = new LatLng(-40.787640, 172.595176);
        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(CameraPosition.builder().target(kahurangiNationalPark).build()));

        mMap.getUiSettings().setMapToolbarEnabled(false);

        //restrict the user to zoom out to a maximum of showing the whole country
        mMap.setMinZoomPreference(5.4f);

        //restrict the user to only move the map within the New Zealand region
        LatLng nzNorthEastBounds = new LatLng(-34.36, -175.81);
        LatLng nzSouthWestBounds = new LatLng(-47.35, 166.28);
        LatLngBounds nzBounds = new LatLngBounds(nzSouthWestBounds, nzNorthEastBounds);
        mMap.setLatLngBoundsForCameraTarget(nzBounds);
        mMap.setOnMapClickListener(c -> imagesLoaded = false);
    }

    @Override
    public void onResume() {
        if (!firstLoad) { //when returning from the trippie creation
            image.setImageBitmap(null);
            imagesLoaded = false;
            mMap.clear();
            v.findViewById(R.id.overlay).setVisibility(View.GONE);
            v.findViewById(R.id.map).getLayoutParams().height = -1;
            onMapReady(mMap);
        } else firstLoad = false;
        super.onResume();
    }

    private void showPickupLocations() {
        loadingCircle.setVisibility(View.INVISIBLE);

        if(!trippies.isEmpty()){
            List<Trippie> trippiesCopy = new ArrayList<>(trippies);
            for(Trippie t : trippiesCopy) if(t.getUserId().equals(FirebaseAuth.getInstance().getUid())) trippies.remove(t);
        }

        if (!trippies.isEmpty()) {

            mMap.clear();

            clusterManagerList = new ArrayList<>();
            MarkerManager markerManager = new MarkerManager(mMap);
            mMap.setInfoWindowAdapter(markerManager);

            clusterMarkersProcessed = new boolean[trippies.size()];
            for(int i = 0; i < clusterMarkersProcessed.length; i++) clusterMarkersProcessed[i] = false;

            builder = new LatLngBounds.Builder();

            for(int markerId = 0; markerId < trippies.size(); markerId++){
                if(!clusterMarkersProcessed[markerId]){
                    ClusterManager<MapClusterMarker> clusterManager = new ClusterManager<>(Objects.requireNonNull(getContext()),mMap,markerManager);
                    clusterManagerList.add(clusterManager);
                    clusterManager.setRenderer(new MapClusterRenderer(getContext(),mMap,clusterManager));
                    clusterManager.getClusterMarkerCollection().setOnInfoWindowAdapter(new CustomMarkerInfoWindow());
                    clusterManager.onCameraIdle();
                    int index = clusterManagerList.size() - 1;
                    Trippie trip = trippies.get(markerId);
                    addPickupTrippie(trip,markerId,index);

                    for(int tempMarkerId = markerId + 1; tempMarkerId < trippies.size(); tempMarkerId++){
                        float[] distance = new float[1];
                        Trippie tempTrippie = trippies.get(tempMarkerId);
                        Location.distanceBetween(trip.getPickupLocation().getLatitude(),trip.getPickupLocation().getLongitude(),tempTrippie.getPickupLocation().getLatitude(),tempTrippie.getPickupLocation().getLongitude(),distance);

                        if(distance[0] < 500) addPickupTrippie(tempTrippie,tempMarkerId,index);
                    }
                    clusterManager.cluster();
                    clusterManager.setOnClusterClickListener(cluster -> {
                        clickedCluster = cluster;
                        return false;
                    });
                    clusterManager.setOnClusterItemClickListener(mapClusterMarker -> {
                        for(ClusterManager manager : clusterManagerList) manager.clearItems();
                        showDistanceLine(Integer.parseInt(mapClusterMarker.getTitle()));
                        return true;
                    });
                }
            }

            mMap.setOnCameraIdleListener(() -> { for(ClusterManager clusterManager : clusterManagerList) clusterManager.onCameraIdle(); });
            mMap.setOnMarkerClickListener(markerManager);

            LatLngBounds bounds = builder.build();

            int width = getResources().getDisplayMetrics().widthPixels;
            int height = getResources().getDisplayMetrics().heightPixels;
            int padding = (int) (width * 0.40);
            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding));
        }
    }

    class CustomMarkerInfoWindow implements GoogleMap.InfoWindowAdapter{

        private final View clusterView;

        @SuppressLint("InflateParams")
        CustomMarkerInfoWindow(){
            clusterView = getLayoutInflater().inflate(R.layout.custom_marker_info_window_view,null);
        }

        @Override
        public View getInfoContents(Marker marker){
            if(clickedCluster != null && !imagesLoaded){
                StorageReference sr = FirebaseStorage.getInstance().getReference();
                ((LinearLayout)clusterView).removeAllViews();
                List<MapClusterMarker> featuredAndUrgent = new ArrayList<>(), normal = new ArrayList<>(), sortedList = new ArrayList<>();

                for(MapClusterMarker m : clickedCluster.getItems()){
                    Trippie currentTrippie = trippies.get(Integer.parseInt(m.getTitle()));
                    if((currentTrippie.getUrgent() != null && currentTrippie.getUrgent()) ||  currentTrippie.getFeatured()) featuredAndUrgent.add(m);
                    else normal.add(m);
                }

                sortedList.addAll(featuredAndUrgent);
                sortedList.addAll(normal);

                for(MapClusterMarker m : sortedList) {
                    imagesLoaded = true;
                    RelativeLayout ll = (RelativeLayout) getLayoutInflater().inflate(R.layout.info_window_trippie_item_layout, (ViewGroup) clusterView, false);
                    Trippie currentTrippie = trippies.get(Integer.parseInt(m.getTitle()));
                    TextView title = ll.findViewById(R.id.trippie_title_list_item), pickup = ll.findViewById(R.id.trippie_pickup_list_item);
                    if(currentTrippie.getFeatured()) {
                        ((ImageView) ll.findViewById(R.id.sash_container)).setImageDrawable(ContextCompat.getDrawable(context, (currentTrippie.getUrgent() != null && currentTrippie.getUrgent()) ? R.drawable.ic_urgentribbon : R.drawable.ic_featuredribbon));
                        int pickupColour = ContextCompat.getColor(context, currentTrippie.getUrgent() ? R.color.urgent_colour : R.color.featured_colour);
                        pickup.setTextColor(pickupColour);
                    }
                    title.setText(currentTrippie.getTitle());
                    pickup.setText(currentTrippie.getPickupAddress().replace(", New Zealand", ""));
                    ((TextView) ll.findViewById(R.id.trippie_destination_list_item)).setText(currentTrippie.getDeliveryAddress().replace(", New Zealand", ""));
                    ImageView image = ll.findViewById(R.id.trippie_image_list_item);
                    imageViews.add(image); final int position = imageViews.size() - 1;
                    sr.child("images/trippies/" + currentTrippie.getThumbnailUrl()).getDownloadUrl().addOnSuccessListener(uri -> {
                        Picasso picasso = new Picasso.Builder(Objects.requireNonNull(getContext())).listener((picasso1, uri1, e) -> e.printStackTrace()).build();
                        picasso.load(uri.toString()).noFade().into(imageViews.get(position), new MarkerCallback(marker));
                    });
                    ((ViewGroup) clusterView).addView(ll);

                    v.findViewById(R.id.map_handler).setOnTouchListener((view, motionEvent) -> {
                        view.performClick();
                        clickedYPosition = motionEvent.getRawY();
                        clickedXPosition = motionEvent.getRawX();
                        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN && marker.isInfoWindowShown()) {
                            Point newMarkerLocation = mMap.getProjection().toScreenLocation(clickedCluster.getPosition());
                            int windowX = newMarkerLocation.x - clusterView.getWidth()/2, windowY = newMarkerLocation.y - clusterView.getHeight() - (50 * (int) getResources().getDisplayMetrics().density);
                            int[] infoWindowCoordinates = new int[]{windowX,windowY, windowX + clusterView.getWidth(), windowY + clusterView.getHeight()};
                            if(infoWindowCoordinates[0] < clickedXPosition && clickedXPosition < infoWindowCoordinates[2] && infoWindowCoordinates[1] < clickedYPosition && clickedYPosition < infoWindowCoordinates[3]){
                                int clickedItem = (int) Math.floor((clickedYPosition - infoWindowCoordinates[1]) / clusterView.getHeight() * clickedCluster.getSize());
                                //goToDetails(trippies.get(Integer.parseInt(((MapClusterMarker)clickedCluster.getItems().toArray()[clickedItem]).getTitle())));
                                showDistanceLine(Integer.parseInt((sortedList.get(clickedItem)).getTitle()));
                                return true;
                            }
                        }
                        return false;
                    });
                }
            }
            return clusterView;
        }

        @Override
        public View getInfoWindow(Marker marker){
            return null;
        }
    }

    class MarkerCallback implements Callback {
        Marker marker;

        MarkerCallback(Marker marker) {
            this.marker = marker;
        }

        @Override
        public void onError(Exception ex) {
            Log.e(getClass().getSimpleName(), "Error loading thumbnail!");
        }

        @Override
        public void onSuccess() {
            if (marker != null && marker.isInfoWindowShown()) {
                marker.hideInfoWindow();
                marker.showInfoWindow();
            }
        }
    }

    private void addPickupTrippie(Trippie trip, int markerId, int index){
        LatLng pickupLocation = new LatLng(trip.getPickupLocation().getLatitude(), trip.getPickupLocation().getLongitude());


        MapClusterMarker marker = new MapClusterMarker(new MarkerOptions().position(pickupLocation).icon(getIconChoice(trip)).title(String.valueOf(markerId)));
        builder.include(pickupLocation);
        clusterManagerList.get(index).addItem(marker);
        clusterMarkersProcessed[markerId] = true;
    }

    private BitmapDescriptor getIconChoice(Trippie trippie){
        if(trippie.getFeatured()){
            return trippie.getUrgent() ? urgentIcon : featuredIcon;
        }
        return pickupIcon;
    }

    @SuppressLint("SetTextI18n")
    private void showDistanceLine(int chosenID) {
        mMap.clear();

        chosenTrippie = trippies.get(chosenID);

        LatLng pickupLocation = new LatLng(chosenTrippie.getPickupLocation().getLatitude(), chosenTrippie.getPickupLocation().getLongitude());
        LatLng deliveryLocation = new LatLng(chosenTrippie.getDeliveryLocation().getLatitude(), chosenTrippie.getDeliveryLocation().getLongitude());

        mMap.addMarker(new MarkerOptions().position(deliveryLocation).icon(deliveryIcon));
        mMap.addMarker(new MarkerOptions().position(pickupLocation).icon(getIconChoice(chosenTrippie)));

        TextView price = v.findViewById(R.id.trippie_price);
        TextView title = v.findViewById(R.id.trippie_title);
        TextView size = v.findViewById(R.id.trippie_size);
        TextView pickupText = v.findViewById(R.id.trippie_pickup);
        TextView destinationText = v.findViewById(R.id.trippie_destination);
        TextView pickupDate = v.findViewById(R.id.trippie_pickup_date);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference sr = storage.getReference();
        image.setBackgroundColor(Color.parseColor("#dddddd"));
        shimmerFrameLayout.showShimmer(true);
        sr.child("images/trippies/" + chosenTrippie.getThumbnailUrl()).getDownloadUrl().addOnSuccessListener(uri -> Picasso.get().load(uri).into(image, new Callback() {
            @Override
            public void onSuccess() {
                image.setBackgroundColor(Color.WHITE);
                shimmerFrameLayout.hideShimmer();
            }

            @Override public void onError(Exception e) {}
        }));

        int pickupColour = ContextCompat.getColor(context, chosenTrippie.getFeatured() ? chosenTrippie.getUrgent() ? R.color.urgent_colour : R.color.featured_colour : R.color.pickup_colour);
        pickupText.setTextColor(pickupColour);
        pickupText.setCompoundDrawableTintList(ColorStateList.valueOf(pickupColour));

        pickupText.setText(chosenTrippie.getPickupAddress().replace(", New Zealand",""));
        destinationText.setText(chosenTrippie.getDeliveryAddress().replace(", New Zealand",""));

        TextView[] textViews = new TextView[]{pickupText, destinationText, size}; //set overflow conditions for text views
        for (TextView textView : textViews) {
            textView.setHorizontallyScrolling(true);
            textView.setSelected(true);
            textView.setClickable(false);
            textView.setMarqueeRepeatLimit(-1);
        }

        String formattedPrice = String.valueOf(Math.round(chosenTrippie.getPrice()));
        price.setTextSize(formattedPrice.length() > 2 ? 14 : 20);
        price.setText(String.format(getResources().getString(R.string.currency), formattedPrice));
        title.setText(chosenTrippie.getTitle());

        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm", Locale.UK);
        pickupDate.setText(dateFormat.format(chosenTrippie.getPickupTime()));
        size.setText(chosenTrippie.getSize());

        PolylineOptions route = new PolylineOptions();
        List<LatLng> points = PolyUtil.decode(chosenTrippie.getPolyline());
        route.addAll(points);
        route.color(ContextCompat.getColor(Objects.requireNonNull(getContext()),R.color.main_colour_blue)).width(7);
        mMap.addPolyline(route);

        LatLng distanceLabelPosition = points.get(points.size() / 2);

        Bitmap nullIcon = BitmapFactory.decodeResource(getResources(), R.drawable.null_image);
        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.fromBitmap(nullIcon);
        MarkerOptions mo = new MarkerOptions().position(distanceLabelPosition).title(chosenTrippie.getDistanceText()).visible(true).icon(bitmapDescriptor);
        mMap.addMarker(mo).showInfoWindow();

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for (LatLng point : points) builder.include(point);

        LatLngBounds bounds = builder.build();

        final LinearLayout ll = v.findViewById(R.id.overlay);

        FrameLayout maps = v.findViewById(R.id.map);

        final ViewGroup.LayoutParams lp = maps.getLayoutParams();
        lp.height = maps.getHeight() - ll.getHeight();
        maps.setLayoutParams(lp);

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = lp.height;
        int padding = (int) (width * 0.20);
        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding));

        mMap.setOnMarkerClickListener(marker -> false);

        TextView distance = v.findViewById(R.id.trippie_distance);
        String[] distanceArray = chosenTrippie.getDistanceText().replace(",", "").split(" ");
        distance.setText(Math.round(Double.parseDouble(distanceArray[0])) + " " + distanceArray[1]); //round the distance

        ll.setOnClickListener(c -> {if (chosenTrippie != null) goToDetails(chosenTrippie);});

        ll.setVisibility(View.VISIBLE);

        mMap.setOnMapClickListener(latLng -> {
            image.setImageBitmap(null);
            imagesLoaded = false;
            ll.setOnClickListener(null);
            ll.setVisibility(View.GONE);
            lp.height = -1;
            showPickupLocations();
        });
    }

    private BitmapDescriptor getMarkerIconFromDrawable(Drawable drawable) {
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void goToPriceEstimate() {
        fab.setEnabled(false);
        Intent intent = new Intent(Objects.requireNonNull(getActivity()).getApplication(), CreateTrippieActivity.class);
        intent.putExtra("reList", false);
        startActivity(intent);
    }

    private void goToDetails(Trippie trippie) {
        Intent showTrippieIntent = new Intent(getActivity(), ShowTrippiesDetailActivity.class);
        showTrippieIntent.putExtra("trippiedCancelled", trippie.getCancelled());
        showTrippieIntent.putExtra("TrippieId", trippie.getTrippieId());
        showTrippieIntent.putExtra("UserId", trippie.getUserId());
        startActivity(showTrippieIntent);
    }
}
