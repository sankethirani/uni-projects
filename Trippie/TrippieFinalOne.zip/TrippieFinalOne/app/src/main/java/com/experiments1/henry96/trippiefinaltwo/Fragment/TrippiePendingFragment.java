package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.app.AlertDialog;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Custom_Offer_Display_Adapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.NotificationService.NotificationInRetrofitIns;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.functions.FirebaseFunctions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class TrippiePendingFragment extends Fragment implements Custom_Offer_Display_Adapter.OnItemClickListener {

    private static final String TAG = "TrippiePendingFragment";
    private TextView tvNoOffers;

    private RecyclerView rvOffers;

    private Trippie trippie;
    private DocumentReference docRef;
    private ArrayList<Offer> offerArrayList;
    private Custom_Offer_Display_Adapter custom_offer_display_adapter;
    private ListenerRegistration listenerRegistration;
    private String trippieId;
    private boolean isbeingDelivery;

    private FirebaseFirestore db;

    @Override
    public void onStart() {
        super.onStart();
        offerArrayList = new ArrayList<>();
        custom_offer_display_adapter = new Custom_Offer_Display_Adapter(offerArrayList, getContext());
//        rvOffers.setHasFixedSize(true);
        rvOffers.setLayoutManager(new LinearLayoutManager(getContext()));
        rvOffers.setAdapter(custom_offer_display_adapter);
        custom_offer_display_adapter.setOnItemClickListener(this);

        listenerRegistration = docRef.addSnapshotListener((documentSnapshot, e) -> {
            if (e != null) {
                Log.d(TAG, e.toString());
                return;
            }

            if (documentSnapshot != null && documentSnapshot.exists()) {
                trippie = documentSnapshot.toObject(Trippie.class);
                if (trippie != null && trippie.getOffers() != null) {
                    offerArrayList.clear();

                    if (isbeingDelivery) {
                        custom_offer_display_adapter.setBeingDelivery(false);
                    }
                    for (Offer item : trippie.getOffers().values())
                        if (item.isActive()) offerArrayList.add(item);

                    tvNoOffers.setVisibility(offerArrayList != null && offerArrayList.size() != 0 ? View.GONE : View.VISIBLE);
                    custom_offer_display_adapter.notifyDataSetChanged();

                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        listenerRegistration.remove();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_trippie_pending, container, false);
        init(v);
        if (getArguments() != null) {
//            offers = (Offer[]) getArguments().getParcelableArray("offersList");
            trippieId = getArguments().getString("trippieID");
            docRef = db.collection("trippies").document(trippieId);
            isbeingDelivery = getArguments().getBoolean("beingDelivery", false);
        }

        return v;
    }

    private void sendDeclineNotification(Offer offer, boolean forMultipleDevices) {
        if (!forMultipleDevices)
            Helpers.showToast(getContext(), "Sending notification");

        String title = "Decline offer";

        String body = forMultipleDevices ? "Your Trippie has been taken!" : "Your Offer has been Declined!";

        String trippieid_type_tname = offer.getTrippieId() + "-@-" + Helpers.Key_Job_Decline + "-@-" + trippie.getTitle();
        String imageurl_driverid = trippie.getThumbnailUrl() + "-@-" + "null";

        Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(offer.getServiceProviderToken(), title, body,
                trippieid_type_tname, imageurl_driverid);


        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    offer.setActive(false);
                    docRef.update("offers." + offer.getServiceProviderId(), offer);
                    if (!forMultipleDevices)
                        Helpers.showToast(getActivity(), "Notification has been sent to Tripster!");
                }
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                Helpers.showToast(getContext(), "Offer failed to send!");
                Log.e(TAG, Objects.requireNonNull(t.getMessage()));
            }
        });
    }


    private void sendAcceptNotification(Offer offer) {
        Helpers.showToast(getContext(), "Sending notification");

        String title = "Your offer was accepted!";
        String body = "Your Offer has been accepted!";
        String trippieid_type_tname = offer.getTrippieId() + "-@-" + Helpers.Key_Job + "-@-" + trippie.getTitle();
        String imageurl_driverid = trippie.getThumbnailUrl() + "-@-" + "null";

        Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(offer.getServiceProviderToken(), title, body,
                trippieid_type_tname, imageurl_driverid);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                if (response.isSuccessful()) {
//                    docRef.update("active", true);
                    docRef.update("driverId", offer.getServiceProviderId());
                    docRef.update("status", Trippie.Status.customer_accepted.toString());
                    docRef.update("price", offer.getPrice());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
                    StatusDetail statusDetail = new StatusDetail(Trippie.Status.customer_accepted.toString(),
                            dateFormat.format(Calendar.getInstance().getTime()), 0);
                    docRef.update("statusDetails." + Trippie.Status.customer_accepted.toString(), statusDetail);

                    Helpers.showToast(getActivity(), "Notification has been sent to Tripster!");
                    Objects.requireNonNull(getActivity()).finish();
                }
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                Helpers.showToast(getContext(), "Offer failed to send!");
                Log.e(TAG, Objects.requireNonNull(t.getMessage()));
            }
        });
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private void init(View view) {
        tvNoOffers = view.findViewById(R.id.tvNoOffer);
        rvOffers = view.findViewById(R.id.rvOffers);
        db = FirebaseFirestore.getInstance();

    }

    @Override
    public void onItemAcceptClick(int position) {
        Offer offercur = offerArrayList.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Accept offer?");

        String price = Helpers.addTrailingZerosToCurrency(offercur.getPrice());
        String sourceString = String.format(getString(R.string.accept_offer_confirmation), price, offercur.getServiceProviderName());
        Spannable wordtoSpan = new SpannableString(sourceString);

        int firstletter = sourceString.indexOf("$");
        int secondletter = sourceString.indexOf("from") + "from".length();
        wordtoSpan.setSpan(new ForegroundColorSpan(Color.BLUE), firstletter, firstletter + price.length() + 1, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
        wordtoSpan.setSpan(new ForegroundColorSpan(Color.RED), secondletter, sourceString.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        builder.setMessage(wordtoSpan);
        builder.setPositiveButton("Yes", (dialog, which) -> {
            docRef.get().addOnSuccessListener(documentSnapshot -> {
                trippie = documentSnapshot.toObject(Trippie.class);
                if (trippie != null) {
                    Map<String, Object> data = new HashMap<>();
                    data.put("trippieId", trippieId);
                    data.put("makeInactive", false);
                    FirebaseFunctions.getInstance().getHttpsCallable("auth").call(data);
                    sendAcceptNotification(offercur);
                }

                for (Offer item : offerArrayList) {
                    if (!item.getServiceProviderToken().equals(offercur.getServiceProviderToken()) && item.isActive()) {
                        sendDeclineNotification(item, true);
                    }

                }
            });
        });

        builder.setNegativeButton("No", null);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    @Override
    public void onItemDeclineClick(int position) {
        Offer offercur = offerArrayList.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Decline offer?");

        String sourceString = String.format(getString(R.string.decline_offer_confirmation), offercur.getServiceProviderName());
        Spannable wordtoSpan = new SpannableString(sourceString);
        int secondletter = sourceString.indexOf("from") + "from".length();
        wordtoSpan.setSpan(new ForegroundColorSpan(Color.RED), secondletter, sourceString.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        builder.setMessage(wordtoSpan);

        builder.setPositiveButton("Yes", (dialog, which) -> {
            docRef.get().addOnSuccessListener(documentSnapshot -> {
                trippie = documentSnapshot.toObject(Trippie.class);
                if (trippie != null) {
                    sendDeclineNotification(offercur, false);
                }
            });

        });

        builder.setNegativeButton("No", null);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
