package com.experiments1.henry96.trippiefinaltwo.Helper;

import androidx.annotation.NonNull;

public enum PersonMeetingDriver {
    Me(0),
    Someone_else(1),
    Nobody(2);

    PersonMeetingDriver(int i){
        this.type = i;
    }

    private int type;

    public int getNumericType(){
        return type;
    }

    @NonNull
    @Override
    public String toString() {
        return name().replace("_", " ");
    }
}
