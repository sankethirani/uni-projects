package com.experiments1.henry96.trippiefinaltwo.LocalDb;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "notification_table")
public class Notification {
    @PrimaryKey(autoGenerate = true)
    private long notificationId;

    private String type;
    private String title;
    private String body;
    private Long time;
    private String trippieId;
    private String imageUrl;
    private String trippieName;

    public Notification(String type, String title, String body, Long time, String trippieId, String imageUrl, String trippieName) {
        this.type = type;
        this.title = title;
        this.body = body;
        this.time = time;
        this.trippieId = trippieId;
        this.imageUrl = imageUrl;
        this.trippieName = trippieName;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTrippieName() {
        return trippieName;
    }

    void setTrippieName(String trippieName) {
        this.trippieName = trippieName;
    }

    public long getNotificationId() {
        return notificationId;
    }

    void setNotificationId(long notificationId) {
        this.notificationId = notificationId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public Long getTime() {
        return time;
    }

    void setTime(Long time) {
        this.time = time;
    }

    public String getTrippieId() {
        return trippieId;
    }

    public void setTrippieId(String trippieId) {
        this.trippieId = trippieId;
    }
}
