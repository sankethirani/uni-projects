package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.experiments1.henry96.trippiefinaltwo.Fragment.AddPhotoCreateTrippie;
import com.experiments1.henry96.trippiefinaltwo.Fragment.AddPhotoCreateTrippieInterface;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.PersonMeetingDriver;
import com.experiments1.henry96.trippiefinaltwo.Helper.RetrieveImagePath;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static android.provider.DocumentsContract.EXTRA_INITIAL_URI;

public class EditTrippieActivity extends AppCompatActivity implements AddPhotoCreateTrippieInterface {
    private LinearLayout deliveryLayout, pickupLayout, listingImagesHolder;
    private Trippie trippie;
    private EditText title, value, description, instructions, pickupName, pickupNumber, deliveryName, deliveryNumber;
    private Spinner pickupMeet, deliveryMeet;
    private TextView pickupTime, deliveryTime, pickupLocation, deliveryLocation, distance, size, urgent, featured, signatureRequired;
    private SimpleDateFormat dateFormat;
    private EditText[] compulsoryEditTexts, optionalEditTexts;
    private Button updateButton;
    private RelativeLayout loadingCircle;
    private FrameLayout createContainer, firstListingImageHolder;
    private FloatingActionButton plusButton, minusButton;
    private List<Uri> mainImageUris;
    private ImageView imageHolder;
    private static final int PICK_MAIN_IMAGE_REQUEST = 6124, PICK_CAMERA_IMAGE_REQUEST = 5473, MY_CAMERA_PERMISSION_CODE = 2789;
    private boolean[] imagesChanged;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_trippie);
        initialiseLayout();
        setListeners();
        fillFields();
    }

    private void initialiseLayout(){
        Gson gson = new Gson();
        trippie = gson.fromJson(getIntent().getStringExtra("trippie"), Trippie.class);

        deliveryLayout = findViewById(R.id.delivery_person_fields);
        pickupLayout = findViewById(R.id.pickup_person_fields);
        title = findViewById(R.id.et_title);
        value = findViewById(R.id.et_value);
        description = findViewById(R.id.et_description);
        instructions = findViewById(R.id.et_delivery_instruction);
        pickupName = findViewById(R.id.et_person_pickup);
        pickupNumber = findViewById(R.id.et_person_mobile_pickup);
        deliveryName = findViewById(R.id.et_person_delivery);
        deliveryNumber = findViewById(R.id.et_person_mobile_delivery);
        pickupMeet = findViewById(R.id.et_meet_pickup);
        deliveryMeet = findViewById(R.id.et_meet_delivery);
        pickupTime = findViewById(R.id.et_pickup_time);
        deliveryTime = findViewById(R.id.et_delivery_time);
        pickupLocation = findViewById(R.id.et_pickup_address);
        deliveryLocation = findViewById(R.id.et_destination_address);
        distance = findViewById(R.id.et_distance);
        size = findViewById(R.id.et_size);
        urgent = findViewById(R.id.et_urgent);
        featured = findViewById(R.id.et_featured);
        signatureRequired = findViewById(R.id.et_signature);
        updateButton = findViewById(R.id.btn_update);
        createContainer = findViewById(R.id.create_button_container);
        firstListingImageHolder = findViewById(R.id.first_listing_image_holder);
        listingImagesHolder = findViewById(R.id.listing_images_holder);
        imageHolder = findViewById(R.id.first_image_holder);
        imagesChanged = new boolean[3];

        plusButton = (FloatingActionButton) getLayoutInflater().inflate(R.layout.myfab, listingImagesHolder,false);
        plusButton.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.main_colour_blue)));
        FrameLayout.LayoutParams plusLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        plusLayoutParams.setMargins(0,0,20,30);
        plusLayoutParams.width = plusLayoutParams.height = (int)(25 * getResources().getDisplayMetrics().density);
        plusButton.setScaleType(ImageView.ScaleType.CENTER);
        plusButton.setLayoutParams(plusLayoutParams);

        firstListingImageHolder.addView(plusButton);

        compulsoryEditTexts = new EditText[]{title, value, description, instructions};
        optionalEditTexts = new EditText[]{pickupName,pickupNumber,deliveryName,deliveryNumber};

        dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
    }

    private void fillFields(){
        title.setText(trippie.getTitle());
        value.setText(Helpers.addTrailingZerosToCurrency(trippie.getItemValue()));
        description.setText(trippie.getDescription());
        instructions.setText(trippie.getInstructions());
        pickupTime.setText(dateFormat.format(trippie.getPickupTime()));
        deliveryTime.setText(dateFormat.format(trippie.getDeliveryTime()));
        pickupLocation.setText(trippie.getPickupAddress().replace(", New Zealand", ""));
        deliveryLocation.setText(trippie.getDeliveryAddress().replace(", New Zealand", ""));
        distance.setText(trippie.getDistanceText());
        size.setText(trippie.getSize());
        urgent.setText(yesOrNo(trippie.getUrgent()));
        featured.setText(yesOrNo(trippie.getFeatured()));
        signatureRequired.setText(yesOrNo(trippie.getSignatureRequired()));

        List<PersonMeetingDriver> pickupList = new ArrayList<>(Arrays.asList(PersonMeetingDriver.values()));
        pickupList.remove(PersonMeetingDriver.Nobody);
        List<PersonMeetingDriver> deliveryList = new ArrayList<>(Arrays.asList(PersonMeetingDriver.values()));
        if(!trippie.getCategory().equals("Item") || trippie.getSignatureRequired()) deliveryList.remove(PersonMeetingDriver.Nobody);

        pickupMeet.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pickupList));
        deliveryMeet.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deliveryList));

        pickupMeet.setSelection(trippie.getMeetingDriverPickup());
        deliveryMeet.setSelection(trippie.getMeetingDriverDelivery());

        if(trippie.getMeetingDriverPickup() == PersonMeetingDriver.Someone_else.getNumericType()){
            pickupName.setText(trippie.getPersonMeetingPickupName());
            pickupNumber.setText(trippie.getPersonMeetingPickupPhone());
        }
        if(trippie.getMeetingDriverDelivery() == PersonMeetingDriver.Someone_else.getNumericType()){
            deliveryName.setText(trippie.getPersonMeetingDeliveryName());
            deliveryNumber.setText(trippie.getPersonMeetingDeliveryPhone());
        }

        mainImageUris = new ArrayList<>();

        StorageReference ref = FirebaseStorage.getInstance().getReference();
        List<String> images = trippie.getListingImage();
        ref.child("images/trippies/" + images.get(0)).getDownloadUrl().addOnSuccessListener(uri -> {
            addPicturesToTrippie(uri);
            if(images.size() > 1) for(int i = 1; i < images.size(); i++) ref.child("images/trippies/" + images.get(i)).getDownloadUrl().addOnSuccessListener(EditTrippieActivity.this::addPicturesToTrippie);
        });
    }

    private void setListeners(){
        AdapterView.OnItemSelectedListener meetingWatcher = new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> adapterView) { }
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int visibilitySetting = adapterView.getSelectedItem().toString().equals(PersonMeetingDriver.Someone_else.toString()) ? View.VISIBLE : View.GONE;
                (pickupMeet.hashCode() == adapterView.hashCode() ? pickupLayout : deliveryLayout).setVisibility(visibilitySetting);
                checkAllFieldsFilled();
            }
        };

        pickupMeet.setOnItemSelectedListener(meetingWatcher);
        deliveryMeet.setOnItemSelectedListener(meetingWatcher);

        TextWatcher filledChecker = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void afterTextChanged(Editable editable) { checkAllFieldsFilled(); }
        };

        for(EditText et : compulsoryEditTexts) et.addTextChangedListener(filledChecker);
        for(EditText et : optionalEditTexts) et.addTextChangedListener(filledChecker);

        updateButton.setOnClickListener(view -> {

            updateButton.setEnabled(false); updateButton.setText("");
            loadingCircle = (RelativeLayout) getLayoutInflater().inflate(R.layout.loading_circle, createContainer, false);
            loadingCircle.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
            createContainer.addView(loadingCircle);
            List<String> existingImages = trippie.getListingImage();

            boolean changed = false;
            for(boolean b : imagesChanged) if(b) changed = true;

            if(changed){
                List<String> mainImageUrls = new ArrayList<>();
                if(mainImageUris.size() > 1){
                    if (Objects.requireNonNull(mainImageUris.get(1).getPath()).split("/")[2].endsWith(":")) {
                        for(int i = 1; i < mainImageUris.size(); i++) if(imagesChanged[i]) mainImageUrls.add(Objects.requireNonNull(mainImageUris.get(i).getPath()).split(":")[1]);
                    } else {
                        for(int i = 1; i < mainImageUris.size(); i++) if(imagesChanged[i]) mainImageUrls.add(RetrieveImagePath.getPath(this,mainImageUris.get(i)));
                    }
                }

                List<String> images = new ArrayList<>(), fileNames = new ArrayList<>();
                String[] tempChecker = new String[existingImages.size()];
                existingImages.toArray(tempChecker);

                for (int i = 1; i < existingImages.size(); i++) {
                    if (imagesChanged[i]) existingImages.remove(tempChecker[i]);
                }

                if(!mainImageUrls.isEmpty()) {
                    images.add(mainImageUrls.get(0));

                    for (int i = 0; i < images.size(); i++) {
                        String image = images.get(i);
                        Uri file;
                        file = Uri.fromFile(new File(Objects.requireNonNull(image)));

                        String[] temp = Objects.requireNonNull(images.get(i)).split(getResources().getString(R.string.file_path_splitter));
                        temp = temp[temp.length - 1].split("/");
                        String[] filenameSplit = Helpers.filenameExtensionSplitter(temp[temp.length - 1]);
                        fileNames.add(FirebaseAuth.getInstance().getUid() + "_" + filenameSplit[0] + "_" + i + filenameSplit[1]);
                        StorageReference imageRef = FirebaseStorage.getInstance().getReference().child("images/trippies/" + fileNames.get(i));

                        imageRef.putFile(file).addOnFailureListener(fail -> Helpers.showToast(this, "oops"));
                    }

                    existingImages.addAll(fileNames);
                }
            }

            DocumentReference documentReference = FirebaseFirestore.getInstance().collection("trippies").document(trippie.getTrippieId());

            documentReference.update(
                    "title", title.getText().toString(),
                    "itemValue", Double.parseDouble(value.getText().toString()),
                    "description", description.getText().toString(),
                    "instructions", instructions.getText().toString(),
                    "meetingDriverPickup", ((PersonMeetingDriver)pickupMeet.getSelectedItem()).getNumericType(),
                    "meetingDriverDelivery", ((PersonMeetingDriver)deliveryMeet.getSelectedItem()).getNumericType(),
                    "personMeetingPickupName", pickupName.getText().toString(),
                    "personMeetingPickupPhone", pickupNumber.getText().toString(),
                    "personMeetingDeliveryName", deliveryName.getText().toString(),
                    "personMeetingDeliveryPhone", deliveryNumber.getText().toString(),
                    "listingImage", existingImages
            ).addOnSuccessListener(aVoid -> finish());
        });

        plusButton.setOnClickListener(c -> new AddPhotoCreateTrippie(this).showNow(getSupportFragmentManager(),"photoDialog"));
    }

    private String yesOrNo(boolean value){
        return value ? "Yes" : "No";
    }

    private void checkAllFieldsFilled(){
        boolean isFilled = true;
        for(EditText et : compulsoryEditTexts)
            if (et.getText().toString().isEmpty()) {
                isFilled = false;
                break;
            }

        if(pickupLayout.getVisibility() == View.VISIBLE){
            String number = pickupNumber.getText().toString();
            if(pickupName.getText().toString().isEmpty() || number.isEmpty() || number.length() < 9) isFilled = false;
        }
        if(deliveryLayout.getVisibility() == View.VISIBLE){
            String number = deliveryNumber.getText().toString();
            if (deliveryName.getText().toString().isEmpty() || number.isEmpty() || number.length() < 9) isFilled = false;
        }


        updateButton.setEnabled(isFilled);
        if(!isFilled){
            updateButton.setText(R.string.fill_all_fields);
            updateButton.setBackgroundResource(R.drawable.custom_button_disabled);
        }
        else{
            updateButton.setText(R.string.update_text);
            updateButton.setBackgroundResource(R.drawable.custom_button_blue);
        }
    }

    private void addPicturesToTrippie(@NonNull Uri imageUri){
        minusButton = (FloatingActionButton) getLayoutInflater().inflate(R.layout.myfab, firstListingImageHolder,false);
        minusButton.setImageDrawable(getDrawable(R.drawable.ic_remove_white_24dp));
        minusButton.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.text_colour_red)));
        FrameLayout.LayoutParams minusLayoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        minusLayoutParams.setMargins(0,30,20,0);
        minusLayoutParams.width = minusLayoutParams.height = (int)(25 * getResources().getDisplayMetrics().density);
        minusButton.setScaleType(ImageView.ScaleType.CENTER);
        minusButton.setLayoutParams(minusLayoutParams);

        mainImageUris.add(imageUri);

        if(mainImageUris.size() == 3) plusButton.hide();
        doAfterPicturesLoaded(imageUri);
    }

    private void doAfterPicturesLoaded(Uri imageUri){
        if(mainImageUris.size() == 1) {
            Picasso.get().load(imageUri).into(imageHolder);
        } else {
            FrameLayout fl = new FrameLayout(this);
            LinearLayout listingImagesHolder = findViewById(R.id.listing_images_holder);

            ImageView iv = new ImageView(this);
            fl.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.height = lp.width = (int) (100 * Resources.getSystem().getDisplayMetrics().density);
            iv.setLayoutParams(lp);
            fl.addView(iv);
            fl.addView(minusButton);


            listingImagesHolder.addView(fl);
            Picasso.get().load(imageUri).into(iv);
            minusButton.setOnClickListener(button -> {
                listingImagesHolder.removeView(fl);

                if (mainImageUris.size() == 3) plusButton.show();
                mainImageUris.remove(imageUri);
                imagesChanged[mainImageUris.size()] = true;
            });
        }

        checkAllFieldsFilled();
    }

    public void openFileChooser() {
        Intent imageSelectIntent = new Intent();
        imageSelectIntent.setType("image/*");
        imageSelectIntent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*"});
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { //if we're on API 26 or higher
            imageSelectIntent.putExtra(EXTRA_INITIAL_URI, "/storage/emulated/0/"); //place user in /storage/emulated/0/ by default
        }
        imageSelectIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
        startActivityForResult(imageSelectIntent, PICK_MAIN_IMAGE_REQUEST);
    }

    public void openCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
        }
        else
        {
            Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, PICK_CAMERA_IMAGE_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, PICK_CAMERA_IMAGE_REQUEST);
            }
            else
            {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(data != null) {
            Uri imageUri = null;
            if (requestCode == PICK_MAIN_IMAGE_REQUEST) {
                imageUri = data.getData();
            } else if (requestCode == PICK_CAMERA_IMAGE_REQUEST) {
                Bitmap photo = (Bitmap) Objects.requireNonNull(data.getExtras()).get("data");
                imageUri = Helpers.returnUriFromBitmap(photo, "capturedimage");
            }
            if (imageUri != null) {
                imagesChanged[mainImageUris.size()] = true;
                addPicturesToTrippie(imageUri);
            }
        }
    }

}
