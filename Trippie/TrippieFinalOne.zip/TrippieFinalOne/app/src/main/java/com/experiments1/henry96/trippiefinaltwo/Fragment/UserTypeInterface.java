package com.experiments1.henry96.trippiefinaltwo.Fragment;

public interface UserTypeInterface {
    double getRating();
    int getNumberOfRatings();
}
