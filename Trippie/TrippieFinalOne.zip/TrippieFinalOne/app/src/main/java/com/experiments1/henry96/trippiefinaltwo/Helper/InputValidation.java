package com.experiments1.henry96.trippiefinaltwo.Helper;

import android.content.Context;

import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.RadioGroup;

import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Pattern;


public class InputValidation {

    private Context context;

    public InputValidation(Context context) {
        this.context = context;
    }

    public boolean isInputEditextField(TextInputLayout textInputLayout, String message) {
        String value = textInputLayout.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(value)) {
            textInputLayout.setError(message);
            hideKeyBoardFrom(textInputLayout);
            return false;
        } else {
            textInputLayout.setError(null);
            textInputLayout.setErrorEnabled(false);
            return true;
        }
    }

    public String CapitalizString(String temp) {
        return temp.substring(0, 1).toUpperCase() + temp.substring(1).toLowerCase();
    }


    public boolean isInputeditTextEmail(TextInputLayout textInputLayout, String message) {
        String emailInput = textInputLayout.getEditText().getText().toString().trim();

        if (TextUtils.isEmpty(emailInput)) {
            textInputLayout.setError("Field Can't be Empty!");
            hideKeyBoardFrom(textInputLayout);
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            textInputLayout.setError(message);
            hideKeyBoardFrom(textInputLayout);
            return false;
        } else {
            textInputLayout.setError(null);
            return true;
        }
    }

    public boolean isEditTextEmailValid(String email) {
        String emailInput = email.trim();

        if (TextUtils.isEmpty(emailInput) || !Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            return false;
        }

        return true;
    }


    public boolean isInputEdittextMatches(TextInputLayout textInputLayout1, TextInputLayout textInputLayout2, String message) {
        String value1 = textInputLayout1.getEditText().getText().toString().trim();
        String value2 = textInputLayout2.getEditText().getText().toString().trim();

        if (!value1.contentEquals(value2)) {
            textInputLayout1.setError(message);
            hideKeyBoardFrom(textInputLayout1);
            return false;
        } else {
            textInputLayout1.setErrorEnabled(false);
            return true;
        }
    }

    public boolean isInputValidationAutoCompletextbox(TextInputLayout textInputLayout, AutoCompleteTextView autotextview, String message) {
        String input = autotextview.getText().toString().trim();
        if (TextUtils.isEmpty(input)) {
            textInputLayout.setError(message);
            hideKeyBoardFrom(textInputLayout);
            return false;
        } else {
            textInputLayout.setError(null);
            textInputLayout.setErrorEnabled(false);
            return true;
        }
    }

    public boolean isPasswordLengthValid(TextInputLayout textInputLayout, String message) {
        String str = textInputLayout.getEditText().getText().toString().trim();
        if (str.length() < 6) {
            textInputLayout.setError(message);
            return false;
        } else {
            textInputLayout.setError(null);
            textInputLayout.setErrorEnabled(false);
            return true;
        }
    }

    public boolean isInputValidateRadioButtonGroup(TextInputLayout textInputLayout, RadioGroup group, String message) {
        if (group.getCheckedRadioButtonId() == -1) {
            textInputLayout.setError(message);
            return false;
        } else {
            textInputLayout.setError(null);
            textInputLayout.setErrorEnabled(false);
            return true;
        }
    }

    public void hideKeyBoardFrom(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public boolean isInputCheckBoxClick(TextInputLayout textInputLayout, CheckBox ck, String message) {
        if (!ck.isChecked()) {
            textInputLayout.setError(message);
            return false;
        } else {
            textInputLayout.setError(null);
            textInputLayout.setErrorEnabled(false);
            return true;
        }
    }


    public boolean isValidMobile(TextInputLayout textInputLayout, String message) {
        String phone = textInputLayout.getEditText().getText().toString().trim();

        if (!Pattern.matches("[a-zA-Z]+", phone) && !(phone.length() > 6 && phone.length() < 13)) {
            Log.e("Input", "False");
            textInputLayout.setError(message);
            hideKeyBoardFrom(textInputLayout);
            return false;
        } else {
            textInputLayout.setError(null);
            Log.e("Input", "true");
            return true;
        }
    }
}
