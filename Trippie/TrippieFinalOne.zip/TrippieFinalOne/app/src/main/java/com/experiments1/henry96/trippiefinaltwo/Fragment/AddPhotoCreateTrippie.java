package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.experiments1.henry96.trippiefinaltwo.R;

public class AddPhotoCreateTrippie extends DialogFragment {

    private View v;
    private TextView galleryOption, cameraOption;
    private AddPhotoCreateTrippieInterface caller;


    public AddPhotoCreateTrippie(AddPhotoCreateTrippieInterface caller){
        this.caller = caller;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.dialog_changephoto, container, false);
        initialiseLayout();
        setOnClickListeners();
        return v;
    }

    private void initialiseLayout(){
        galleryOption = v.findViewById(R.id.dialogChoosePhoto);
        cameraOption  = v.findViewById(R.id.dialogOpenCamera);
    }

    private void setOnClickListeners(){
        galleryOption.setOnClickListener(c -> {
            caller.openFileChooser();
            this.dismiss();
        });
        cameraOption.setOnClickListener(c -> {
            caller.openCamera();
            this.dismiss();
        });
    }
}
