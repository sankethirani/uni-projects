package com.experiments1.henry96.trippiefinaltwo.Fragment;

public interface VehicleInterface {
    int setAnimalQuantity(String animalString, int animalQuantity);
    void setRelistVehicleSize(String size);
    void setRelistAnimalQuantity(String animalString, int animalQuantity);
}
