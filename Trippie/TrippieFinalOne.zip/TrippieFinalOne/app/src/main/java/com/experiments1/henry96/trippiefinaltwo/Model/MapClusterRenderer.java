package com.experiments1.henry96.trippiefinaltwo.Model;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.util.TypedValue;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;

import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;
import com.google.maps.android.ui.SquareTextView;

public class MapClusterRenderer extends DefaultClusterRenderer<MapClusterMarker> {

    private Context context;
    private ShapeDrawable coloredCircleBackground;
    private IconGenerator iconGenerator;

    public MapClusterRenderer(Context context, GoogleMap map, ClusterManager<MapClusterMarker> clusterManager) {
        super(context, map, clusterManager);
        this.context = context;
        iconGenerator = new IconGenerator(context);
        iconGenerator.setContentView(this.makeSquareTextView(context));
        clusterManager.setRenderer(this);
    }

    private LayerDrawable makeClusterBackground(){
        coloredCircleBackground = new ShapeDrawable(new OvalShape());
        ShapeDrawable outline = new ShapeDrawable(new OvalShape());
        outline.getPaint().setColor(-2130706433);
        LayerDrawable background = new LayerDrawable(new Drawable[]{outline, coloredCircleBackground});
        int strokeWidth = (int)(context.getResources().getDisplayMetrics().density * 1.8F);
        background.setLayerInset(1, strokeWidth, strokeWidth, strokeWidth, strokeWidth);
        return background;
    }

    @Override
    protected int getColor(int clusterSize){
        return ContextCompat.getColor(context,R.color.main_colour_blue);
    }

    @Override
    protected void onBeforeClusterItemRendered(MapClusterMarker markerItem, MarkerOptions markerOptions){
        if(markerItem.getIcon() != null) markerOptions.icon(markerItem.getIcon());
        markerOptions.rotation(markerItem.getRotation()).visible(true);
    }

    @Override
    protected void onBeforeClusterRendered(Cluster<MapClusterMarker> cluster, MarkerOptions markerOptions){
        iconGenerator.setBackground(makeClusterBackground());
        coloredCircleBackground.getPaint().setColor(this.getColor(this.getBucket(cluster)));
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(iconGenerator.makeIcon(String.valueOf(cluster.getSize()))));
    }

    private SquareTextView makeSquareTextView(Context context) {
        SquareTextView squareTextView = new SquareTextView(context);
        squareTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        squareTextView.setTextColor(Color.WHITE);
        squareTextView.setTypeface(null, Typeface.BOLD);

        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
        squareTextView.setLayoutParams(layoutParams);
        squareTextView.setId(R.id.amu_text);
        int padding = (int)(7.2f * context.getResources().getDisplayMetrics().density);
        squareTextView.setPadding(padding, padding, padding, padding);
        return squareTextView;
    }

    @Override
    protected boolean shouldRenderAsCluster(Cluster<MapClusterMarker> cluster){
        return cluster.getSize() > 1;
    }
}
