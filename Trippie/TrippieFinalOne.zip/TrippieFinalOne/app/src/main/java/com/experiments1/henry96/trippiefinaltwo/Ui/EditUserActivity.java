package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.experiments1.henry96.trippiefinaltwo.Fragment.ChangePhotoDialog;
import com.experiments1.henry96.trippiefinaltwo.Helper.FilePaths;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.InputValidation;
import com.experiments1.henry96.trippiefinaltwo.Model.Address;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.github.abdularis.civ.CircleImageView;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

public class EditUserActivity extends AppCompatActivity implements View.OnClickListener,
        DatePickerDialog.OnDateSetListener, ChangePhotoDialog.OnPhotoReceivedListener {

    private static final String TAG = "EditUserActivity";
    private TextInputLayout inputFName, inputLName;
    private EditText newAddressField;
    private TextView tvDOB;
    private ProgressBar progressBar;

    private Button btnSave;

    private DatePickerDialog dtpDate;
    private Calendar mDateOfBirth;

    private Uri mSelectedImageUri;
    private CircleImageView imgProfile;

    private InputValidation inputValidation;
    private FirebaseFirestore db;

    private Address address;

    private byte[] mBytes;
    private double progress;
    private static final double MB_THRESHOLD = 5.0, MB = 1000000.0;

    private String message;
    private DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.UK);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        init();
        initObjects();
        initListeners();
        createDatePicker();

        // Initialize the SDK
        Places.initialize(getApplicationContext(), getString(R.string.google_places_key));

        getUserDetail();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 223) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                address = new Address(place.getAddress(), new GeoPoint(Objects.requireNonNull(place.getLatLng()).latitude, place.getLatLng().longitude));
                newAddressField.setText(Objects.requireNonNull(place.getAddress()).replace(", New Zealand", ""));
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i(TAG, Objects.requireNonNull(status.getStatusMessage()));
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    private void createDatePicker() {
        mDateOfBirth = Calendar.getInstance();
        dtpDate = new DatePickerDialog(this, this, mDateOfBirth.get(Calendar.YEAR), mDateOfBirth.get(Calendar.MONTH), mDateOfBirth.get(Calendar.DAY_OF_MONTH));

    }


    private void initListeners() {
        btnSave.setOnClickListener(this);
//        tvDOB.setOnClickListener(this);
        imgProfile.setOnClickListener(this);
        findViewById(R.id.new_address_field).setOnClickListener(view -> {
            Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, Arrays.asList(Place.Field.LAT_LNG, Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS)).setCountry("NZ").setTypeFilter(TypeFilter.ADDRESS).build(this);
            startActivityForResult(intent, 223);
        });

    }

    private void initObjects() {
        inputValidation = new InputValidation(this);
        message = getString(R.string.text_empty_field);
        db = FirebaseFirestore.getInstance();
    }

    private void init() {

        inputFName = findViewById(R.id.textinput_fName);
        inputLName = findViewById(R.id.textinput_Lastname);
        btnSave = findViewById(R.id.btnSave);
        tvDOB = findViewById(R.id.tvDateOfbirth);
        imgProfile = findViewById(R.id.iv_profilepicture);
        progressBar = findViewById(R.id.progressBar);
        newAddressField = (findViewById(R.id.new_address_field));
        setMaxLengthForMobileNumber();

    }

    private void setMaxLengthForMobileNumber() {
        InputFilter filter = (source, start, end, dest, dstart, dend) -> {
            for (int i = start; i < end; ++i) {
                if (!Pattern.compile("[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890]*").matcher(String.valueOf(source.charAt(i))).matches()) {
                    return "";
                }
            }

            return null;
        };

    }


    private void getUserDetail() {
        Helpers.showDialog(progressBar);
        DocumentReference docRef = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            User user = documentSnapshot.toObject(User.class);
            assert user != null;
            Objects.requireNonNull(inputFName.getEditText()).setText(user.getFirstNm());
            Objects.requireNonNull(inputLName.getEditText()).setText(user.getLastNm());
            newAddressField.setText(user.getAddress().getPlaceName());
            address = user.getAddress();
            mDateOfBirth.setTime(user.getDateofbirth());
            tvDOB.setText(df.format(user.getDateofbirth()));
            Picasso.get()
                    .load(user.getImage())
                    .placeholder(R.mipmap.ic_launcher)
                    .fit()
                    .centerCrop()
                    .into(imgProfile);
            btnSave.setEnabled(true);
            Helpers.hideDialog(progressBar);

        });
    }

    public void setDate(View view) {
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = df.format(mDateOfBirth.getTime());
        Calendar dateOfBirthTemp = Calendar.getInstance();
        dateOfBirthTemp.set(Calendar.YEAR, year);
        dateOfBirthTemp.set(Calendar.MONTH, month);
        dateOfBirthTemp.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        Calendar minimumAge = Calendar.getInstance();
        minimumAge.add(Calendar.YEAR, -18);

        if (dateOfBirthTemp.before(minimumAge)) {
            tvDOB.setError(null);
            Log.e(TAG, "Task Date:" + Helpers.showTime(mDateOfBirth, "dd/MM/yyyy"));
            //update Birthdate
            mDateOfBirth.set(Calendar.YEAR, year);
            mDateOfBirth.set(Calendar.MONTH, month);
            mDateOfBirth.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            date = df.format(mDateOfBirth.getTime());
            tvDOB.setText(date);
        } else {
            tvDOB.setFocusableInTouchMode(true);
            tvDOB.setError("You must be 18 or over to use this app!");
            tvDOB.requestFocus();
            tvDOB.setFocusableInTouchMode(false);
            tvDOB.setInputType(InputType.TYPE_NULL);
            tvDOB.setText(date);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSave:
                updateInformation();
                break;
//            case R.id.tvDateOfbirth:
//                dtpDate.show();
//                break;
            case R.id.iv_profilepicture:
                ChangePhotoDialog dialog = new ChangePhotoDialog();
                dialog.show(getSupportFragmentManager(), getString(R.string.dialog_change_photo));
                break;
        }
    }

    @Override
    public void getImagePath(Uri imagePath, String tag) {
        if (!TextUtils.isEmpty(imagePath.toString())) {
            mSelectedImageUri = imagePath;
            Log.d(TAG, "getImagePath: got the image uri: " + mSelectedImageUri);
            Picasso.get().load(imagePath).into(imgProfile);
        }
    }

    public void uploadNewPhoto(Uri imageUri) {
        Log.d(TAG, "uploadNewPhoto: uploading new profile photo to firebase storage.");
        BackgroundImageResize resize = new BackgroundImageResize(this);
        resize.execute(imageUri);
    }

    public static class BackgroundImageResize extends AsyncTask<Uri, Integer, byte[]> {

        private WeakReference<EditUserActivity> editUserActivityWeakReference;
        Bitmap mBitmap;

        BackgroundImageResize(EditUserActivity context) {
            editUserActivityWeakReference = new WeakReference<>(context);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected byte[] doInBackground(Uri... params) {
            Log.d(TAG, "doInBackground: started.");

            if (mBitmap == null) {
                InputStream iStream = null;

                Log.d(TAG, "Bitmap == null");
                try {
                    iStream = editUserActivityWeakReference.get().getContentResolver().openInputStream(params[0]);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                if (iStream != null) {
                    ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
                    int bufferSize = 1024;
                    byte[] buffer = new byte[bufferSize];

                    int len;
                    try {
                        while ((len = iStream.read(buffer)) != -1) {
                            byteBuffer.write(buffer, 0, len);
                        }
                        iStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    return byteBuffer.toByteArray();
                }
                return null;

            } else {
                int size = mBitmap.getRowBytes() * mBitmap.getHeight();
                ByteBuffer byteBuffer = ByteBuffer.allocate(size);
                mBitmap.copyPixelsToBuffer(byteBuffer);
                byte[] bytes = byteBuffer.array();
                byteBuffer.rewind();
                return bytes;
            }
        }


        @Override
        protected void onPostExecute(byte[] bytes) {
            super.onPostExecute(bytes);
            EditUserActivity activity = editUserActivityWeakReference.get();
            Helpers.showDialog(activity.progressBar);
            activity.mBytes = bytes;
            //execute the upload
            activity.executeUploadTask();
        }
    }

    private void executeUploadTask() {
        FilePaths filePaths = new FilePaths();
        final StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                .child(filePaths.FIREBASE_IMAGE_STORAGE + "/" + Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid()
                        + "/profile_image"); //just replace the old image with the new one

        if (mBytes.length / MB < MB_THRESHOLD) {

            new StorageMetadata.Builder()
                    .setContentType("image/jpg")
                    .setContentLanguage("en") //see nodes below
                    .setCustomMetadata("Mitch's special meta data", "JK nothing special here")
                    .setCustomMetadata("location", "Iceland")
                    .build();
//            uploadTask = storageReference.putBytes(mBytes, metadata);
            UploadTask uploadTask = storageReference.putBytes(mBytes); //without metadata

            uploadTask.addOnSuccessListener(taskSnapshot -> storageReference.getDownloadUrl().addOnSuccessListener(uri -> {
                Log.d(TAG, "onSuccess: firebase download url : " + uri.toString());
                DocumentReference userRef = db.collection("users").document(FirebaseAuth.getInstance().getCurrentUser().getUid());
                userRef.update(getString(R.string.field_profile_photo), uri.toString());
                Helpers.showToast(EditUserActivity.this, "Updated Successfully");
                Helpers.hideDialog(progressBar);
                finish();

            })).addOnFailureListener(exception -> {
                Helpers.showToast(EditUserActivity.this, "could not upload photo");
                Helpers.hideDialog(progressBar);
            }).addOnProgressListener(taskSnapshot -> {
                double currentProgress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                if (currentProgress > (progress + 15)) {
                    progress = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                    Log.d(TAG, "onProgress: Upload is " + progress + "% done");
                }
            })
            ;
        } else {
            Helpers.showToast(this, "Image is too Large");
            Helpers.hideDialog(progressBar);
        }

    }


    private void updateInformation() {
        if (!inputValidation.isInputEditextField(inputFName, message)
                | !inputValidation.isInputEditextField(inputLName, message)
        ) {
            Helpers.showToast(this, "Some Errors Happened! Please Check Your Detail Again!");
            return;
        }


        if (address == null) {
            Helpers.showToast(this, "Please Enter Address!");
            return;
        }

        String fName = Objects.requireNonNull(inputFName.getEditText()).getText().toString().trim();
        String lName = Objects.requireNonNull(inputLName.getEditText()).getText().toString().trim();

        updateUser(fName, lName);

    }

    private void updateUser(String fName, String LName) {
        Helpers.showDialog(progressBar);
        //Update User Information
        DocumentReference userRef = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        userRef.update(
                getString(R.string.field_first_name), fName,
                getString(R.string.field_last_name), LName,
                getString(R.string.field_address), address,
                getString(R.string.field_birthday), mDateOfBirth.getTime()
        ).addOnSuccessListener(aVoid -> {
            Log.d(TAG, "DocumentSnapshot successfully updated!");
            //Update User Profile Picture
            if (mSelectedImageUri != null) {
                uploadNewPhoto(mSelectedImageUri);
            } else {
                Helpers.showToast(EditUserActivity.this, "Updated Successfully");
                Helpers.hideDialog(progressBar);
                finish();
            }
        }).addOnFailureListener(e -> {
            Log.w(TAG, "Error updating document", e);
            Helpers.showToast(EditUserActivity.this, "Error updating document!");
            Helpers.hideDialog(progressBar);
        });
    }
}

