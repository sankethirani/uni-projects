package com.experiments1.henry96.trippiefinaltwo.LocalDb;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutionException;

public class Repository {

    private NotificationDao notificationDao;
    private LiveData<List<Notification>> notificationList;

    public Repository(Application application) {
        notificationDao = LocalDatabase.getInstance(application).notificationDao();
        notificationList = notificationDao.getAllNotifications();
    }

    public LiveData<List<Notification>> getNoteList() {
        return notificationList;
    }

    public long insertNote(Notification note) {
        try {
            return new insertNoteAsynceTask(notificationDao).execute(note).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public void updateNote(Notification note) {
        new updateNoteAsynceTask(notificationDao).execute(note);
    }

    public void deleteNote(Notification note) {
        new deleteNoteAsynceTask(notificationDao).execute(note);
    }


    private static class insertNoteAsynceTask extends AsyncTask<Notification, Void, Long> {
        private NotificationDao notificationDao;

        public insertNoteAsynceTask(NotificationDao noteDao) {
            this.notificationDao = noteDao;
        }

        @Override
        protected Long doInBackground(Notification... notes) {
            return notificationDao.addNotification(notes[0]);
        }

    }

    private static class updateNoteAsynceTask extends AsyncTask<Notification, Void, Void> {
        private NotificationDao noteDao;

        public updateNoteAsynceTask(NotificationDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Notification... notes) {
            noteDao.updateNotificatione(notes[0]);
            return null;
        }
    }

    private static class deleteNoteAsynceTask extends AsyncTask<Notification, Void, Void> {
        private NotificationDao noteDao;

        public deleteNoteAsynceTask(NotificationDao noteDao) {
            this.noteDao = noteDao;
        }

        @Override
        protected Void doInBackground(Notification... notes) {
            noteDao.deleteNotification(notes[0]);
            return null;
        }
    }


}
