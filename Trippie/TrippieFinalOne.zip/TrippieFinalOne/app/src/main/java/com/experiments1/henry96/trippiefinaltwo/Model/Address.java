package com.experiments1.henry96.trippiefinaltwo.Model;
import com.google.firebase.firestore.GeoPoint;



public class Address {
    private String placeName;
    private GeoPoint placeLocation;

    public Address(String placeName, GeoPoint placeLocation) {
        this.placeName = placeName;
        this.placeLocation = placeLocation;
    }

    public Address() {
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public GeoPoint getPlaceLocation() {
        return placeLocation;
    }

    public void setPlaceLocation(GeoPoint placeLocation) {
        this.placeLocation = placeLocation;
    }
}
