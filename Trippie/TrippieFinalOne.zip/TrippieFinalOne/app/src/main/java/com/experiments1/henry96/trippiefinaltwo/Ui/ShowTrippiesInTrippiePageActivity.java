package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippieDetailFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippieOnTheWayFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippiePendingFragment;
import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

public class ShowTrippiesInTrippiePageActivity extends AppCompatActivity {

    private Fragment secondFragment;
    private Trippie trippie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_trippies_in_trippie_page);

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        String trippieId = getIntent().getStringExtra("TrippieId");
        boolean trippieExpired = getIntent().getBooleanExtra("expired", false);
        boolean isbeingDelivery = getIntent().getBooleanExtra("beingDelivery", false);
        TrippieDetailFragment detailFragment = new TrippieDetailFragment(false);
        Bundle bundle = new Bundle();
        bundle.putString("TrippieId", trippieId);
        detailFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.linearContain, detailFragment);

        if (trippieExpired) fragmentTransaction.commit();
        else {
            assert trippieId != null;
            DocumentReference docRef = db.collection("trippies").document(trippieId);
            docRef.get().addOnSuccessListener(documentSnapshot -> {
                trippie = documentSnapshot.toObject(Trippie.class);
                Bundle bundle1 = new Bundle();
                if (trippie.getStatus() != null) {
                    secondFragment = new TrippieOnTheWayFragment();
                    if (trippie.getStatusDetails() != null) {
                        bundle1.putString("TrippieId", trippieId);
                    }

                } else {
                    secondFragment = new TrippiePendingFragment();
                    bundle1.putString("trippieID", trippieId);

                    if (isbeingDelivery) {
                        bundle1.putBoolean("beingDelivery", true);
                    }
                }

                secondFragment.setArguments(bundle1);
                fragmentTransaction.add(R.id.linearTrippieDetail, secondFragment).commit();
            });
        }
    }
}
