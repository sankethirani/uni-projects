package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.LocalDb.Notification;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.github.abdularis.civ.CircleImageView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class Notification_Display_Adapter extends ListAdapter<Notification, Notification_Display_Adapter.NotificationViewHolder> {

    private OnItemClickListener mListener;
    private Context context;
    private static final String TAG = "Notification_Display_Ad";

    private SparseBooleanArray selected_items;
    private int current_selected_idx = -1;


    public Notification_Display_Adapter(Context context) {
        super(diffCallback);
        this.context = context;
        selected_items = new SparseBooleanArray();
    }

    private static final DiffUtil.ItemCallback<Notification> diffCallback = new DiffUtil.ItemCallback<Notification>() {
        @Override
        public boolean areItemsTheSame(@NonNull Notification oldItem, @NonNull Notification newItem) {
            return oldItem.getNotificationId() == newItem.getNotificationId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Notification oldItem, @NonNull Notification newItem) {
            return oldItem.getBody().equals(newItem.getBody())
                    && oldItem.getImageUrl().equals(newItem.getImageUrl())
                    && oldItem.getTime().equals(newItem.getTime())
                    && oldItem.getTitle().equals(newItem.getTitle())
                    && oldItem.getTrippieId().equals(newItem.getTrippieId())
                    && oldItem.getTrippieName().equals(newItem.getTrippieName())
                    && oldItem.getType().equals(newItem.getType())
                    ;
        }
    };


    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    //set Onclick interface
    public interface OnItemClickListener {
        void onItemEditClick(Notification notification, int pos);

        void onItemLongClick(int pos);
    }

    public Notification getNoteAt(int position) {
        return getItem(position);
    }


    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_notification_item, parent, false);
        return new NotificationViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        Notification currentItem = getItem(position);
        if (currentItem != null && currentItem.getTrippieId() != null) {
            holder.bind(currentItem, context);
            toggleCheckedIcon(holder, position);
        }
    }


    private void toggleCheckedIcon(NotificationViewHolder holder, int position) {
        if (selected_items.get(position, false)) {
            holder.lyt_parent.setBackgroundColor(Color.parseColor("#004FB6"));
            if (current_selected_idx == position) resetCurrentIndex();
        } else {
            holder.lyt_parent.setBackgroundColor(Color.parseColor("#FFFFFF"));
            if (current_selected_idx == position) resetCurrentIndex();
        }
    }

    public void toggleSelection(int pos) {
        current_selected_idx = pos;
        if (selected_items.get(pos, false)) {
            selected_items.delete(pos);
        } else {
            selected_items.put(pos, true);
        }
        notifyItemChanged(pos);
    }


    public void clearSelections() {
        selected_items.clear();
        notifyDataSetChanged();
    }


    public int getSelectedItemCount() {
        return selected_items.size();
    }

    public List<Integer> getSelectedItems() {
        List<Integer> items = new ArrayList<>(selected_items.size());
        for (int i = 0; i < selected_items.size(); i++) {
            items.add(selected_items.keyAt(i));
        }
        return items;
    }


    private void resetCurrentIndex() {
        current_selected_idx = -1;
    }


    class NotificationViewHolder extends RecyclerView.ViewHolder {
        private CircleImageView imgTrippie;
        private ImageView imgNotificationType;
        private ImageView imgStatus;
        private TextView tvTrippieTitle, tvContent;
        private View lyt_parent;


        NotificationViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            imgTrippie = itemView.findViewById(R.id.imgTripe);
            imgNotificationType = itemView.findViewById(R.id.imgNotificationType);
            imgStatus = itemView.findViewById(R.id.imgStatus);
            tvTrippieTitle = itemView.findViewById(R.id.tvTrippieTitle);
            tvContent = itemView.findViewById(R.id.tvNotificationContent);
            lyt_parent = itemView.findViewById(R.id.lyt_parent);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemEditClick(getItem(position), position);
                }
            });

            itemView.setOnLongClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemLongClick(position);
                }
                return true;
            });
        }

        void bind(Notification notification, Context context) {
            String content = notification.getBody();
            if (notification.getType().equals(Helpers.Key_Job)) {
                imgNotificationType.setImageDrawable(context.getDrawable(R.drawable.jobs));
            } else if (notification.getType().equals(Helpers.Key_Trippie)) {
                try {
                    imgNotificationType.setImageDrawable(context.getDrawable(R.drawable.trippies));
                    content = notification.getBody().substring(0, notification.getBody().indexOf('['));
                } catch (StringIndexOutOfBoundsException ex) {
                    Log.e(TAG, Objects.requireNonNull(ex.getMessage()));
                }

            } else if (notification.getType().equals(Helpers.Key_Driver_Accept)) {
                imgNotificationType.setImageDrawable(context.getDrawable(R.drawable.ic_truck));
            } else if (notification.getType().equals(Helpers.Key_Trippie_Refund)) {
                imgNotificationType.setImageDrawable(context.getDrawable(R.drawable.trippies));
            }
            tvTrippieTitle.setText(notification.getTrippieName());


            tvContent.setText(content);

            FirebaseStorage storage = FirebaseStorage.getInstance();
            StorageReference sr = storage.getReference();
            sr.child("images/trippies/" + notification.getImageUrl()).getDownloadUrl().addOnSuccessListener(uri -> Picasso.get()
                    .load(uri)
                    .placeholder(R.drawable.null_image)
                    .fit()
                    .centerCrop()
                    .into(imgTrippie));


        }
    }
}
