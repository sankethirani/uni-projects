package com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Fragment.ChangePhotoDialog;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class DeliveredFragment extends Fragment implements View.OnClickListener, ChangePhotoDialog.OnPhotoReceivedListener,
        SignatureDialogFragment.onSignatureDialogFragmentListeners {

    private static final String TAG = "DeliveredFragment";
    private final int resourceID = R.layout.fragment_complete_status;
    private DeliveredFragmentClickListener deliveredFragmentClickListener;
    private Button btnSubmit;

    private ImageView imgDelivery1, imgDelivery2, imgSign, imgCall, imgChat;
    private ArrayList<Uri> mSelectedImageUris;
    private TextView tvsign, tvPickupName;

    private RelativeLayout loadingCircle;
    private FrameLayout createContainer;

    private byte[] signaturebytes;

    private PickedUpFragment.onPickupFragmentClickListener communicateOnClickListener;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnCompleteDelivery:
                if (mSelectedImageUris != null && mSelectedImageUris.size() >= 2) {
                    if (signaturebytes != null && signaturebytes.length != 0)
                        loadCircle();
                }
                deliveredFragmentClickListener.onSubmitTrippie();
                break;
            case R.id.imgImage:
                ChangePhotoDialog dialog = new ChangePhotoDialog();
                dialog.getPhotoReceiver(this);
                dialog.show(getChildFragmentManager(), "ChangePhotoDialog");
                break;
            case R.id.imgImage1:
                ChangePhotoDialog dialog2 = new ChangePhotoDialog();
                dialog2.getPhotoReceiver(this);
                dialog2.show(getChildFragmentManager(), "ChangePhotoDialog2");
                break;
            case R.id.imgImageSign:
                SignatureDialogFragment signatureDialogFragment = new SignatureDialogFragment();
                signatureDialogFragment.show(getChildFragmentManager(), "SignatureDialog");
                break;
            case R.id.imgCallUser:
                communicateOnClickListener.onCallClick();
                break;
            case R.id.imgChat:
                communicateOnClickListener.onMessageClick();
                break;
        }

    }

    private void loadCircle() {
        btnSubmit.setEnabled(false);
        btnSubmit.setText("");
        loadingCircle = (RelativeLayout) getLayoutInflater().inflate(R.layout.loading_circle, createContainer, false);
        loadingCircle.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        createContainer.addView(loadingCircle);
    }

    @Override
    public void onSaveClickListener(Bitmap bitmap, byte[] signatureBytes) {
        if (bitmap != null && signatureBytes != null) {
            imgSign.setImageBitmap(bitmap);
            this.signaturebytes = signatureBytes;
        }
    }

    public byte[] getSignaturebytes() {
        return signaturebytes;
    }

    public interface DeliveredFragmentClickListener {
        public void onSubmitTrippie();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);

        init(v);
        initListeners();

        if (getArguments() != null) {
            Boolean isSignatureRequire = getArguments().getBoolean("signatureStatus");
            if (!isSignatureRequire) {
                imgSign.setVisibility(View.GONE);
                tvsign.setVisibility(View.GONE);
            }

            String customerName = getArguments().getString("customer");
            if (customerName != null) {
                tvPickupName.setText(customerName);
            }

        }
        return v;
    }

    private void init(View v) {
        btnSubmit = v.findViewById(R.id.btnCompleteDelivery);
        imgDelivery1 = v.findViewById(R.id.imgImage);
        imgDelivery2 = v.findViewById(R.id.imgImage1);
        imgSign = v.findViewById(R.id.imgImageSign);
        tvsign = v.findViewById(R.id.tvSignatureR);
        imgCall = v.findViewById(R.id.imgCallUser);
        imgChat = v.findViewById(R.id.imgChat);
        tvPickupName = v.findViewById(R.id.tvPickUpName);
        createContainer = v.findViewById(R.id.create_button_container);
        mSelectedImageUris = new ArrayList<>();
    }

    private void initListeners() {
        btnSubmit.setOnClickListener(this);
        imgDelivery1.setOnClickListener(this);
        imgDelivery2.setOnClickListener(this);
        imgSign.setOnClickListener(this);
        imgCall.setOnClickListener(this);
        imgChat.setOnClickListener(this);
    }

    public ArrayList<Uri> getmSelectedImageUris() {
        return mSelectedImageUris;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        deliveredFragmentClickListener = (DeliveredFragmentClickListener) getActivity();
        communicateOnClickListener = (PickedUpFragment.onPickupFragmentClickListener) getActivity();
    }

    @Override
    public void getImagePath(Uri imagePath, String tag) {
        if (!TextUtils.isEmpty(imagePath.toString())) {
            if (tag.equals("ChangePhotoDialog")) {
                Picasso.get().load(imagePath).into(imgDelivery1);
                mSelectedImageUris.add(imagePath);
                Log.e(TAG, mSelectedImageUris.size() + "");
            } else if (tag.equals("ChangePhotoDialog2")) {
                Picasso.get().load(imagePath).into(imgDelivery2);
                mSelectedImageUris.add(imagePath);
                Log.e(TAG, mSelectedImageUris.size() + "");
            }


        }
    }

}
