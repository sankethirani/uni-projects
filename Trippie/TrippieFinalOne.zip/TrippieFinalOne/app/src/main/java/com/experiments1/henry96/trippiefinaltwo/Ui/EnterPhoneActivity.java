package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.WidgetCustom.CustomBackgroundTextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.w3c.dom.Text;

public class EnterPhoneActivity extends AppCompatActivity {
    private EditText phoneInputEditText;
    private Button loginButton;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private static final String TAG = "EnterPhoneActivity";

    private static final int REQUEST_CODE = 1234;


    //Firebase
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        init();
        initListeners();

        verifyStoragePermissions();
        setupfirebase();
    }

    public void verifyStoragePermissions() {
        Log.d(TAG, "verifyPermissions: asking user for permissions.");
        String[] permissions = {android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA, Manifest.permission.CALL_PHONE};

        boolean allPermissionsGranted = true;
        for (String permission : permissions)
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        if (!allPermissionsGranted) {

            ActivityCompat.requestPermissions(
                    EnterPhoneActivity.this,
                    permissions,
                    REQUEST_CODE
            );
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        try {
            Log.d(TAG, "onRequestPermissionsResult: requestCode: " + requestCode);
            if (requestCode == REQUEST_CODE && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "onRequestPermissionsResult: User has allowed permission to access: " + permissions[0]);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void init() {
        phoneInputEditText = findViewById(R.id.phone_edit_text);
        loginButton = findViewById(R.id.login_button);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    private void initListeners() {
        phoneInputEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (phoneInputEditText.getText().toString().length() == 9 || phoneInputEditText.getText().toString().length() == 10) {
                    loginButton.setEnabled(true);
                    loginButton.setBackgroundResource(R.drawable.custom_button_blue);
                    loginButton.setText(R.string.text_login);
                } else {
                    loginButton.setEnabled(false);
                    loginButton.setBackgroundResource(R.drawable.custom_button_disabled);
                    loginButton.setText(R.string.enter_mobile_number_text);
                }
            }
        });
    }

    public void verifyPhoneNumber(View v) {
        String number = phoneInputEditText.getText().toString();

        String phoneNumber = getString(R.string.country_code_prefix) + number;
        Intent intent = new Intent(EnterPhoneActivity.this, VerifyPhoneActivity.class);
        intent.putExtra("phonenumber", phoneNumber);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    //set up firebase
    public void setupfirebase() {
        mAuthListener = firebaseAuth -> {
            Log.e(TAG, "onAuthStateChanged!");
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null && mAuth.getUid() != null) {
                String currentUserId = mAuth.getUid();
                DocumentReference userRef = db.collection("users").document(currentUserId);
                userRef.get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot documentSnapshot = task.getResult();
                        //If user record exists in database
                        if (documentSnapshot != null && documentSnapshot.exists()) {
                            Intent intent = new Intent(EnterPhoneActivity.this, HomeActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                        //clear user form currently being logged in
                        else {
                            mAuth.signOut();
                        }
                    }
                });
            } else {
                Log.e(TAG, "signed_out");
            }
        };
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mAuthListener != null) {
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }
}
