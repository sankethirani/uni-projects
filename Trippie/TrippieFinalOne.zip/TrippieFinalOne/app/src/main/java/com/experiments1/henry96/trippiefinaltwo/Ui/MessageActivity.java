package com.experiments1.henry96.trippiefinaltwo.Ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.experiments1.henry96.trippiefinaltwo.Adapter.MessageAdapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Message;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class MessageActivity extends AppCompatActivity implements View.OnClickListener{
    private CircleImageView chatUserImage;
    private TextView tvChatName;
    private Intent intent;
    private ImageButton btnSend;
    private EditText editTextChatMessage;

    private FirebaseAuth mAuth;
    private DatabaseReference rootRef;
    private DatabaseReference notificationsRef;

    private String senderId;
    private String receiverId;

    private RecyclerView messagesRecyclerView;

    private final List<Message> messageList = new ArrayList<>();
    private LinearLayoutManager linearLayoutManager;
    private MessageAdapter messageAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        init();
        initListeners();
        initObjects();
        setUpToolbar();
    }


    private void init() {
        chatUserImage = findViewById(R.id.chatUserImage);
        tvChatName = findViewById(R.id.chatUserName);
        btnSend = findViewById(R.id.sendButton);
        editTextChatMessage = findViewById(R.id.messageToSend);
        messagesRecyclerView = findViewById(R.id.chatRecyclerView);

        //SKH Having trouble connecting to the database
        //System.out.println("INITIALIZING APP FROM PID: " + android.os.Process.myPid());
        rootRef = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        intent = getIntent();
    }

    private void initListeners() {
        btnSend.setOnClickListener(this);
    }

    private void initObjects() {
        senderId = mAuth.getUid();
        notificationsRef = rootRef.child("Notifications");
        receiverId = intent.getStringExtra("receiver_id");
        messageAdapter = new MessageAdapter(messageList, this);
        linearLayoutManager = new LinearLayoutManager(this);
        messagesRecyclerView.setLayoutManager(linearLayoutManager);
        messagesRecyclerView.setAdapter(messageAdapter);
    }

    private void setUpToolbar() {
        Toolbar toolbar = findViewById(R.id.chatToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(view -> finish());

        tvChatName.setText(intent.getStringExtra("chat_username"));
        Picasso.get()
                .load(intent.getStringExtra("chat_user_image"))
                .fit()
                .centerCrop()
                .into(chatUserImage, new com.squareup.picasso.Callback() {
                    @Override
                    public void onSuccess() {
                        storeImageToSharedPreferences();
                    }

                    @Override
                    public void onError(Exception e) {
                        Log.e("Failed Picasso.load", e.getMessage());
                    }
                });
    }

    private void storeImageToSharedPreferences() {
        SharedPreferences myPreference = this.getSharedPreferences("chatProfileImages",MODE_PRIVATE);
        SharedPreferences.Editor editor = myPreference.edit();
        editor.putString(receiverId, encodeToBase64(((BitmapDrawable)chatUserImage.getDrawable()).getBitmap()));
        editor.apply();
    }

    private String encodeToBase64(Bitmap bitmap) {
        Bitmap image = bitmap;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String imageEncoded = Base64.encodeToString(b, Base64.DEFAULT);
        Log.d("Image Log:", imageEncoded);
        return imageEncoded;

    }


    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.sendButton:
                sendMessage();
        }
    }

    private void sendMessage(){
        String message = editTextChatMessage.getText().toString();
        if(message.isEmpty()){
            Helpers.showToast(MessageActivity.this, "Please enter a message to send");
        }
        else{
            //SKH create the two database reference points to where the message will be saved
            String senderRef = "chats/" + senderId + "/" + receiverId;
            String receiverRef = "chats/" + receiverId + "/" + senderId;

            //SKH Get the auto generated Id for the reference point of the message
            DatabaseReference messageKeyRef = rootRef.child("chats")
                    .child(senderId).child(receiverId).push();
            String messageId = messageKeyRef.getKey();

            //Create object of message to send
            Message messageToSend = new Message(message, senderId, "text");


            //Create two Map objects to where the data is saved
            Map messageDetails = new HashMap();
            messageDetails.put(senderRef + "/" + messageId, messageToSend);
            messageDetails.put(receiverRef + "/" + messageId, messageToSend);

            rootRef.updateChildren(messageDetails).addOnCompleteListener(task -> {
                if (task.isSuccessful()){
                    Log.i("Message Sent?", "Success");
                    HashMap<String,String> chatNotificationMap = new HashMap<>();
                    chatNotificationMap.put("from", senderId);
                    chatNotificationMap.put("type", message);

                    notificationsRef.child(receiverId).push().setValue(chatNotificationMap).addOnCompleteListener(task1 -> {
                        if (task1.isSuccessful()){
                            Log.d("Notification", "notification sent");
                        }
                        else{
                            Toast.makeText(MessageActivity.this, "Failed to send message", Toast.LENGTH_LONG).show();
                        }
                    });

                }
                else{
                    Toast.makeText(MessageActivity.this, "Failed to send message", Toast.LENGTH_LONG).show();
                }
                editTextChatMessage.setText("");
            });
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        rootRef.child("chats").child(senderId).child(receiverId).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Message message = dataSnapshot.getValue(Message.class);
                messageList.add(message);
                messageAdapter.notifyDataSetChanged();

                //automatically scroll to the bottom of the chats
                messagesRecyclerView.smoothScrollToPosition(messagesRecyclerView.getAdapter().getItemCount());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
