package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Helper.PackageType;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.CreateTrippieActivity;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.TypeFilter;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.api.Distribution;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.functions.FirebaseFunctions;
import com.google.firebase.functions.FirebaseFunctionsException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


public class CreateTrippieFirstStepFragment extends Fragment {

    private String destinationString = "", pickupString = "", distanceInKmsString, sizeString, animalString;
    private View v;
    private EditText priceEditText;
    private Location destination, pickup;
    private double distanceInKms, durationHoursDouble, flatFee, litresPerHundredKm, roundPrice, hourlyRate = 2, animalCost;
    private int sizeFee;
    private TextView destinationSearch, pickupLocationSearch, estimateTextView, focusedView;
    private LinearLayout afterLocationLayout, secondRadioHolder;
    private RadioButton itemButton, petButton, liveStockButton;
    private Button nextPageButton, pickupClearButton, destinationClearButton;
    private CheckBox featuredCheckBox, urgentCheckBox;
    private CreateTrippieSecondStepFragment secondStepFragment;
    private CreateTrippieThirdStepFragment thirdStepFragment;
    private CreateTrippieFourthStepFragment fourthStepFragment;
    private boolean isRelist;
    private Trippie relistTrippie;
    private FirebaseFunctions mFunctions;
    private JSONObject jsonObject;
    private LinearLayout loadingCircle;

    public CreateTrippieFirstStepFragment(CreateTrippieSecondStepFragment secondStepFragment, CreateTrippieThirdStepFragment thirdStepFragment,CreateTrippieFourthStepFragment fourthStepFragment){
        this.secondStepFragment = secondStepFragment;
        this.thirdStepFragment = thirdStepFragment;
        this.fourthStepFragment = fourthStepFragment;
    }

    public void relistTrippieAfterLayoutInitialised(Trippie trippie){
        isRelist = true;
        relistTrippie = trippie;
        destination = new Location("whatever");
        pickup = new Location("whatever");
        destination.setLatitude(trippie.getDeliveryLocation().getLatitude());
        destination.setLongitude(trippie.getDeliveryLocation().getLongitude());

        pickup.setLatitude(trippie.getPickupLocation().getLatitude());
        pickup.setLongitude(trippie.getPickupLocation().getLongitude());
        pickupString = trippie.getPickupAddress();
        destinationString = trippie.getDeliveryAddress();
        focusedView = destinationSearch;
        destinationSearch.setText(destinationString.replace(", New Zealand", ""));
        focusedView = pickupLocationSearch;
        pickupLocationSearch.setText(pickupString.replace(", New Zealand", ""));

        destinationActions();
    }

    private void doAfterRelistInitialised(){
        switch(PackageType.valueOf(relistTrippie.getCategory())){
            case Pet:
                petButton.performClick();
                break;
            case Item:
                itemButton.performClick();
                break;
            case Livestock:
                liveStockButton.performClick();
                break;
        }

        secondStepFragment.relistTrippieAfterLayoutInitialised(relistTrippie);
        thirdStepFragment.relistTrippieAfterLayoutInitialised(relistTrippie);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_create_trippie_first_step, container, false);
        initialiseLayout();
        setOnClickListeners();
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).setViewCreated(0);
    }

    private void initialiseLayout() {
        estimateTextView = v.findViewById(R.id.estimated_price_text);
        featuredCheckBox = v.findViewById(R.id.featured_delivery_checkbox);
        urgentCheckBox = v.findViewById(R.id.urgent_checkbox);
        v.findViewById(R.id.checkbox_label).setSelected(true);
        afterLocationLayout = v.findViewById(R.id.afterLocationLinear);
        itemButton = v.findViewById(R.id.item_button);
        petButton = v.findViewById(R.id.pet_button);
        liveStockButton = v.findViewById(R.id.livestock_button);
        secondRadioHolder = v.findViewById(R.id.second_radio_holder);
        nextPageButton = v.findViewById(R.id.create_trippie_first_page_next_button);
        pickupClearButton = v.findViewById(R.id.pickup_clear_button);
        destinationClearButton = v.findViewById(R.id.destination_clear_button);
        priceEditText = v.findViewById(R.id.edit_price_text);
        pickupLocationSearch = v.findViewById(R.id.pickup_location_search);
        destinationSearch = v.findViewById(R.id.destination_search);
        mFunctions = FirebaseFunctions.getInstance();
        // Initialize the SDK
        Places.initialize(Objects.requireNonNull(getActivity()).getApplicationContext(), getString(R.string.google_places_key));

        LinearLayout circleHolder = new LinearLayout(getContext());
        loadingCircle = (LinearLayout) getLayoutInflater().inflate(R.layout.loading_circle, circleHolder);
        loadingCircle.setVisibility(View.GONE);
        ((ViewGroup) pickupLocationSearch.getParent().getParent()).addView(circleHolder);
    }

    private void setOnClickListeners() {
        itemButton.setOnClickListener(c -> {
            StandardVehicleTypesFragment f = new StandardVehicleTypesFragment(false, this);
            radioHolderContentChanger(secondRadioHolder, f, "Items1");
            animalString = null; animalCost = 0; flatFee = 0; sizeString = ""; thirdStepFragment.setPackageType(PackageType.Item);
            if(isRelist) f.setRelistVehicleSize(relistTrippie.getSize());
        });
        liveStockButton.setOnClickListener(c -> {
            AnimalTypeFragment f = new AnimalTypeFragment(false, this);
            radioHolderContentChanger(secondRadioHolder, f, "Live1");
            animalCost = 0; sizeString = ""; flatFee = 45; thirdStepFragment.setPackageType(PackageType.Livestock);
            if(isRelist) {
                String[] sizeArray = relistTrippie.getSize().split(";");
                f.setRelistProperties(relistTrippie.getQuantity(), sizeArray[0], sizeArray[1].trim());
            }
        });
        petButton.setOnClickListener(c -> {
            AnimalTypeFragment f = new AnimalTypeFragment(true, this);
            radioHolderContentChanger(secondRadioHolder, f, "Pets1");
            animalCost = 0; sizeString = ""; flatFee = 10; thirdStepFragment.setPackageType(PackageType.Pet);
            if(isRelist) {
                String[] sizeArray = relistTrippie.getSize().split(";");
                f.setRelistProperties(relistTrippie.getQuantity(), sizeArray[0], sizeArray[1].trim());
            }
        });
        pickupClearButton.setOnClickListener(c -> {
            pickupLocationSearch.setText(pickupString = "");
            pickupLocationSearch.setEnabled(true);
            if (afterLocationLayout.getVisibility() == View.VISIBLE) clearButtonClickedAfterSearch();
        });
        destinationClearButton.setOnClickListener(c -> {
            destinationSearch.setText(destinationString = "");
            destinationSearch.setEnabled(true);
            if(afterLocationLayout.getVisibility() == View.VISIBLE) clearButtonClickedAfterSearch();
        });
        featuredCheckBox.setOnClickListener(c -> {
            if(sizeFee != 0 && !sizeString.isEmpty() && (animalCost != 0|| flatFee == 0)) calculatePrice();
            fourthStepFragment.getTrippie().setFeatured(featuredCheckBox.isChecked());
        });
        urgentCheckBox.setOnClickListener(c->{
            featuredCheckBox.setChecked(urgentCheckBox.isChecked());
            featuredCheckBox.setEnabled(!urgentCheckBox.isChecked());
            fourthStepFragment.getTrippie().setUrgent(urgentCheckBox.isChecked());
            if(urgentCheckBox.isChecked()) fourthStepFragment.getTrippie().setFeatured(true);
            featuredCheckBox.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(Objects.requireNonNull(getContext()), featuredCheckBox.isEnabled() ? R.color.main_colour_blue : R.color.text_colour_grey)));
            if(sizeFee != 0 && !sizeString.isEmpty() && (animalCost != 0|| flatFee == 0)) calculatePrice();
        });

        nextPageButton.setOnClickListener(c -> ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(1,true));

        priceEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void afterTextChanged(Editable editable) {
                if(!editable.toString().isEmpty()) {
                    if (!estimateTextView.getText().toString().equals(getString(R.string.estimate_text_unfinished))) {
                        if (Double.parseDouble(editable.toString()) < roundPrice){
                            priceEditText.setError("Custom price must be above estimated price");
                            setNextPageButtonEnabled(false);
                        }
                        else if (Double.parseDouble(editable.toString()) > roundPrice * 2) {
                            priceEditText.setError("Custom price must be less than double estimated price");
                            setNextPageButtonEnabled(false);
                        }
                        else {
                            priceEditText.setError(null);
                            setNextPageButtonEnabled(true);
                            fourthStepFragment.getTrippie().setPrice(Double.parseDouble(priceEditText.getText().toString()));
                        }
                    } else setNextPageButtonEnabled(false);
                }
            }
        });

        TextView.OnClickListener searchListener = view -> {
            focusedView = (TextView)view;
            Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, Arrays.asList(Place.Field.LAT_LNG, Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS))
                    .setCountry("NZ").setTypeFilter(TypeFilter.ADDRESS).build(Objects.requireNonNull(getContext()));
            startActivityForResult(intent, 223);
        };

        pickupLocationSearch.setOnClickListener(searchListener);
        pickupLocationSearch.addTextChangedListener(locationFilterTextWatcher);
        destinationSearch.setOnClickListener(searchListener);
        destinationSearch.addTextChangedListener(locationFilterTextWatcher);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 223) {
            if (resultCode == Activity.RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                if(destinationSearch.equals(focusedView)){
                    destination = new Location("");
                    destination.setLatitude(Objects.requireNonNull(place.getLatLng()).latitude);
                    destination.setLongitude(place.getLatLng().longitude);
                    destinationSearch.setText(Objects.requireNonNull(place.getAddress()).replace(", New Zealand", ""));
                    destinationString = place.getAddress();
                }
                else{
                    pickup = new Location("");
                    pickup.setLatitude(Objects.requireNonNull(place.getLatLng()).latitude);
                    pickup.setLongitude(place.getLatLng().longitude);
                    pickupLocationSearch.setText(Objects.requireNonNull(place.getAddress()).replace(", New Zealand", ""));
                    pickupString = place.getAddress();
                }
                if(!destinationString.isEmpty() && !pickupString.isEmpty()) destinationActions();
            }
        }
    }

    private void radioHolderContentChanger(LinearLayout radioHolder, Fragment fragment, String tag) {
        if (radioHolder.getChildCount() > 0) {
            if (getChildFragmentManager().findFragmentByTag(tag) == null) {
                getChildFragmentManager().beginTransaction().replace(radioHolder.getId(), fragment, tag).commit();
                reinitialiseFields();
            }
        } else {
            radioHolder.setVisibility(View.VISIBLE);
            getChildFragmentManager().beginTransaction().add(radioHolder.getId(), fragment, tag).commit();
        }
    }

    private void clearButtonClickedAfterSearch(){
        afterLocationLayout.setVisibility(View.GONE);
        nextPageButton.setVisibility(View.GONE);
        ((RadioGroup)v.findViewById(R.id.radioGroupCategory)).clearCheck();
        Fragment secondHolderFragment = getChildFragmentManager().findFragmentById(R.id.second_radio_holder);
        if(secondHolderFragment != null) {
            getChildFragmentManager().beginTransaction().remove(secondHolderFragment);
            if (secondRadioHolder.getChildCount() > 0) {
                secondRadioHolder.removeAllViews();
                reinitialiseFields();
            }
        }

        priceEditText.clearFocus();
    }

    private TextWatcher locationFilterTextWatcher = new TextWatcher() {
        public void afterTextChanged(Editable s) {
            if (!s.toString().equals("")) {
                focusedView.setEnabled(false);
                focusedView.setFocusable(false);
            }
        }
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
        public void onTextChanged(CharSequence s, int start, int before, int count) { }
    };

    private void destinationActions(){
        loadingCircle.setVisibility(View.VISIBLE);
        pickupClearButton.setEnabled(false);
        destinationClearButton.setEnabled(false);

        distanceInKms = calculateDistance(destination, pickup);

        double roundDistance = round(distanceInKms);
        distanceInKmsString = roundDistance + " km";

        callDirectionsAPI().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Exception e = task.getException();
                if (e instanceof FirebaseFunctionsException) {
                    FirebaseFunctionsException ffe = (FirebaseFunctionsException) e;
                    FirebaseFunctionsException.Code code = ffe.getCode();
                    Object details = ffe.getDetails();
                    Log.d("error", code + " " + details);
                }
            }
            else{
                try {
                    JSONArray routes = jsonObject.getJSONArray("routes");

                    pickupClearButton.setEnabled(true);
                    destinationClearButton.setEnabled(true);

                    if (!Objects.requireNonNull(routes).toString().equals("[]")) {

                        String durationNumberString = routes.getJSONObject(0).getJSONArray("legs").getJSONObject(0).getJSONObject("duration").getString("value");
                        secondStepFragment.setMinimumTravelTime((int) Double.parseDouble(durationNumberString) / 60);
                        durationHoursDouble = CreateTrippieFirstStepFragment.this.round(Double.parseDouble(durationNumberString) / 3600);

                        destinationSearch.setSelected(false);
                        pickupLocationSearch.setSelected(false);
                        afterLocationLayout.setVisibility(View.VISIBLE);
                        nextPageButton.setVisibility(View.VISIBLE);
                        if (isRelist) CreateTrippieFirstStepFragment.this.doAfterRelistInitialised();
                        Trippie trippie = fourthStepFragment.getTrippie();
                        trippie.setPickupLocation(new GeoPoint(pickup.getLatitude(), pickup.getLongitude()));
                        trippie.setPickupAddress(pickupString);
                        trippie.setDeliveryLocation(new GeoPoint(destination.getLatitude(), destination.getLongitude()));
                        trippie.setDeliveryAddress(destinationString);
                        String kmString = Double.parseDouble(routes.getJSONObject(0).getJSONArray("legs").getJSONObject(0).getJSONObject("distance").getString("value"))/1000d + " km";
                        fourthStepFragment.getTrippie().setDistanceText(kmString);
                        fourthStepFragment.getTrippie().setPolyline(routes.getJSONObject(0).getJSONObject("overview_polyline").getString("points"));
                        fourthStepFragment.refreshMapAfterPolyline();
                        loadingCircle.setVisibility(View.GONE);
                    } else {
                        pickupClearButton.performClick();
                        destinationClearButton.performClick();
                        new AlertDialog.Builder(CreateTrippieFirstStepFragment.this.getContext()).setTitle("No routes available!")
                                .setMessage("We couldn't find any routes between these locations. Please ensure a driver can safely travel between your pickup and destination.")
                                .setNeutralButton("OK", (dialogInterface, i) -> dialogInterface.dismiss()).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private Task<String> callDirectionsAPI(){
        // Create the arguments to the callable function.
        Map<String, Object> data = new HashMap<>();
        data.put("pickupLocation", pickupString);
        data.put("deliveryLocation", destinationString);
        data.put("push", true);

        return mFunctions
                .getHttpsCallable("directions")
                .call(data)
                .continueWith(task -> {
                    // This continuation runs on either success or failure, but if the task
                    // has failed then getResult() will throw an Exception which will be
                    // propagated down.
                    jsonObject = new JSONObject((Map) Objects.requireNonNull(Objects.requireNonNull(task.getResult()).getData()));

                    return task.getResult().getData().toString();
                });
    }

    private double calculateDistance(Location destination, Location pickup) {

        double distanceInMeters = (double) pickup.distanceTo(destination);
        return distanceInMeters / 1000;

    }

    private double round(double value) {
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    void setVehicleSpecs(int sizeFee, int litresPerHundredKm, String sizeString, boolean isAnimalType) {
        this.sizeFee = sizeFee;
        this.litresPerHundredKm = litresPerHundredKm;
        this.sizeString = sizeString;
        if(animalString != null) fourthStepFragment.getTrippie().setSize(sizeString + "; " + animalString);
        else fourthStepFragment.getTrippie().setSize(sizeString);
        if(!isAnimalType || (animalCost != 0 && !sizeString.isEmpty())){ calculatePrice(); setNextPageButtonEnabled(true);}
        else reinitialiseFields();
    }

    void setAnimalCost(double animalCost) {
        this.animalCost = animalCost;
        if(animalCost != 0 && !sizeString.isEmpty()){ calculatePrice(); setNextPageButtonEnabled(true); }
        else reinitialiseFields();
    }

    private void reinitialiseFields(){
        priceEditText.setText("");
        estimateTextView.setText(getResources().getString(R.string.estimate_text_unfinished));
        estimateTextView.setTextColor(ContextCompat.getColor(Objects.requireNonNull(getContext()),R.color.text_colour_red));
        setNextPageButtonEnabled(false);
        ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).disableTabs(1);
    }

    void setNextPageButtonEnabled(boolean enabled){
        nextPageButton.setEnabled(enabled);
        if (enabled) {
            nextPageButton.setText(R.string.next_button_text);
            nextPageButton.setBackgroundResource(R.drawable.custom_button_blue);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).enableTab(1, false);
            fourthStepFragment.getTrippie().setDistanceText(distanceInKmsString);
        }
        else{
            nextPageButton.setText(R.string.fill_all_fields);
            nextPageButton.setBackgroundResource(R.drawable.custom_button_disabled);
            ((CreateTrippieActivity) Objects.requireNonNull(getActivity())).disableTabs(1);
        }
    }

    private void calculatePrice() {
        double priceOfPetrol = 2.1, newPetrolPrice = priceOfPetrol - 1 + (distanceInKms / 1000), hourlyRateFactor = 2.0, litersPer100KmsFactor = 3.0,
                finishedPrice, partDistance = 1100.0, remainingHours = durationHoursDouble - 13.5, restOfDistance = distanceInKms - partDistance;

        if (durationHoursDouble > 13.5 && distanceInKms > 1100) {
            finishedPrice = (13.5 + remainingHours / 2) * hourlyRate / hourlyRateFactor + newPetrolPrice * (litresPerHundredKm / litersPer100KmsFactor) * (partDistance + restOfDistance / 2) / 100 + flatFee;
        } else {
            finishedPrice = durationHoursDouble * hourlyRate / hourlyRateFactor + newPetrolPrice * (distanceInKms / 100) * (litresPerHundredKm / litersPer100KmsFactor) + flatFee;
        }

        finishedPrice += sizeFee + animalCost;

        if (featuredCheckBox.isChecked()) {
            finishedPrice += finishedPrice > 50 ? finishedPrice * 0.1 : 5; //if featured, add $5 or 10% of the price if the price is over $50
            if(urgentCheckBox.isChecked()){
                int urgentBaseFee = 0;
                //check top radio button's text to find out category
                switch(((RadioButton)v.findViewById(((RadioGroup)v.findViewById(R.id.radioGroupCategory)).getCheckedRadioButtonId())).getText().toString()) {
                    case "Pet"      : urgentBaseFee =                                                        25; break;
                    case "Livestock": urgentBaseFee = animalString.matches("Sheep|Goat|Calf") ? 30 : 55; break;
                    case "Item"     : urgentBaseFee = sizeString.matches("Truck|Large Truck") ? 25 : 15; break;
                }
                finishedPrice += urgentBaseFee;
            }
        }

        roundPrice = round(finishedPrice);
        String priceString = Helpers.addTrailingZerosToCurrency(roundPrice);
        estimateTextView.setText(String.format(getResources().getString(R.string.currency),priceString));
        estimateTextView.setTextColor(ContextCompat.getColor(Objects.requireNonNull(getContext()),R.color.text_colour_green));
        priceEditText.setText(priceString);
    }

    void setAnimalString(String animal, int animalQuantity){
        this.animalString = animal;
        fourthStepFragment.getTrippie().setQuantity(animalQuantity);
        thirdStepFragment.setAnimalString(animal);
        if(sizeString != null) fourthStepFragment.getTrippie().setSize(sizeString + "; " + animalString);
    }

    public boolean containsData(){
        return !destinationSearch.getText().toString().isEmpty() || !pickupLocationSearch.getText().toString().isEmpty();
    }
}