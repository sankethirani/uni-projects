package com.experiments1.henry96.trippiefinaltwo.Model;

import androidx.annotation.NonNull;

import java.util.Date;


public class Vehicle {
    private String registrationNo;
    private String bodyType;
    private String make;
    private String model;
    private int year;
    private String colour;
    private String insuranceType;
    private boolean isSmokeFree;
    private boolean isActive = true;
    private boolean isVerified = false;
    private Date creationDate, insuranceExpiryDate;




    public enum BodyType {
        VAN, SEDAN, CONVERTIBLE, HATCHBACK, MOTORCYCLE, UTILITY,
        SPORTSCAR {
            @NonNull
            @Override
            public String toString() {
                return "SPORTS CAR";
            }
        },
        STATIONWAGON {
            @NonNull
            @Override
            public String toString() {
                return "STATION WAGON";
            }
        }
    }
    public enum InsuranceType {
        COMPREHENSIVE, THIRDPARTY {
            @NonNull
            @Override
            public String toString() {
                return "THIRD PARTY";
            }
        }
    }

    public Vehicle(String registrationNo, String bodyType, String make, String model, int year, String colour, String insuranceType, boolean isSmokeFree, boolean isActive, boolean isVerified, Date creationDate, Date insuranceExpiryDate) {
        this.registrationNo = registrationNo;
        this.bodyType = bodyType;
        this.make = make;
        this.model = model;
        this.year = year;
        this.colour = colour;
        this.insuranceType = insuranceType;
        this.isSmokeFree = isSmokeFree;
        this.isActive = isActive;
        this.isVerified = isVerified;
        this.creationDate = creationDate;
        this.insuranceExpiryDate = insuranceExpiryDate;
    }

    public Vehicle() {

    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public void setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
    }

    public String getBodyType() {
        return bodyType;
    }

    public void setBodyType(String bodyType) {
        this.bodyType = bodyType;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public boolean isSmokeFree() {
        return isSmokeFree;
    }

    public void setSmokeFree(boolean smokeFree) {
        isSmokeFree = smokeFree;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public boolean isVerified() {
        return isVerified;
    }

    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getInsuranceExpiryDate() {
        return insuranceExpiryDate;
    }

    public void setInsuranceExpiryDate(Date insuranceExpiryDate) {
        this.insuranceExpiryDate = insuranceExpiryDate;
    }


}
