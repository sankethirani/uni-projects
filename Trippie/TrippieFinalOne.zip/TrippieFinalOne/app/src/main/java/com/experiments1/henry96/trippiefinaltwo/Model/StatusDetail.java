package com.experiments1.henry96.trippiefinaltwo.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Map;

public class StatusDetail implements Parcelable{
    private String status;
    private String createdTime;
    private int position;
    private Map<String, String> imageLinks;

    public StatusDetail(String status, String createdTime,int position) {
        this.status = status;
        this.createdTime = createdTime;
        this.position=position;
    }

    public StatusDetail() {
    }


    protected StatusDetail(Parcel in) {
        status = in.readString();
        createdTime = in.readString();
        position = in.readInt();
    }

    public static final Creator<StatusDetail> CREATOR = new Creator<StatusDetail>() {
        @Override
        public StatusDetail createFromParcel(Parcel in) {
            return new StatusDetail(in);
        }

        @Override
        public StatusDetail[] newArray(int size) {
            return new StatusDetail[size];
        }
    };

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }


    public Map<String, String> getImageLinks() {
        return imageLinks;
    }

    public void setImageLinks(Map<String, String> imageLinks) {
        this.imageLinks = imageLinks;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(status);
        dest.writeString(createdTime);
        dest.writeInt(position);
    }
}
