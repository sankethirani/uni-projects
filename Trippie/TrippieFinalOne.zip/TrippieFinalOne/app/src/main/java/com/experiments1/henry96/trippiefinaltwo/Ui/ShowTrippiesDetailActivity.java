package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.experiments1.henry96.trippiefinaltwo.Fragment.FragmentTrippies_Offers;
import com.experiments1.henry96.trippiefinaltwo.Fragment.TrippieDetailFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.Model.UserOfferDetail;
import com.experiments1.henry96.trippiefinaltwo.NotificationService.NotificationInRetrofitIns;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.github.abdularis.civ.CircleImageView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.Objects;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShowTrippiesDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "ShowTrippiesDetail";
    private FirebaseFirestore db;
    private TextView tvFullName;
    private CircleImageView imgProfile;
    private MaterialRatingBar ratingBar;
    private User user, driver;
    private String trippieId;
    private ImageView chatImageView, callImageView;
    private Button btnOffer, btnCancelOffer;
    TrippieDetailFragment newFragment;
    DocumentReference docRef;
    private boolean isSecondOffer;
    private UserOfferDetail userOfferDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_trippies_detail);

        db = FirebaseFirestore.getInstance();

        init();
        isSecondOffer = false;

        trippieId = getIntent().getStringExtra("TrippieId");
        boolean cancelled = getIntent().getBooleanExtra("trippieCancelled",false);
        newFragment = new TrippieDetailFragment(false);
        Bundle bundle = new Bundle();
        bundle.putString("TrippieId", trippieId);
        bundle.putString("Action", "DriverOffer");
        bundle.putString("driverID", Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        newFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.linearContain, newFragment).commit();

        docRef = db.collection("users").document(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid());
        docRef.get().addOnSuccessListener(documentSnapshot -> {
            driver = documentSnapshot.toObject(User.class);
            if (driver != null) {
                if (driver.isDriver()) btnOffer.setVisibility(View.VISIBLE);


                userOfferDetail = driver.getListTrippieOffers() != null ? driver.getListTrippieOffers().get(trippieId) : null;

                if (userOfferDetail != null && userOfferDetail.getOfferCount() == 2) {
                    btnOffer.setVisibility(View.GONE);
                }

                if(cancelled){
                    btnOffer.setEnabled(false);
                }
            }
        });
        getData();

        if (getIntent().getAction() != null && getIntent().getAction().equals(FragmentTrippies_Offers.Action_Offer)) {
            isSecondOffer = true;
            btnOffer.setText("Amend Offer");
            btnCancelOffer.setVisibility(View.VISIBLE);
            btnCancelOffer.setOnClickListener(this);
        }
    }

    private void init() {
        tvFullName = findViewById(R.id.tvUserName);
        imgProfile = findViewById(R.id.imgUser);
        ratingBar = findViewById(R.id.ratingBar);
        btnOffer = findViewById(R.id.btnOffer);
        btnOffer.setOnClickListener(this);
        chatImageView = findViewById(R.id.imgChatWithUser);
        callImageView = findViewById(R.id.imgCallUser);
        btnCancelOffer = findViewById(R.id.btnCancelOffer);
        chatImageView.setOnClickListener(view -> startChatActivity());
    }

    private void startChatActivity() {
        Intent intent = new Intent(ShowTrippiesDetailActivity.this, MessageActivity.class);
        intent.putExtra("chat_username", user.getFirstNm());
        intent.putExtra("chat_user_image", user.getImage());
        intent.putExtra("receiver_id", user.getUserId());
        startActivity(intent);
    }

    private void getData() {

        String userId = getIntent().getStringExtra("UserId");
        assert userId != null;
        if (!userId.equals(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())) {
            findViewById(R.id.offer_layout).setVisibility(View.VISIBLE);
            DocumentReference docRef = db.collection("users").document(userId);
            docRef.get().addOnSuccessListener(documentSnapshot -> {
                user = documentSnapshot.toObject(User.class);
                String name = Objects.requireNonNull(user).getFirstNm() + " " + user.getLastNm();
                tvFullName.setText(name);
                Picasso.get()
                        .load(user.getImage())
                        .placeholder(R.drawable.null_image)
                        .fit()
                        .centerCrop()
                        .into(imgProfile);
                ratingBar.setRating((float) user.getRating());
            });
        }


    }

    //Driver Click then send notification to user by user token.
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnCancelOffer) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Cancel Offer!");
            builder.setMessage("Are you sure you want to Cancel this Offer?");
            builder.setPositiveButton("Yes", (dialogInterface, i) -> {
                DocumentReference trippieref = db.collection("trippies").document(trippieId);
                trippieref.update("offers." + driver.getUserId() + ".active", false);
                Helpers.showToast(getApplicationContext(), "Cancel Successfully!");
                finish();
            });
            builder.setNegativeButton("No", null);
            builder.create().show();
        } else {
            if (user != null) {
                double offerPrice = newFragment.getOfferPrice();
                if (offerPrice == 0) {
                    Helpers.showToast(ShowTrippiesDetailActivity.this, "Please enter your offer price!");
                    return;
                } else if (offerPrice < newFragment.getTrippieDefaultPrice()) {
                    Toast.makeText(this, "Your offer must not be less than $" + Helpers.addTrailingZerosToCurrency(newFragment.getTrippieDefaultPrice()) + ".", Toast.LENGTH_LONG).show();
                    return;
                } else if (offerPrice > newFragment.getTrippieDefaultPrice() * 2) {
                    Helpers.showToast(ShowTrippiesDetailActivity.this, "Your offer is too high!");
                    return;
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Notification");
                String price = Helpers.addTrailingZerosToCurrency(offerPrice);

                //set up depending on situation!
                Spannable wordtoSpan = null;
                String sourceString = null;
                if (!isSecondOffer) {
                    sourceString = String.format(getResources().getString(R.string.make_offer_confirmation), price, newFragment.getTrippieTitle().trim());
                    wordtoSpan = new SpannableString(sourceString);
                    int firstletter = sourceString.indexOf("$");
                    int secondletter = sourceString.indexOf("Trippie") + "Trippie".length();
                    wordtoSpan.setSpan(new ForegroundColorSpan(Color.BLUE), firstletter, firstletter + price.length() + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    wordtoSpan.setSpan(new ForegroundColorSpan(Color.RED), secondletter, sourceString.length() - 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

                } else {
                    //please Don't chang the text as it will be caused crash!
                    sourceString = "You can only make two offers per Trippie! Please make sure this is your best offer.";
                    wordtoSpan = new SpannableString(sourceString);
                    int firstidx = sourceString.indexOf("two");
                    wordtoSpan.setSpan(new ForegroundColorSpan(Color.RED), firstidx, firstidx + "txwo".length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                }

                builder.setMessage(wordtoSpan);
                builder.setPositiveButton("Yes", (dialog, which) -> {


                    //modify code by Trung
//                if (userOfferDetail != null && userOfferDetail.getOfferCount() == 2) {
//                    Helpers.showToast(this, "Sorry!You can't offer more than two times");
//                } else {
                    //never offer before
                    if (userOfferDetail == null) {
                        sendNotification(offerPrice, 1);
                        finish();
                    } else {
                        if (userOfferDetail.getOfferPrice() == offerPrice) {
                            Helpers.showToast(this, "Please select an amount that is not the same as your first offer!");
                        } else {
                            sendNotification(offerPrice, 2);
                            finish();
                        }
                    }
//                }
                });

                builder.setNegativeButton("No", null);

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        }

    }

    private void sendNotification(double offerPrice, int offerCount) {
        Helpers.showToast(ShowTrippiesDetailActivity.this, "Sending notification");

        String title = "New offer";
        String body = String.format(getResources().getString(R.string.offer_received_notification), driver.getFirstNm(), Helpers.addTrailingZerosToCurrency(offerPrice), newFragment.getTrippieName());
        String trippieid_type_tname = trippieId + "-@-" + Helpers.Key_Trippie + "-@-" + newFragment.getTrippieName();
        String imageurl_driverid = newFragment.getImageUrl() + "-@-" + driver.getUserId();
        Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(user.getToken(), title, body,
                trippieid_type_tname, imageurl_driverid);

        Log.d("getToken", user.getToken());
        Log.d("Type2", newFragment.getTrippieName());

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NonNull Call<ResponseBody> call, @NonNull Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Helpers.showToast(ShowTrippiesDetailActivity.this, "Offer has been sent!");
                    DocumentReference trippieRef = db.collection("trippies").document(trippieId);

                    String driverName = driver.getFirstNm() + " " + driver.getLastNm();
                    Calendar today = Calendar.getInstance();
                    Calendar expiryDate = Calendar.getInstance();
                    expiryDate.add(Calendar.DAY_OF_MONTH, 10);
                    db.collection("drivers").document(driver.getUserId()).get().addOnSuccessListener(documentSnapshot -> {
                        Offer offer = new Offer(FirebaseAuth.getInstance().getUid(), trippieId, driverName, driver.getToken(), offerPrice, today.getTime(), expiryDate.getTime());
                        trippieRef.update("offers." + driver.getUserId(), offer);

                        UserOfferDetail userOfferDetail = new UserOfferDetail(offerPrice, offerCount);
                        docRef.update("listTrippieOffers." + trippieId, userOfferDetail);
                    });

                }
            }

            @Override
            public void onFailure(@NonNull Call<ResponseBody> call, @NonNull Throwable t) {
                Helpers.showToast(ShowTrippiesDetailActivity.this, "Offer failed to send!");
                Log.e(TAG, Objects.requireNonNull(t.getMessage()));
            }
        });
    }

}
