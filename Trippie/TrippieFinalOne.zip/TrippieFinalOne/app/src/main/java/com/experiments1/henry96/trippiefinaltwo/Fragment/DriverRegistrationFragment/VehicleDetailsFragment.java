package com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.Fragment.GetPhotoUriFragment;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.Model.Vehicle;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.DriverRegistrationActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ViewDocumentActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;


public class VehicleDetailsFragment extends Fragment implements GetPhotoUriFragment.PhotoDialogListener {
    // layout views
    private View view;
    private EditText etRegistration, etYear, etRegistrationImg, etInsuranceImg, etInsuranceExpiryDate;
    private AutoCompleteTextView etMake, etModel, etColour;
    private Spinner etBodyType, etInsuranceType;
    private CheckBox chkSmokeFree, chkHasAgreed;
    private Button btnSubmit;

    // objects
    private DriverRegistrationActivity activity;
    private GetPhotoUriFragment dialog;
    private EditText[] fields;
    private Map<String, Uri> uriMap;
    private ProgressBar progressBar;
    private Vehicle vehicle;
    private Driver driver;
    private List<VehicleList.VehicleData> vehicleDataList;
    private Date insuranceExpiryDate;

    // database objects
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private String userId;
    private int numberOfAsyncTasks;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_driver_registration_vehicle, container, false);

        dialog = new GetPhotoUriFragment();
        initialiseLayout();
        setOnClickListeners();
        activity = (DriverRegistrationActivity)getActivity();
        uriMap = Objects.requireNonNull(activity).getUriMap();

        // Will be deleted later.
        driver = activity.getDriver();
        vehicle = activity.getVehicle();

        // initialise database objects
        firebaseAuth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        db = FirebaseFirestore.getInstance();
        setUserId();
        return view;
    }

    public void initialiseLayout() {
        chkSmokeFree = view.findViewById(R.id.chk_smore_free);
        chkHasAgreed = view.findViewById(R.id.chk_has_agreed);
        // setup spannable string for terms of service
        String text = "I agree to Trippie Terms of Service.";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {
                Intent intent = new Intent(getContext(), ViewDocumentActivity.class);
                intent.putExtra("Title","Service Agreement");
                startActivity(intent);
            }
            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setColor(Color.BLUE);
                ds.setUnderlineText(false);
            }
        };
        ss.setSpan(clickableSpan, 11, text.indexOf("."), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        chkHasAgreed.setText(ss);
        chkHasAgreed.setMovementMethod(LinkMovementMethod.getInstance());

        etRegistration = view.findViewById(R.id.et_registration_no);
        etBodyType = view.findViewById(R.id.et_body_type);
        etMake = view.findViewById(R.id.et_make);
        etModel = view.findViewById(R.id.et_model);
        etYear = view.findViewById(R.id.et_year);
        etColour = view.findViewById(R.id.et_colour);
        etInsuranceType = view.findViewById(R.id.et_insurance_type);
        etInsuranceImg = view.findViewById(R.id.et_insurance_img);
        etRegistrationImg = view.findViewById(R.id.et_registration_img);
        etInsuranceExpiryDate = view.findViewById(R.id.insurance_expiry_date);

        // string lists for spinner and autocomplete textview adapters
        String[] bodyTypeList = getResources().getStringArray(R.array.body_type);
        String[] insuranceTypeList = getResources().getStringArray(R.array.insurance_type);
        String[] colourList = getResources().getStringArray(R.array.colours);

        // set spinner and string adapters
        etColour.setAdapter(createStringAdapter(getActivity(), colourList));
        etBodyType.setAdapter(createSpinnerAdapter(getActivity(), bodyTypeList));
        etInsuranceType.setAdapter(createSpinnerAdapter(getActivity(), insuranceTypeList));

        btnSubmit = view.findViewById(R.id.btn_submit);
        progressBar = view.findViewById(R.id.progressBar);

        // array of fields
        fields = new EditText[] {
                etRegistration, etMake, etModel, etYear, etColour, etInsuranceExpiryDate
        };
    }

    private void setOnClickListeners() {
        chkSmokeFree.setOnClickListener(c -> {
            if(!chkSmokeFree.isChecked()) {
                Helpers.showToast(getActivity(), "A vehicle must be smoke-free.");
            }
        });

        chkHasAgreed.setOnClickListener(v -> {
            checkFields();
            if(!chkHasAgreed.isChecked()) {
                Helpers.showToast(getContext(), "You must agree to Terms of Service.");
            }
        });

        etRegistrationImg.setOnClickListener(view -> {
            dialog.viewId = R.id.et_registration_img;
            dialog.show(VehicleDetailsFragment.this.getChildFragmentManager(), getString(R.string.dialog_change_photo));
        });

        etInsuranceImg.setOnClickListener(view -> {
            dialog.viewId = R.id.et_insurance_img;
            dialog.show(VehicleDetailsFragment.this.getChildFragmentManager(), getString(R.string.dialog_change_photo));
        });


        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> adapterView) { }
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    ((TextView) adapterView.getChildAt(0)).setTextColor(Color.BLACK);
                }
                checkFields();
            }
        };

        etInsuranceType.setOnItemSelectedListener(itemSelectedListener);

        etBodyType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    ((TextView) parent.getChildAt(0)).setTextColor(Color.BLACK);
                }
                // get vehicle data from firebase and set it to vehicleDataList
                setVehicleDataListByBodyType(etBodyType.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        etMake.setOnItemClickListener((parent, view, position, id) -> {
            etModel.setAdapter(createStringAdapter(getActivity(), getVehicleDataListByType("model")));
            etModel.setEnabled(true);
        });


        // validate year when focus is lost.
        etYear.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus && !etYear.getText().toString().isEmpty()) {
                int year = Integer.parseInt(etYear.getText().toString());
                // check if vehicle year is less than 1950 or is more than 2 years than the current year.
                int maximumYear = Calendar.getInstance().get(Calendar.YEAR) + 2;
                if((year < 1980) || (year  > maximumYear)) {
                    etYear.setError("Year must be between 1980 and " + maximumYear + ".");
                }
            }
        });

        etRegistration.setOnFocusChangeListener((v, hasFocus) -> {
            if(!hasFocus && !etRegistration.getText().toString().isEmpty() && etRegistration.getText().toString().length() < 2) {
                // minimum length of licence number should be 2
                etRegistration.setError("The minimum number of characters is 2.");
            }});

        btnSubmit.setOnClickListener(view1 -> {
            if(chkSmokeFree.isChecked() && chkHasAgreed.isChecked()) {
                Helpers.showDialog(progressBar);
                uploadPhoto();
            } else {
                Helpers.showToast(getContext(),"Your vehicle must be smoke-free.");
            }
        });

        etInsuranceExpiryDate.setOnClickListener(c -> setDate((EditText) c));


        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

            @Override public void afterTextChanged(Editable editable) {
                checkFields();
            }
        };

        for (EditText et : fields) {
            et.addTextChangedListener(tw);
        }
    }

    private void setDate(EditText et) {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(Objects.requireNonNull(getContext()), createOnDateListener(et), year, month, day);
        dialog.show();
    }

    // create new OnDateSetListener by supplying the text view you want to set
    private DatePickerDialog.OnDateSetListener createOnDateListener(EditText et) {


        return (DatePicker datePicker, int year, int month, int day) -> {
            String date = day + "/" + (month + 1) + "/" + year;


            // derive date from calendar data
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(year, month, day);
            Date selectedDate = selectedCalendar.getTime();

            // current calendar
            Calendar nowCalendar = Calendar.getInstance();
            nowCalendar.setTime(Calendar.getInstance().getTime());

            if (et == etInsuranceExpiryDate) {
                if (selectedDate.after(Calendar.getInstance().getTime())) {
                    insuranceExpiryDate = selectedDate;
                    et.setText(date);
                } else {
                    Helpers.showToast(getContext(), "Invalid issue date. Cannot be a past date.");
                    et.setText("");
                }
            }
        };
    }

    // creates adapter for dropdown views
    public static SpinnerAdapter createSpinnerAdapter(Context context, String[] list) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(Objects.requireNonNull(context), R.layout.layout_spinner_item,list ) {
            @Override
            public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                tv.setTextColor(position == 0 ? Color.GRAY : Color.BLACK);

                return view;
            }

            @Override
            public boolean isEnabled(int position) {
                // disables hint
                return position != 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(R.id.tv_spinner);
                // do whatever you want with this text view
                //textView.setTextSize(18);
                return view;
            }
        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }

    // creates string adapter for autocompletetextview
    public static ArrayAdapter<String> createStringAdapter(Context context, String[] list) {
        return new ArrayAdapter<String>(Objects.requireNonNull(context), android.R.layout.simple_spinner_dropdown_item, list);
    }

    // implementation of GetPhotoDialogUriFragment.PhotoDialogListener method
    @Override
    public void getImagePath(Uri imagePath, int id) {
        String title = imagePath.getLastPathSegment();
        switch (id) {
            case R.id.et_registration_img:
                uriMap.put("registration", imagePath);
                etRegistrationImg.setText(title);
                break;
            case R.id.et_insurance_img:
                uriMap.put("insurance", imagePath);
                etInsuranceImg.setText(title);
                break;
        }
        checkFields();
    }

    private void checkFields() {
        boolean isFilled = true;

        if(!chkHasAgreed.isChecked() || uriMap.size() < 5 || etBodyType.getSelectedItemPosition() == 0 || etInsuranceType.getSelectedItemPosition() == 0 || etYear.getError() != null || etYear.getText().toString().length() != 4 ||
                etRegistration.getError() != null || etRegistration.getText().toString().length() < 2) {
            isFilled = false;
        }
        else {
            for (EditText et : fields) {
                if (et.getText().toString().isEmpty()) {
                    isFilled = false;
                    break;
                }
            }
        }

        if(isFilled) {
            btnSubmit.setBackgroundResource(R.drawable.custom_button_blue);
            btnSubmit.setEnabled(true);
            btnSubmit.setText(getResources().getString(R.string.submit_button_text));
            updateVehicleDetails();
        } else {
            btnSubmit.setBackgroundResource(R.drawable.custom_button_disabled);
            btnSubmit.setEnabled(false);
            btnSubmit.setText(R.string.fill_all_fields);
        }
    }

    private void updateVehicleDetails() {
        Vehicle vehicle = activity.getVehicle();
        vehicle.setRegistrationNo(etRegistration.getText().toString());
        vehicle.setBodyType(etBodyType.getSelectedItem().toString());
        vehicle.setMake(etMake.getText().toString());
        vehicle.setModel(etModel.getText().toString());
        vehicle.setYear(Integer.parseInt(etYear.getText().toString()));
        vehicle.setColour(etColour.getText().toString());
        vehicle.setInsuranceType(etInsuranceType.getSelectedItem().toString());
        vehicle.setSmokeFree(chkSmokeFree.isChecked());
        vehicle.setInsuranceExpiryDate(insuranceExpiryDate);
    }

    private void uploadPhoto() {
        StorageReference storageRef = storage.getReference();
        if(activity.isDriverImagesUploaded()) {
            uriMap.remove("frontLicence");
            uriMap.remove("backLicence");
            uriMap.remove("evidence");
        }

        numberOfAsyncTasks = uriMap.size();

        for(Map.Entry<String, Uri> entry : uriMap.entrySet()) {
            String key = entry.getKey();
            Uri uri = entry.getValue();
            final StorageReference imageRef;

            switch(key){
                case "frontLicence": case "backLicence": case "evidence":   imageRef = storageRef.child("images/drivers/" + userId + "/" + key);                                              break;
                case "registration": case "insurance":                      imageRef = storageRef.child("images/drivers/" + userId + "/vehicles/" + vehicle.getRegistrationNo() + "/" + key); break;
                default: imageRef = null;
            }

            UploadTask uploadTask = Objects.requireNonNull(imageRef).putFile(uri);
            uploadTask.addOnSuccessListener(taskSnapshot -> {
                numberOfAsyncTasks--;
                if(numberOfAsyncTasks == 0) {
                    uploadDriver();
                }
            });
        }
    }

    private void setUserId() {
        userId = Objects.requireNonNull(firebaseAuth.getCurrentUser()).getUid();
    }

    private void uploadDriver() {
        driver.setDriverId(userId);
        driver.setHasAgreed(chkHasAgreed.isChecked());
        driver.setVerified(false);
        driver.setLicenceVerified(false);
        driver.setRightToWorkVerified(false);

        // set creation date for both the driver and vehicle
        driver.setCreationDate(Calendar.getInstance().getTime());
        vehicle.setCreationDate(Calendar.getInstance().getTime());

        //TODO Must be set to false before release


        Map<String, Vehicle> vehicleList = new HashMap<>();
        vehicleList.put(vehicle.getRegistrationNo(), vehicle);

        driver.setVehicleList(vehicleList);
        db.collection("drivers").document(userId).set(driver);

        // TODO For testing purposes only, must be deleter before release
        DocumentReference userRef = db.collection("users").document(userId);
        DocumentReference driverRef = db.collection("drivers").document(userId);
        userRef.update("driver", true);
        driverRef.update("licenceVerified", true, "rightToWorkVerified", true);


        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        builder.setIcon(android.R.drawable.ic_dialog_alert)
                .setMessage("Thank you! The verification process and background check take approximately two weeks. We will contact you for further details if needed.")
                .setPositiveButton("Ok", (dialogInterface, i) -> {
                    Helpers.hideDialog(progressBar);
                    Objects.requireNonNull(getActivity()).finish();
                })
                .create()
                .show();

    }

    // get vehicle list from firebase based on chosesn boty type
    private void setVehicleDataListByBodyType(String bodyType) {
       db.collection("vehicles").document(bodyType.toLowerCase()).get().addOnSuccessListener(documentSnapshot -> {
           VehicleList list = documentSnapshot.toObject(VehicleList.class);
           if (list != null) {
               vehicleDataList = list.vehicleList;
               // set make autocomplete view
               etMake.setAdapter(createStringAdapter(getActivity(), getVehicleDataListByType("make")));

               // clear make and model textviews if different bodytype is chosen
               if(!etMake.getText().toString().equals(bodyType)) {
                   etMake.setText("");
                   etModel.setText("");
                   etMake.setEnabled(true);
                   etModel.setEnabled(false);
               }
           }
       });
    }

    private String[] getVehicleDataListByType(String dataType) {
        Set<String> set = new HashSet<>();
        switch (dataType) {
            case "make":
                for(VehicleList.VehicleData data : vehicleDataList) {
                    set.add(Helpers.capitalizeFully(data.make));
                }
                break;
            case "model":
                for(VehicleList.VehicleData data : vehicleDataList) {
                    set.add(Helpers.capitalizeFully(data.model));
                }
                break;
        }

        String[] list = new String[set.size()];
        list = set.toArray(list);
        return list;
    }




    public static class VehicleList {
        public List<VehicleData> vehicleList;

        public VehicleList() { }

        public static class VehicleData {
            public String make, model, bodyType;

            public VehicleData() {}
        }
    }
}
