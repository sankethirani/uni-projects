package com.experiments1.henry96.trippiefinaltwo.NotificationService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NotificationInRetrofitIns {

    private static Retrofit retrofit = null;
    private static String BASE_URL = "https://trippiefinaltwo.firebaseapp.com/api/";

    public static NotificationAPI getService() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }

        return retrofit.create(NotificationAPI.class);
    }
}
