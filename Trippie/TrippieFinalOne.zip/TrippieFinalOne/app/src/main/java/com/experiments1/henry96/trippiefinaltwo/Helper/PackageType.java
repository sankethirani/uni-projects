package com.experiments1.henry96.trippiefinaltwo.Helper;

public enum PackageType {
    Item,
    Livestock,
    Pet
}
