package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.R;

import java.util.HashMap;
import java.util.Map;


public class AnimalTypeFragment extends Fragment{
    //Test Comment

    private boolean isPetVersion, isRelist = false;
    private CreateTrippieFirstStepFragment originalFragment;
    private View v;
    private RadioGroup rg;
    private RadioButton[] pets, livestock;
    private EditText quantityText;
    private LinearLayout thirdRadioHolder;
    private String animalString, sizeString;
    private int sizeFee, litresPerHundredKm, animalCost, quantity;
    private Button incrementButton, decrementButton;
    private VehicleInterface thirdFragment;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_animal_types, container, false);
        initialiseLayout();
        initialiseOnClicks();
        if(isPetVersion){
            for(RadioButton rb : pets) rb.setVisibility(View.VISIBLE);
            for(RadioButton rb : livestock) rb.setVisibility(View.GONE);
        }
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(isRelist){
            switch(animalString){
                case "Dog"       : pets[0].performClick();      break;
                case "Cat"       : pets[1].performClick();      break;
                case "Rabbit"    : pets[2].performClick();      break;
                case "Bird"      : pets[3].performClick();      break;
                case "Large Bird": pets[4].performClick();      break;
                case "Other"     : pets[5].performClick();      break;
                case "Horse"     : livestock[0].performClick(); break;
                case "Cow"       : livestock[1].performClick(); break;
                case "Calf"      : livestock[2].performClick(); break;
                case "Sheep"     : livestock[3].performClick(); break;
                case "Goat"      : livestock[4].performClick(); break;
            }
            thirdFragment.setRelistVehicleSize(sizeString);
            quantityText.setText(String.valueOf(quantity == 0 ? 1 : quantity));
        }
    }

    private void initialiseLayout() {
        rg = v.findViewById(R.id.animal_radio_group);
        quantityText = v.findViewById(R.id.quantity_text);
        thirdRadioHolder = v.findViewById(R.id.third_radio_holder);
        //check if user has selected pets or not, then show them standard or livestock vehicles accordingly
        getChildFragmentManager().beginTransaction().add(R.id.third_radio_holder, isPetVersion ? new StandardVehicleTypesFragment(true, originalFragment) : new LivestockVehicleTypesFragment(originalFragment),"vehicles").commitNowAllowingStateLoss();
        //separate the RadioButtons into arrays since they're all in the same RadioGroup for slick coding reasons
        pets = new RadioButton[]{rg.findViewById(R.id.dog_button), rg.findViewById(R.id.cat_button), rg.findViewById(R.id.rabbit_button), rg.findViewById(R.id.bird_button), rg.findViewById(R.id.large_bird_button), rg.findViewById(R.id.other_button)};
        livestock = new RadioButton[]{rg.findViewById(R.id.horse_button), rg.findViewById(R.id.cow_button), rg.findViewById(R.id.calf_button), rg.findViewById(R.id.sheep_button), rg.findViewById(R.id.goat_button)};
        decrementButton = v.findViewById(R.id.decrement_button);
        incrementButton = v.findViewById(R.id.increment_button);
    }

    private void initialiseOnClicks(){
        rg.setOnCheckedChangeListener((radioGroup,i)->{
            quantityText.setError(null);
            quantityText.setVisibility(View.VISIBLE);
            animalString = ((RadioButton)radioGroup.findViewById(i)).getText().toString();
            thirdRadioHolder.setVisibility(animalString.equals("Horse") ? View.GONE : View.VISIBLE); //if it's a horse, we know what vehicles we will use, so don't show the vehicles
            switch(animalString){
                case "Bird": case "Goat":                   animalCost = 10; break;
                case "Rabbit": case "Other":                animalCost = 15; break;
                case "Large Bird": case "Cat": case "Calf": animalCost = 20; break;
                case "Dog": case "Sheep":                   animalCost = 25; break;
                case "Cattle":                              animalCost = 30; break;
                case "Horse":                               animalCost = 90; break;
            }
            if(quantityText.getText().toString().isEmpty()) quantityText.setText("1");
            originalFragment.setAnimalString(animalString,Integer.parseInt(quantityText.getText().toString()));
            calculateQuantity(quantityText.getText().toString());
            if(animalString.equals("Horse")) quantityText.setText("1");
            refreshRadioFromQuantity(quantityText.getText().toString());
        });

        quantityText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String input = charSequence.toString().isEmpty() ? "0" : charSequence.toString();
                if (animalString != null && !quantityText.getText().toString().isEmpty()){
                    if (animalString.equals("Horse")) {
                        if (Integer.parseInt(input) == 1) {
                            sizeFee =  60; litresPerHundredKm = 12; sizeString = "Horse Float";
                        } else if(Integer.parseInt(input) == 2) {
                            sizeFee = 100; litresPerHundredKm = 15; sizeString = "Horse Truck";
                        }
                        originalFragment.setVehicleSpecs(sizeFee,litresPerHundredKm,sizeString,true);
                        originalFragment.setAnimalString(animalString,Integer.parseInt(quantityText.getText().toString()));
                    }
                    calculateQuantity(input);
                }
            }
            @Override public void afterTextChanged(Editable editable) {
                String input = editable.toString();
                if(animalString != null && input.length() > 0) {
                    if (input.charAt(0) == '0'){
                        editable.replace(0, 1, "1");
                        setQuantityError("Please enter valid number");
                    }
                    else if(animalString.equals("Horse") && !input.matches("[12]")){
                        editable.replace(0,input.length(),"1");
                        setQuantityError("Horse number must be 1 or 2");
                    }
                    else{
                        quantityText.setError(null);
                    }
                    refreshRadioFromQuantity(input);
                }
                else originalFragment.setNextPageButtonEnabled(false);
            }
        });

        decrementButton.setOnClickListener(view -> {
            String currentQuantity = quantityText.getText().toString();
            if (!currentQuantity.isEmpty() && !currentQuantity.matches("[01]")) quantityText.setText(String.valueOf(Integer.parseInt(currentQuantity) -1));
        });

        incrementButton.setOnClickListener(view -> {
            String currentQuantity = quantityText.getText().toString();
            if (!currentQuantity.isEmpty() && animalString != null && !animalString.isEmpty() && !(animalString.equals("Horse") && quantityText.getText().toString().equals("2"))) quantityText.setText(String.valueOf(Integer.parseInt(currentQuantity) + 1));
        });
    }

    private void calculateQuantity(String quantity){
        double newAnimalCost = quantity.equals("0") ? 0 : (double) (animalCost + animalCost * ((Integer.valueOf(quantity) - 1) * (isPetVersion ? 0.25 : 0.1)));
        originalFragment.setAnimalCost(newAnimalCost);
    }

    AnimalTypeFragment(boolean isPetVersion, CreateTrippieFirstStepFragment originalFragment) {
        this.isPetVersion = isPetVersion;
        this.originalFragment = originalFragment;
    }

    private void refreshRadioFromQuantity(String quantity){
        if(!animalString.equals("Horse")) {
            thirdFragment = (VehicleInterface)getChildFragmentManager().findFragmentByTag("vehicles");
            assert thirdFragment != null;
            if(!isRelist) {
                int maximumAnimals = thirdFragment.setAnimalQuantity(animalString, Integer.parseInt(quantity));
                if (maximumAnimals != -1) {
                    setQuantityError(String.format(getString(R.string.maximum_animals_error),animalString,maximumAnimals));
                }
            }
            else{
                thirdFragment.setRelistAnimalQuantity(animalString, Integer.parseInt(quantity));
            }
        }
    }

    private void setQuantityError(String message) {
        quantityText.setError(message);
        quantityText.requestFocus();
    }

    void setRelistProperties(int quantity, String sizeString, String animalString){
        isRelist = true;
        this.quantity = quantity;
        this.sizeString = sizeString;
        this.animalString = animalString;
    }
}