package com.experiments1.henry96.trippiefinaltwo.Ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.experiments1.henry96.trippiefinaltwo.Adapter.DriverRegistrationFragmentAdapter;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment.DriverLicenceFragment;
import com.experiments1.henry96.trippiefinaltwo.Fragment.DriverRegistrationFragment.VehicleDetailsFragment;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.Model.Vehicle;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.google.android.material.tabs.TabLayout;

import java.util.HashMap;
import java.util.Map;

public class DriverRegistrationActivity extends AppCompatActivity  {
    private static final String TAG = "DriverRegistrationActivity";
    private DriverRegistrationFragmentAdapter mAdapter;
    private ViewPager mViewPager;
    private LinearLayout tabs;



    private int maxSwipe = 0;
    private Map<String, Uri> uriMap;
    private Driver driver;
    private Vehicle vehicle;
    private boolean isDriverImagesUploaded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_registration);


        setupViewPager();
        setupTabDots();
        mViewPager.setOffscreenPageLimit(2);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) { }

            @Override
            public void onPageSelected(int position) {
                if (position > maxSwipe) {
                    mViewPager.setCurrentItem(maxSwipe, true);


                }
            }

            @Override public void onPageScrollStateChanged(int state) { }
        });

        isDriverImagesUploaded = false;
        uriMap = new HashMap<>();
        driver = new Driver();
        vehicle = new Vehicle();
    }

    // this method removes focus of edit text when touch anywhere else on the screen.
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if ( v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent( event );
    }


    private void setupViewPager() {
        mViewPager = findViewById(R.id.viewpager);
        mAdapter = new DriverRegistrationFragmentAdapter(getSupportFragmentManager());
        //mAdapter.add(new UserAgreementFragment(), "User Agreement");
        mAdapter.add(new DriverLicenceFragment(), "Licence Details");
        mAdapter.add(new VehicleDetailsFragment(), "Vehicle Details");
        mViewPager.setAdapter(mAdapter);
        mViewPager.setCurrentItem(0);

    }

    private void setupTabDots() {
        TabLayout tabLayout = findViewById(R.id.tabDots);
        tabLayout.setupWithViewPager(mViewPager, true);
        tabLayout.setTabRippleColor(null);

        tabs = ((LinearLayout)tabLayout.getChildAt(0));
        for(int i = 0; i < tabs.getChildCount(); i++){
            tabs.getChildAt(i).setClickable(false);
            Log.i("tabs", String.valueOf(i));
        }
    }

    public void nextPage() {
        maxSwipe++;
        if(maxSwipe > mViewPager.getChildCount()) {
            maxSwipe = mViewPager.getChildCount();
        }
        int nextPosition = mViewPager.getCurrentItem() + 1;
        mViewPager.setCurrentItem(nextPosition);
    }

    public void setMaxSwipe(int position) {
        maxSwipe = position;
    }

    public int getMaxSwipe() {
        return maxSwipe;
    }

    public Map<String, Uri> getUriMap() {
        return uriMap;
    }
    public void setUriMap(Map<String, Uri> uriMap) {
        this.uriMap = uriMap;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }


    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public boolean isDriverImagesUploaded() {
        return isDriverImagesUploaded;
    }

    public void setDriverImagesUploaded(boolean driverImagesUploaded) {
        isDriverImagesUploaded = driverImagesUploaded;
    }
}
