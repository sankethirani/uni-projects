package com.experiments1.henry96.trippiefinaltwo.Model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

public class Offer implements Parcelable{
    private String serviceProviderId, trippieId, serviceProviderName, serviceProviderToken;
    private Double price;
    private boolean isActive;
    private Date dateCreated, dateExpires;

    public Offer(String serviceProviderId, String trippieId, String serviceProviderName, String serviceProviderToken, Double price, Date dateCreated, Date dateExpires) {
        this.serviceProviderId = serviceProviderId;
        this.trippieId = trippieId;
        this.serviceProviderName = serviceProviderName;
        this.serviceProviderToken = serviceProviderToken;
        this.price = price;
        this.dateCreated = dateCreated;
        this.dateExpires = dateExpires;
        isActive = true;
    }


    protected Offer(Parcel in) {
        serviceProviderId = in.readString();
        trippieId = in.readString();
        serviceProviderName = in.readString();
        serviceProviderToken = in.readString();
        if (in.readByte() == 0) {
            price = null;
        } else {
            price = in.readDouble();
        }
        isActive = in.readByte() != 0;
    }

    public static final Creator<Offer> CREATOR = new Creator<Offer>() {
        @Override
        public Offer createFromParcel(Parcel in) {
            return new Offer(in);
        }

        @Override
        public Offer[] newArray(int size) {
            return new Offer[size];
        }
    };

    public String getServiceProviderToken() {
        return serviceProviderToken;
    }

    public void setServiceProviderToken(String serviceProviderToken) {
        this.serviceProviderToken = serviceProviderToken;
    }

    // TAB 27092019 For firebase
    public Offer() {
    }

    public String getServiceProviderId() {
        return serviceProviderId;
    }

    public void setServiceProviderId(String serviceProviderId) {
        this.serviceProviderId = serviceProviderId;
    }


    public String getTrippieId() {
        return trippieId;
    }

    public void setTrippieId(String trippieId) {
        this.trippieId = trippieId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateExpires() {
        return dateExpires;
    }

    public void setDateExpires(Date dateExpires) {
        this.dateExpires = dateExpires;
    }


    public String getServiceProviderName() {
        return serviceProviderName;
    }

    public void setServiceProviderName(String serviveProviderName) {
        this.serviceProviderName = serviveProviderName;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(serviceProviderId);
        dest.writeString(trippieId);
        dest.writeString(serviceProviderName);
        dest.writeString(serviceProviderToken);
        if (price == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(price);
        }
        dest.writeByte((byte) (isActive ? 1 : 0));
    }

}
