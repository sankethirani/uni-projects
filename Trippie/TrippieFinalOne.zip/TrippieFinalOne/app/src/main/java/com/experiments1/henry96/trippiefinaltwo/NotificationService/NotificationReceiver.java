package com.experiments1.henry96.trippiefinaltwo.NotificationService;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.NOTIFICATION_SERVICE;

public class NotificationReceiver extends BroadcastReceiver {
    private DocumentReference docRef;
    private Trippie trippie;
    private static final String TAG = "NotificationReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        Helpers.showToast(context, intent.getAction());
        int notificationId = intent.getIntExtra("notificationId", -1);
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        manager.cancel(notificationId);


//        if (intent.getAction().equals("Accepted")) {
//            String trippieId = intent.getStringExtra("trippie");
//            String driverId = intent.getStringExtra("driverid");
//            FirebaseFirestore db = FirebaseFirestore.getInstance();
//            docRef = db.collection("trippies").document(trippieId);
//            docRef.get().addOnSuccessListener(documentSnapshot -> {
//                trippie = documentSnapshot.toObject(Trippie.class);
//                if (trippie != null) {
//                    Offer offercur = trippie.getOffers().get(driverId);
//                    sendNotification(offercur, context);
//
//                }
//            });
//        }

    }

//    private void sendNotification(Offer offer, Context context) {
//        Helpers.showToast((context), "Send notification");
//
//        String title = "New Offer";
//        String body = "Your Offer has been accepted!";
//        String trippieid_type_tname = offer.getTrippieId() + "-@-" + Helpers.Key_Job + "-@-" + trippie.getTitle();
//        String imageurl_driverid = trippie.getThumbnailUrl() + "-@-" + "null";
//
//        Call<ResponseBody> call = NotificationInRetrofitIns.getService().sendNotification(offer.getServiceProviderToken(), title, body,
//                trippieid_type_tname, imageurl_driverid);
//
//        call.enqueue(new Callback<ResponseBody>() {
//            @Override
//            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                if (response.isSuccessful()) {
//                    docRef.update("driverId", offer.getServiceProviderId());
//                    docRef.update("status", Trippie.Status.customer_accepted.toString());
//                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.UK);
//                    StatusDetail statusDetail = new StatusDetail(Trippie.Status.customer_accepted.toString(),
//                            dateFormat.format(Calendar.getInstance().getTime()), 0);
//                    docRef.update("statusDetails." + Trippie.Status.customer_accepted.toString(), statusDetail);
//
//                    Helpers.showToast(context, "Notification has sent to Driver!");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                Helpers.showToast(context, "Offer sended Fail!");
//                Log.e(TAG, t.getMessage());
//            }
//        });
//    }


}
