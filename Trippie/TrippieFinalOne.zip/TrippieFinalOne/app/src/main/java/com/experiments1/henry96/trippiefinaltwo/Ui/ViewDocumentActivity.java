package com.experiments1.henry96.trippiefinaltwo.Ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat;

import com.experiments1.henry96.trippiefinaltwo.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ViewDocumentActivity extends AppCompatActivity {
    private static final String TAG = "ViewDocumentActivity";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_document);
        Intent intent = getIntent();
        String title = intent.getStringExtra("Title");
        if(title != null) initialiseLayout(title);

    }

    public void initialiseLayout(String title) {
        TextView titleTextView = findViewById(R.id.document_title);
        TextView documentTextView = findViewById(R.id.document);

        String html = "";

        switch (title) {
            case "Insurance Policy":
                html = getStringFromFile(R.raw.insurance_policy);
                break;
            case "Service Agreement":
                html = getStringFromFile(R.raw.service_agreement);
                break;
            case "Privacy Policy":
                html = getStringFromFile(R.raw.privacy_policy);
                break;
            case "Driving Record Check":
                html = getStringFromFile(R.raw.driving_record_check);
                break;
            case "About":
                html = getStringFromFile(R.raw.about);
                break;
        }


        // set the text for title and document textview
        titleTextView.setText(title);


        // Html.fromHtml is deprecated starting from Android Nougat
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            documentTextView.setText(HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY));
        } else {
            documentTextView.setText(Html.fromHtml(html));
        }

    }

    // BC 9-28-2019 This method converts a file into a string
    public String getStringFromFile(int fileID) {
        InputStream inputStream = getResources().openRawResource(fileID);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder builder = new StringBuilder();
        String line = "";

        try {
            while((line = reader.readLine()) != null) {
                builder.append(line);
            }
        } catch (IOException ex) {
            Log.e(TAG, "Error reading data on line" + line, ex);
            ex.printStackTrace();
        }
        return builder.toString();
    }

}
