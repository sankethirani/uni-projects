package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Custom_Status_Display_Adapter;
import com.experiments1.henry96.trippiefinaltwo.CompareArray.StatusListComparator;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Driver;
import com.experiments1.henry96.trippiefinaltwo.Model.StatusDetail;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.Model.User;
import com.experiments1.henry96.trippiefinaltwo.R;

import com.experiments1.henry96.trippiefinaltwo.Ui.MessageActivity;
import com.github.abdularis.civ.CircleImageView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;


public class TrippieOnTheWayFragment extends Fragment implements View.OnClickListener {


    private final int resourceID = R.layout.fragment_trippie_on_the_way;
    private RecyclerView rvstatus;
    private ArrayList<StatusDetail> statusDetails;
    private Custom_Status_Display_Adapter custom_status_display_adapter;

    private TextView tvDetailUser;
    private Button btnUpdate;
    private ImageView imgCall, imgArrow;
    private LinearLayout linearProgress;
    private ImageView questionMessage;

    private LinearLayout linearDeliveryStatus;
    private int delivery_Click;

    private User user;
    private TextView tvFullName;
    private CircleImageView imgProfile;
    private MaterialRatingBar ratingBar;
    private Trippie trippie;
    private FirebaseFirestore db;
    private static final String TAG = "TrippieOnTheWayFragment";

    private String trippieId;
    private ListenerRegistration listenerRegistration;

    private boolean isfirsttimeUpdate;

    @Override
    public void onStart() {
        super.onStart();
        statusDetails = new ArrayList<>();
        custom_status_display_adapter = new Custom_Status_Display_Adapter(statusDetails, getContext());
        rvstatus.setLayoutManager(new LinearLayoutManager(getContext()));
        rvstatus.setAdapter(custom_status_display_adapter);

        listenerRegistration = db.collection("trippies").document(trippieId)
                .addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Log.d(TAG, e.toString());
                            return;
                        }

                        if (documentSnapshot != null && documentSnapshot.exists()) {
                            trippie = documentSnapshot.toObject(Trippie.class);

                            if (trippie != null && trippie.getStatusDetails() != null && trippie.getStatusDetails().size() != 0) {
                                if (trippie.getCancelled()) {
                                    Helpers.showToast(getContext(), "This Trippie was cancelled by its owner!");
                                    if (getActivity() != null) {
                                        getActivity().finish();
                                        return;
                                    }

                                }

                                statusDetails.clear();
                                statusDetails.addAll(trippie.getStatusDetails().values());
                                Collections.sort(statusDetails, new StatusListComparator());
                                custom_status_display_adapter.notifyDataSetChanged();


                                if (isfirsttimeUpdate) {

                                    String userId;
                                    boolean tripsterLookingAtDetails = getArguments() != null && getArguments().getString("define") != null;
                                    if (tripsterLookingAtDetails) {
                                        tvDetailUser.setText("Sender:");
                                        userId = trippie.getUserId();
                                        btnUpdate.setVisibility(View.VISIBLE);
                                    } else {
                                        btnUpdate.setVisibility(View.GONE);
                                        userId = trippie.getDriverId();
                                    }
                                    DocumentReference docRef = db.collection("users").document(Objects.requireNonNull(userId));
                                    docRef.get().addOnSuccessListener(documentSnapshot1 -> {
                                        user = documentSnapshot1.toObject(User.class);
                                        if(!tripsterLookingAtDetails) db.collection("drivers").document(trippie.getDriverId()).get().addOnSuccessListener(snapshot -> ratingBar.setRating((float) Objects.requireNonNull(snapshot.toObject(Driver.class)).getRating()));
                                        else ratingBar.setRating((float) user.getRating());
                                        tvFullName.setText(String.format(getString(R.string.name_concatenation), user.getFirstNm(), user.getLastNm()));
                                        Picasso.get()
                                                .load(user.getImage())
                                                .placeholder(R.drawable.null_image)
                                                .fit()
                                                .centerCrop()
                                                .into(imgProfile);
                                    });

                                    isfirsttimeUpdate = false;
                                }

                            }


                        }
                    }
                });
    }


    @Override
    public void onStop() {
        super.onStop();
        listenerRegistration.remove();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);
        init(v);
        db = FirebaseFirestore.getInstance();
        if (getArguments() != null) {
            trippieId = getArguments().getString("TrippieId");
        }


        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getActivity() instanceof OnTheWayOnClickListener)
            onTheWayOnClickListener = (OnTheWayOnClickListener) getActivity();
        btnUpdate.setOnClickListener(this);
        imgCall.setOnClickListener(this);
        linearProgress.setOnClickListener(this);
        questionMessage.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), MessageActivity.class);
            intent.putExtra("chat_username", user.getFirstNm());
            intent.putExtra("chat_user_image", user.getImage());
            intent.putExtra("receiver_id", user.getUserId());
            startActivity(intent);
        });
    }

    private void init(View view) {
        linearDeliveryStatus = view.findViewById(R.id.dialog);
        imgArrow = view.findViewById(R.id.imgarrow);
        linearProgress = view.findViewById(R.id.progressLinear);
        rvstatus = view.findViewById(R.id.rvStatusDetail);
        tvFullName = view.findViewById(R.id.tvUserName);
        imgProfile = view.findViewById(R.id.imgUser);
        ratingBar = view.findViewById(R.id.ratingBar);
        tvDetailUser = view.findViewById(R.id.tvDetailUser);
        btnUpdate = view.findViewById(R.id.btnCompleteDelivery);
        imgCall = view.findViewById(R.id.imgCallUser);
        questionMessage = view.findViewById(R.id.imgQuestionMessage);
        delivery_Click = 0;
        isfirsttimeUpdate = true;
    }

    public interface OnTheWayOnClickListener {
        void onUpdateItemClick();

    }

    private OnTheWayOnClickListener onTheWayOnClickListener;

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnCompleteDelivery) {
            onTheWayOnClickListener.onUpdateItemClick();
        } else if (v.getId() == R.id.imgCallUser) {
            makePhoneCall();
        } else if (v.getId() == R.id.progressLinear) {
            //is closing now
            if (delivery_Click % 2 == 0) {
                openDeliveryStatus();
            } else {
                //is opening now
                closeDeliveryStatus();
            }
            delivery_Click++;

        }
    }

    private void openDeliveryStatus() {
        imgArrow.setImageResource(Helpers.getResoureImageID(getContext(), "ic_arrow_up"));
        linearDeliveryStatus.setVisibility(LinearLayout.VISIBLE);
        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.delivery_status_anim);
        animation.setDuration(500);
        linearDeliveryStatus.setAnimation(animation);
        linearDeliveryStatus.animate();
        animation.start();
    }

    private void closeDeliveryStatus() {
        imgArrow.setImageResource(Helpers.getResoureImageID(getContext(), "ic_arrow_down"));
        linearDeliveryStatus.setVisibility(LinearLayout.INVISIBLE);
        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.delivery_status_anim_out);
        animation.setDuration(500);
        linearDeliveryStatus.setAnimation(animation);
        linearDeliveryStatus.animate();
        animation.start();
    }

    private void makePhoneCall() {
        String number = user.getPhone().trim();
        if (number.length() > 0) {
            String dial = "tel:" + number;
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
        } else {
            Helpers.showToast(getContext(), "Driver has no phone number");
        }
    }
}
