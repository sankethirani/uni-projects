package com.experiments1.henry96.trippiefinaltwo.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Notification_Display_Adapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.LocalDb.Notification;
import com.experiments1.henry96.trippiefinaltwo.LocalDb.Repository;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInJobPageActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInTrippiePageActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Collections;
import java.util.List;
import java.util.Objects;


public class NotificationFragment extends Fragment {

    private static final String TAG = "NotificationFragment";
    private final int resourceID = R.layout.fragment_notification;
    private RecyclerView rvNotifications;
    private Notification_Display_Adapter notification_display_adapter;
    private LiveData<List<Notification>> notifications;
    private Repository repository;

    private FloatingActionButton fab_Load;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);

        fab_Load = v.findViewById(R.id.fab_deleteall);

        fab_Load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (notification_display_adapter.getSelectedItemCount() != 0)
                    deleteInboxes();
                else {
                    Helpers.showToast(getContext(), "Please Select Notifications to delete!");
                }
            }
        });


        repository = new Repository(Objects.requireNonNull(getActivity()).getApplication());

        rvNotifications = v.findViewById(R.id.rvNotifications);
        rvNotifications.setLayoutManager(new LinearLayoutManager(getContext()));
        notifications = repository.getNoteList();


        notification_display_adapter = new Notification_Display_Adapter(getContext());
        rvNotifications.setAdapter(notification_display_adapter);
        notification_display_adapter.notifyDataSetChanged();

        notifications.observe(this, notifications -> notification_display_adapter.submitList(notifications));

        notification_display_adapter.setOnItemClickListener(
                new Notification_Display_Adapter.OnItemClickListener() {
                    @Override
                    public void onItemEditClick(Notification notification, int pos) {
                        if (notification_display_adapter.getSelectedItemCount() > 0) {
                            enableActionMode(pos);

                        } else {

                            if (notification.getType().equalsIgnoreCase(Helpers.Key_Trippie)) {
                                Intent sendtoDisplayTrippieIntent = new Intent(getActivity(), ShowTrippiesInTrippiePageActivity.class);
                                sendtoDisplayTrippieIntent.putExtra("TrippieId", notification.getTrippieId());
                                startActivity(sendtoDisplayTrippieIntent);
                            } else if (notification.getType().equalsIgnoreCase(Helpers.Key_Job)) {
                                Intent sendtoDisplayTrippieIntent = new Intent(getActivity(), ShowTrippiesInJobPageActivity.class);
                                sendtoDisplayTrippieIntent.putExtra("TrippieId", notification.getTrippieId());
                                startActivity(sendtoDisplayTrippieIntent);
                            } else if (notification.getType().equalsIgnoreCase(Helpers.Key_Driver_Accept)) {
                                Intent sendtoDisplayTrippieIntent = new Intent(getActivity(), ShowTrippiesInTrippiePageActivity.class);
                                sendtoDisplayTrippieIntent.putExtra("TrippieId", notification.getTrippieId());
                                startActivity(sendtoDisplayTrippieIntent);

                            }
                        }

                    }

                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onItemLongClick(int pos) {
                        enableActionMode(pos);

                        if (fab_Load.getVisibility() == View.GONE) {
                            fab_Load.setVisibility(View.VISIBLE);
                            Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.delivery_status_anim);
                            animation.setDuration(500);
                            fab_Load.setAnimation(animation);
                            fab_Load.animate();
                            animation.start();
                        }
                    }

                }
        );


        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                repository.deleteNote(notification_display_adapter.getNoteAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(rvNotifications);


        return v;
    }

    private void enableActionMode(int position) {
        toggleSelection(position);
    }

    private void toggleSelection(int position) {
        notification_display_adapter.toggleSelection(position);
    }

    private void deleteInboxes() {
        if (notifications.getValue() != null) {
            List<Integer> selectedItemPositions = notification_display_adapter.getSelectedItems();
            for (int i = selectedItemPositions.size() - 1; i >= 0; i--) {
                repository.deleteNote(notification_display_adapter.getNoteAt(selectedItemPositions.get(i)));
            }
            notification_display_adapter.clearSelections();
        } else {
            Log.e(TAG, "notifications is null");
        }

    }



    @Override
    public void onResume() {
        super.onResume();
    }
}
