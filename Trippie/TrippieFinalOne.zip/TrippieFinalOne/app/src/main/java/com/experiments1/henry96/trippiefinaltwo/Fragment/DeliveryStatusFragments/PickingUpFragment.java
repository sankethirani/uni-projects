package com.experiments1.henry96.trippiefinaltwo.Fragment.DeliveryStatusFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.experiments1.henry96.trippiefinaltwo.R;


public class PickingUpFragment extends Fragment {

    private final int resourceID = R.layout.fragment_picking_up_status;
    private String pickupLocation;
    private TextView tvPickupLocation;
    private Button btnPickingUp;
    private onPickingUpFragmentClickListener onPickingUpFragmentClickListener;

    public interface onPickingUpFragmentClickListener {
        public void onPickingupClick();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(resourceID, container, false);
//        tvPickupLocation = v.findViewById(R.id.tvPickupLocation);
        btnPickingUp = v.findViewById(R.id.btnPickingUp);
        if (getArguments() != null) {
            pickupLocation = getArguments().getString("pickUpDestination");
//            tvPickupLocation.setText(String.format(getString(R.string.pickup_location_driver),pickupLocation.replace(", New Zealand","")));
        }

        btnPickingUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPickingUpFragmentClickListener.onPickingupClick();
            }
        });

        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        onPickingUpFragmentClickListener = (PickingUpFragment.onPickingUpFragmentClickListener) getActivity();
    }


}
