package com.experiments1.henry96.trippiefinaltwo.Fragment;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Adapter.Custom_Trippie_Display_Adapter;
import com.experiments1.henry96.trippiefinaltwo.Helper.Helpers;
import com.experiments1.henry96.trippiefinaltwo.Model.Trippie;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesDetailActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInJobPageActivity;
import com.experiments1.henry96.trippiefinaltwo.Ui.ShowTrippiesInTrippiePageActivity;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class FragmentTrippies_Offers extends Fragment {

    private static final String TAG = "FragmentTrippies_Jobs";
    public static final String Action_Offer = "ACTION_AMEND_OFFER";
    private RecyclerView rvTrippies;
    private Custom_Trippie_Display_Adapter custom_trippie_display;
    private ArrayList<Trippie> trippies;

    private FirebaseFirestore db;

    private ListenerRegistration listenerRegistration;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        int resourceID = R.layout.fragment_trippie_jobs;
        View v = inflater.inflate(resourceID, container, false);
        db = FirebaseFirestore.getInstance();
        rvTrippies = v.findViewById(R.id.rvTrippies);

        return v;
    }

    @Override
    public void onStart() {
        super.onStart();

        trippies = new ArrayList<>();
        custom_trippie_display = new Custom_Trippie_Display_Adapter(trippies, getContext());
        custom_trippie_display.setIsjob(true);
        rvTrippies.setLayoutManager(new LinearLayoutManager(getContext()));
        rvTrippies.setAdapter(custom_trippie_display);

        listenerRegistration = db.collection("trippies")
                .whereEqualTo("offers." + Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid() + ".active", true)
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    if (e != null) {
                        Log.d(TAG, e.toString());
                        return;
                    }
                    if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()) {
                        trippies.clear();
                        List<Trippie> trippielist = queryDocumentSnapshots.toObjects(Trippie.class);
                        for (Trippie item : trippielist) {
                            if (item.getStatus() == null) {
                                trippies.add(item);
                            }
                        }
                        setOnClickToTrippieItem();
                        custom_trippie_display.notifyDataSetChanged();
                    } else {
                        Log.e(TAG, "Errors Happened");
                    }
                });
    }

    @Override
    public void onStop() {
        super.onStop();
        listenerRegistration.remove();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private void setOnClickToTrippieItem() {
        custom_trippie_display.setOnItemClickListener(new Custom_Trippie_Display_Adapter.OnItemClickListener() {
            @Override
            public void onItemEditClick(int position) {
                Trippie trippie = trippies.get(position);
                Intent showTrippieIntent = new Intent(getActivity(), ShowTrippiesDetailActivity.class);
                showTrippieIntent.putExtra("TrippieId", trippie.getTrippieId());
                showTrippieIntent.putExtra("UserId", trippie.getUserId());
                showTrippieIntent.setAction(Action_Offer);
                startActivity(showTrippieIntent);

            }

            @Override
            public void onRelistCLick(int position) {
                Helpers.showToast(getContext(), "onRelistCLick");
            }

            @Override
            public void onCancelCLick(int position) {
                Helpers.showToast(getContext(), "onCancelCLick");
            }

            @Override
            public void onEditCLick(int position) {
                Helpers.showToast(getContext(), "onEditCLick");
            }

            @Override
            public void onDeleteCLick(int position) {
                Helpers.showToast(getContext(), "onDeleteCLick");
            }
        });
    }


}



