package com.experiments1.henry96.trippiefinaltwo.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.experiments1.henry96.trippiefinaltwo.Model.Offer;
import com.experiments1.henry96.trippiefinaltwo.R;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Objects;

import me.zhanghai.android.materialratingbar.MaterialRatingBar;


public class Custom_Offer_Display_Adapter extends RecyclerView.Adapter<Custom_Offer_Display_Adapter.OfferViewHolder> {

    private ArrayList<Offer> items;
    private OnItemClickListener mListener;
    private Context context;
    private boolean beingDelivery;
    private static final String TAG = "Custom_Offer_Display";


    public Custom_Offer_Display_Adapter(ArrayList<Offer> items, Context context) {
        this.items = items;
        this.context = context;
        beingDelivery = true;
    }

    public void setBeingDelivery(boolean value) {
        beingDelivery = value;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    //set Onclick interface
    public interface OnItemClickListener {
        void onItemAcceptClick(int position);

        void onItemDeclineClick(int position);

    }


    @NonNull
    @Override
    public OfferViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_offer_item, parent, false);
        return new OfferViewHolder(v, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull OfferViewHolder holder, int position) {
        Offer currentItem = items.get(position);
        if (currentItem != null && currentItem.getTrippieId() != null) {
            holder.bind(currentItem, context, beingDelivery);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class OfferViewHolder extends RecyclerView.ViewHolder {
        private TextView tvDriverName, tvPrice;
        private MaterialRatingBar ratingBar;
        private TextView tvlinkAccepted, tvlinkDecline;
        private LinearLayout linearButtons;

        OfferViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            tvDriverName = itemView.findViewById(R.id.tvDriverName);
            ratingBar = itemView.findViewById(R.id.ratingBar);
            tvPrice = itemView.findViewById(R.id.tvOfferPrice);
            tvlinkAccepted = itemView.findViewById(R.id.linkAccept);
            tvlinkDecline = itemView.findViewById(R.id.linkDecline);
            linearButtons = itemView.findViewById(R.id.linearButton);


            tvlinkAccepted.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemAcceptClick(position);
                }
            });

            tvlinkDecline.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemDeclineClick(position);
                }
            });
        }

        void bind(Offer offer, Context context, boolean isBeingDelivery) {
            tvDriverName.setText(offer.getServiceProviderName());
            tvPrice.setText(String.format(context.getResources().getString(R.string.currency), String.valueOf(Math.round(offer.getPrice()))));
            FirebaseFirestore.getInstance().collection("drivers").document(offer.getServiceProviderId()).get().addOnSuccessListener(snapshot ->
                    ratingBar.setRating(Objects.requireNonNull(snapshot.getDouble("rating")).floatValue()));

            if (!isBeingDelivery) {
                linearButtons.setVisibility(View.GONE);
            }
        }
    }
}
