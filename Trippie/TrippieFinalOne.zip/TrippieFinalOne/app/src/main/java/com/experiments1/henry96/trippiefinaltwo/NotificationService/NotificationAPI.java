package com.experiments1.henry96.trippiefinaltwo.NotificationService;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface NotificationAPI {

    @FormUrlEncoded
    @POST("send")
    Call<ResponseBody> sendNotification(
            @Field("token") String token,
            @Field("title") String title,
            @Field("body") String body,
            @Field("trippieid_type_tname") String trippieid_type_tname,
            @Field("imageurl_driverid") String imageurl_driverid
    );
}
