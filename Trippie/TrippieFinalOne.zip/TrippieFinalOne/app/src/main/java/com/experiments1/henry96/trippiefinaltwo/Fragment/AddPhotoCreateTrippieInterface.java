package com.experiments1.henry96.trippiefinaltwo.Fragment;

public interface AddPhotoCreateTrippieInterface {
    void openCamera();
    void openFileChooser();
}
