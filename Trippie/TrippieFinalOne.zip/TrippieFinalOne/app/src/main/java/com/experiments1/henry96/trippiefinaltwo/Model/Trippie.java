package com.experiments1.henry96.trippiefinaltwo.Model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.GeoPoint;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Trippie implements Parcelable {
    private GeoPoint deliveryLocation, pickupLocation;

    // TAB New Fields
    private List<String> listingImage;
    private String deliveryAddress, pickupAddress, vetImageUrl, userId, driverId, title, category, description, instructions, size, thumbnailUrl, polyline, distanceText, trippieId,
            personMeetingPickupName, personMeetingPickupPhone, personMeetingDeliveryName, personMeetingDeliveryPhone;
    private int quantity, meetingDriverPickup, meetingDriverDelivery;

    private Double itemValue, price;
    private Date postedDate, expiryTime, pickupTime, deliveryTime;

    private Boolean featured = false, urgent = false, signatureRequired = false, userHasBeenRated = false, driverHasBeenRated = false, cancelled = false;
    private int ratingReminderCount = 0;

    public Trippie(GeoPoint deliveryLocation, GeoPoint pickupLocation, String deliveryAddress, String pickupAddress,
                   String vetImageUrl, List<String> listingImage, String userId, String title, String category,
                   Double itemValue, Date postedDate, String description, String instructions, Boolean featured, Boolean urgent, Boolean signatureRequired,
                   Double price, Date expiryTime, String size, String thumbnailUrl, Date pickupTime,
                   Date deliveryTime, String polyline, String distanceText, String trippieId) {
        this.deliveryLocation = deliveryLocation;
        this.pickupLocation = pickupLocation;
        this.deliveryAddress = deliveryAddress;
        this.pickupAddress = pickupAddress;
        this.vetImageUrl = vetImageUrl;
        this.listingImage = listingImage;
        this.userId = userId;
        this.title = title;
        this.category = category;
        this.itemValue = itemValue;
        this.postedDate = postedDate;
        this.description = description;
        this.instructions = instructions;
        this.featured = featured;
        this.urgent = urgent;
        this.signatureRequired = signatureRequired;
        this.price = price;
        this.driverId = null;
        this.expiryTime = expiryTime;
        this.size = size;
        this.thumbnailUrl = thumbnailUrl;
        this.pickupTime = pickupTime;
        this.deliveryTime = deliveryTime;
        this.polyline = polyline;
        this.distanceText = distanceText;
        this.trippieId = trippieId;
        this.status = null;
        offers = new HashMap<>();
        statusDetails = new HashMap<>();
        isActive = true;
        ratingReminderCount = 0;
    }

    public Trippie() {
    }

    protected Trippie(Parcel in) {
        listingImage = in.createStringArrayList();
        deliveryAddress = in.readString();
        pickupAddress = in.readString();
        vetImageUrl = in.readString();
        userId = in.readString();
        driverId = in.readString();
        title = in.readString();
        category = in.readString();
        description = in.readString();
        instructions = in.readString();
        size = in.readString();
        thumbnailUrl = in.readString();
        polyline = in.readString();
        distanceText = in.readString();
        trippieId = in.readString();
        if (in.readByte() == 0) {
            itemValue = null;
        } else {
            itemValue = in.readDouble();
        }
        if (in.readByte() == 0) {
            price = null;
        } else {
            price = in.readDouble();
        }
        byte tmpFeatured = in.readByte();
        byte tmpUrgent = in.readByte();
        featured = tmpFeatured == 0 ? null : tmpFeatured == 1;
        urgent = tmpUrgent == 0 ? null : tmpUrgent == 1;
        expiryTime = in.readParcelable(Timestamp.class.getClassLoader());
        isActive = in.readByte() != 0;
    }

    public static final Creator<Trippie> CREATOR = new Creator<Trippie>() {
        @Override
        public Trippie createFromParcel(Parcel in) {
            return new Trippie(in);
        }

        @Override
        public Trippie[] newArray(int size) {
            return new Trippie[size];
        }
    };

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public Date getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(Date expiryTime) {
        this.expiryTime = expiryTime;
    }

    public GeoPoint getDeliveryLocation() {
        return deliveryLocation;
    }

    public void setDeliveryLocation(GeoPoint deliveryLocation) {
        this.deliveryLocation = deliveryLocation;
    }

    public GeoPoint getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(GeoPoint pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public String getPickupAddress() {
        return pickupAddress;
    }

    public void setPickupAddress(String pickupAddress) {
        this.pickupAddress = pickupAddress;
    }

    public String getVetImageUrl() {
        return vetImageUrl;
    }

    public void setVetImageUrl(String vetImageUrl) {
        this.vetImageUrl = vetImageUrl;
    }

    public List<String> getListingImage() {
        return listingImage;
    }

    public void setListingImage(List<String> listingImage) {
        this.listingImage = listingImage;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getItemValue() {
        return itemValue;
    }

    public void setItemValue(Double itemValue) {
        this.itemValue = itemValue;
    }

    public Date getPostedDate() {
        return postedDate;
    }

    public void setPostedDate(Date postedDate) {
        this.postedDate = postedDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public Boolean getFeatured() {
        return featured;
    }

    public void setFeatured(Boolean featured) {
        this.featured = featured;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public Date getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(Date pickupTime) {
        this.pickupTime = pickupTime;
    }

    public Date getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(Date deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getPolyline() {
        return polyline;
    }

    public void setPolyline(String polyline) {
        this.polyline = polyline;
    }

    public String getDistanceText() {
        return distanceText;
    }

    public void setDistanceText(String distanceText) {
        this.distanceText = distanceText;
    }

    public String getTrippieId() {
        return trippieId;
    }

    public void setTrippieId(String trippieId) {
        this.trippieId = trippieId;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringList(listingImage);
        dest.writeString(deliveryAddress);
        dest.writeString(pickupAddress);
        dest.writeString(vetImageUrl);
        dest.writeString(userId);
        dest.writeString(driverId);
        dest.writeString(title);
        dest.writeString(category);
        dest.writeString(description);
        dest.writeString(instructions);
        dest.writeString(size);
        dest.writeString(thumbnailUrl);
        dest.writeString(polyline);
        dest.writeString(distanceText);
        dest.writeString(trippieId);
        if (itemValue == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(itemValue);
        }
        if (price == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(price);
        }
        dest.writeByte((byte) (featured == null ? 0 : featured ? 1 : 2));
        dest.writeByte((byte) (urgent == null ? 0 : urgent ? 1 : 2));
        dest.writeByte((byte) (isActive ? 1 : 0));
    }

    public Boolean getUrgent() {
        return urgent;
    }

    public void setUrgent(Boolean urgent) {
        this.urgent = urgent;
    }

    public Boolean getSignatureRequired() {
        return signatureRequired;
    }

    public void setSignatureRequired(Boolean signatureRequired) {
        this.signatureRequired = signatureRequired;
    }

    public Boolean getUserHasBeenRated() {
        return userHasBeenRated;
    }

    public void setUserHasBeenRated(Boolean userHasBeenRated) {
        this.userHasBeenRated = userHasBeenRated;
    }

    public Boolean getDriverHasBeenRated() {
        return driverHasBeenRated;
    }

    public void setDriverHasBeenRated(Boolean driverHasBeenRated) {
        this.driverHasBeenRated = driverHasBeenRated;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getMeetingDriverPickup() {
        return meetingDriverPickup;
    }

    public void setMeetingDriverPickup(int meetingDriverPickup) {
        this.meetingDriverPickup = meetingDriverPickup;
    }

    public int getMeetingDriverDelivery() {
        return meetingDriverDelivery;
    }

    public void setMeetingDriverDelivery(int meetingDriverDelivery) {
        this.meetingDriverDelivery = meetingDriverDelivery;
    }

    public String getPersonMeetingPickupName() {
        return personMeetingPickupName;
    }

    public void setPersonMeetingPickupName(String personMeetingPickupName) {
        this.personMeetingPickupName = personMeetingPickupName;
    }

    public String getPersonMeetingPickupPhone() {
        return personMeetingPickupPhone;
    }

    public void setPersonMeetingPickupPhone(String personMeetingPickupPhone) {
        this.personMeetingPickupPhone = personMeetingPickupPhone;
    }

    public String getPersonMeetingDeliveryName() {
        return personMeetingDeliveryName;
    }

    public void setPersonMeetingDeliveryName(String personMeetingDeliveryName) {
        this.personMeetingDeliveryName = personMeetingDeliveryName;
    }

    public String getPersonMeetingDeliveryPhone() {
        return personMeetingDeliveryPhone;
    }

    public void setPersonMeetingDeliveryPhone(String personMeetingDeliveryPhone) {
        this.personMeetingDeliveryPhone = personMeetingDeliveryPhone;
    }

    public Boolean getCancelled() {
        return cancelled;
    }

    public void setCancelled(Boolean cancelled) {
        this.cancelled = cancelled;
    }

    public int getRatingReminderCount() {
        return ratingReminderCount;
    }

    public void setRatingReminderCount(int ratingReminderCount) {
        this.ratingReminderCount = ratingReminderCount;
    }

    public enum Status {
        customer_accepted,
        on_The_Way_To_Pick_Up,
        picked_Up,
        on_The_Way_To_Delivery,
        delivered
    }


    private boolean isActive;
    private Status status;
    private Map<String, Offer> offers;
    private Map<String, StatusDetail> statusDetails;

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }


    public Map<String, Offer> getOffers() {
        return offers;
    }

    public void setOffers(Map<String, Offer> offers) {
        this.offers = offers;
    }

    public Map<String, StatusDetail> getStatusDetails() {
        return statusDetails;
    }

    public void setStatusDetails(Map<String, StatusDetail> statusDetails) {
        this.statusDetails = statusDetails;
    }
}
