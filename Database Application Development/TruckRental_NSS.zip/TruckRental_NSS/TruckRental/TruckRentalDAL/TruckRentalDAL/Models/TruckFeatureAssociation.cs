﻿using System;
using System.Collections.Generic;

namespace TruckRentalDAL.Models
{
    public partial class TruckFeatureAssociation
    {
        public int TruckId { get; set; }
        public int FeatureId { get; set; }

        public TruckFeature Feature { get; set; }
        public IndividualTruck Truck { get; set; }
    }
}
