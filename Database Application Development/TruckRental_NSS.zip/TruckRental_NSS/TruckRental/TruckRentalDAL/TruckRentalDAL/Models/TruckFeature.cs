﻿using System;
using System.Collections.Generic;

namespace TruckRentalDAL.Models
{
    public partial class TruckFeature
    {
        public TruckFeature()
        {
            TruckFeatureAssociation = new HashSet<TruckFeatureAssociation>();
        }

        public int FeatureId { get; set; }
        public string Description { get; set; }

        public ICollection<TruckFeatureAssociation> TruckFeatureAssociation { get; set; }
    }
}
