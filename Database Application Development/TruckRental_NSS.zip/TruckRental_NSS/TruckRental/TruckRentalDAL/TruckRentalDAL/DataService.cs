﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TruckRentalDAL.Models;

namespace TruckRentalDAL
{
    public class DataService
    {
        //Employee & Customer Management
        public static void addEmployee(TruckEmployee emp)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                ctx.TruckEmployee.Add(emp);
                ctx.SaveChanges();
            }
        }

        public static TruckEmployee searchEmployeeById(int id)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckEmployee.Include(e => e.Employee).Where(e => e.EmployeeId == id).FirstOrDefault();
            }
        }

        public static TruckEmployee searchEmployeeByUsername(string username)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckEmployee.Include(e => e.Employee).Where(e => e.Username == username).FirstOrDefault();
            }
        }

        public static TruckCustomer searchCustomerById(int id)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckCustomer.Include(c => c.Customer).Where(c => c.CustomerId == id).FirstOrDefault();
            }
        }

        public static void updateEmployee(TruckEmployee emp)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                ctx.Entry(emp).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                ctx.Entry(emp.Employee).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                ctx.SaveChanges();
            }
        }

        public static void updateCustomer(TruckCustomer customer)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                ctx.Entry(customer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                ctx.Entry(customer.Customer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                ctx.SaveChanges();
            }
        }

        public static TruckEmployee login(string username, string password)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckEmployee.Where(e => e.Username == username && e.Password == password).SingleOrDefault();
            }
        }

        //Rental Management               
        public static void rentTruck(TruckRental record, bool isNewCustomer)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                if (!isNewCustomer)
                {
                    ctx.Entry(record.Customer).State = EntityState.Unchanged;
                }
                ctx.Entry(record.Truck).State = EntityState.Modified;
                ctx.TruckRental.Add(record);
                ctx.SaveChanges();
            }
        }

        public static void returnTruck(TruckRental record)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                ctx.Entry(record).State = EntityState.Modified;
                ctx.Entry(record.Truck).State = EntityState.Modified;
                ctx.SaveChanges();
            }
        }

        public static TruckRental searchRecordForReturn(int customerId, int truckId)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckRental.Where(r => r.CustomerId == customerId && r.TruckId == truckId && r.ReturnDate == DateTime.MinValue).FirstOrDefault();
            }
        }

        public static IndividualTruck searchTruckbyID(int id)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {

                return ctx.IndividualTruck.Where(t => t.TruckId == id).FirstOrDefault();

            }
        }

        public static List<TruckRental> searchTruckRentByCustomerID(int custID)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckRental.Include(t => t.Truck)
                    .Where(c => c.CustomerId == custID).ToList();
            }
        }
        public static List<TruckRental> searchTruckBetweenDates(DateTime startDate, DateTime endDate)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckRental.Include(t => t.Truck).
                    Where(d => d.RentDate >= startDate && d.RentDate <= endDate).ToList();
            }
        }
        
        public static List<TruckRental> allRentedTruckRecords()
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckRental.Where(r => r.ReturnDate == DateTime.MinValue).ToList();
            }
        }

        public static TruckCustomer searchCustomerByNameNAge(string name, int age)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckCustomer.Include(p => p.Customer).Where(c => c.Age == age && c.Customer.Name == name).FirstOrDefault();
            }
        }

        //Stock Management 
        public static void addTruck(IndividualTruck truck, bool isExistingModel)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                if (isExistingModel)
                {
                    ctx.Entry(truck.TruckModel).State = EntityState.Unchanged;

                }

                ctx.IndividualTruck.Add(truck);
                ctx.SaveChanges();

            }
        }

        public static List<TruckFeature> getAllTruckFeatures()
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckFeature.ToList();
            }

        }

        public static List<IndividualTruck> GetAllTrucksByModelId(int id)

        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.IndividualTruck.Include(d => d.TruckModel).Where(c => c.TruckModelId == id).ToList();
            }

        }

        public static List<IndividualTruck> allTrucksAvailableForRent()
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.IndividualTruck.Where(t => t.Status == "available for rent").ToList();
            }
        }


        public static List<IndividualTruck> searchTrucksByModelId(int modelId)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.IndividualTruck.Include(t => t.TruckModel).Where(t => t.TruckModelId == modelId).ToList();
                //ctx.IndividualTruck.Include(t => t.TruckModel).Where(t => t.TruckModelId == modelId).ToList();
            }

        }

        //public static void UpdateTruckInfo(IndividualTruck it)
        //{
        //    using (var ctx = new DAD_TruckRental_NSSContext())
        //    {
        //        TruckModel tm = new TruckModel();
        //        //ctx.Entry(it).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //        //ctx.Entry(tm).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //        ctx.SaveChanges();
        //    }
        //}

        public static TruckModel searchTruckModelById(int id)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckModel.Where(c => c.ModelId == id).FirstOrDefault();
            }

        }

        public static List<TruckModel> getAllModels()
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                return ctx.TruckModel.ToList();
            }
        }

        public static List<IndividualTruck> SearchTruckByStatus(string status)
        {
            using (var ctx = new DAD_TruckRental_NSSContext())
            {
                var newList = new List<IndividualTruck>();
                // return ctx.IndividualTruck.Where(t => t.Status == status).ToList();
                return ctx.IndividualTruck.Where(t => t.Status == status).ToList();
            }
        }
        
    }
}
