﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;
        public CartController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }

        //10/09/18 SKH can't get to run complex join queries
        //public string GetCartItems(int invoiceId)
        //{
        //    string sql = "SELECT OrderItem.OrderItemID, Product.ProductName, OrderItem.Quantity, OrderItem.TotalPrice, Invoice.InvoiceId" +
        //        "FROM OrderItem INNER JOIN Product ON OrderItem.ProductID = Product.ProductId INNER JOIN Invoice ON OrderItem.InvoiceID = Invoice.InvoiceId" +
        //        "WHERE Product.UnitPrice = @p0";            
        //    var cartItem = _context.FromSql(sql, invoiceId).ToList();
        //    return JsonConvert.SerializeObject(cartItem);
        //}
    }
}