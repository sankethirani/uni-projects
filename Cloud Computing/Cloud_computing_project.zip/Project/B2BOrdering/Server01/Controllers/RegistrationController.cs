﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class RegistrationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //Code for database access
        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;
        public RegistrationController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }


        //POST /members/register
        [HttpPost]
        public string Register(string json)
        {
            var user = JsonConvert.DeserializeObject<User>(json);
            user.Password = GetHash(user.Password);
            user.Role = "Customer";
            _context.Add(user);            
            _context.SaveChanges();
            return "SUCCESS with registration.";
        }
       

        private string GetHash(string textToEncrypt)
        {
            //Attribution - thanks to Mike Lopez for advice on one-way encryption 
            var sp = new System.Security.Cryptography.SHA512Managed();
            var enc = new System.Text.UTF8Encoding();
            byte[] hashIn;
            byte[] hashOut;
            //Change the text to encrypt into a byte array of ASCII codes
            //e.g. "A" needs to change to 65
            hashIn = enc.GetBytes(textToEncrypt);
            //We are now ready to encrypt
            hashOut = sp.ComputeHash(hashIn);
            //The result is still in bytes! We need to change back to string
            return Convert.ToBase64String(hashOut);
        }
    }
}