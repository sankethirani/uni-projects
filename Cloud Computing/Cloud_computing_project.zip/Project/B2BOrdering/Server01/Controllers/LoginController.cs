﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        //Code for database access
        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;
        public LoginController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }

        [HttpPost]
        public string Login(string json)
        {
            dynamic jsonObject = JsonConvert.DeserializeObject(json);
            string username = (string)jsonObject.SelectToken("Username");
            string password = (string)jsonObject.SelectToken("Password");
            string xPassword = GetHash(password);
            string sql = "SELECT * FROM [User] WHERE Email = @p0 AND Password = @p1";
            var user = _context.User.FromSql(sql, username, xPassword).ToList();
            var loginResponse = new LoginResponse();
            //Success is when there is 1 matching row for this username/password
            if (user.Count == 1)
            {
                loginResponse.issuccess = true;
                loginResponse.response = "SUCCESS with login";
                loginResponse.userid = user[0].UserId;
                loginResponse.userRole = user[0].Role;
            }
            else
            {
                loginResponse.issuccess = false;
                loginResponse.response = "Login unsuccessful";
                loginResponse.userid = -1;
                loginResponse.userRole = "";
            }
            string response = JsonConvert.SerializeObject(loginResponse);
            return response;
        }

        public class LoginResponse
        {
            public bool issuccess;
            public string response;
            public int userid;
            public string userRole;
        }


        private string GetHash(string textToEncrypt)
        {
            //Attribution - thanks to Mike Lopez for advice on one-way encryption 
            var sp = new System.Security.Cryptography.SHA512Managed();
            var enc = new System.Text.UTF8Encoding();
            byte[] hashIn;
            byte[] hashOut;
            //Change the text to encrypt into a byte array of ASCII codes
            //e.g. "A" needs to change to 65
            hashIn = enc.GetBytes(textToEncrypt);
            //We are now ready to encrypt
            hashOut = sp.ComputeHash(hashIn);
            //The result is still in bytes! We need to change back to string
            return Convert.ToBase64String(hashOut);
        }

    }
}