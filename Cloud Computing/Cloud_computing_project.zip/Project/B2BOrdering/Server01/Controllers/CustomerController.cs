﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class CustomerController : Controller
    {
        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;

        public CustomerController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public string GetCustomer(int customerId)
        {
            var customer = _context.User.Where(c => c.UserId == customerId).SingleOrDefault();
            string json = JsonConvert.SerializeObject(customer);
            return (json);
        }

        [HttpPost]
        public string UpdateCustomer(string json)
        {
            var customer = JsonConvert.DeserializeObject<User>(json);
            _context.Update(customer);
            _context.SaveChanges();
            return ("Customer details updated");
        }

        [HttpPost]
        public string DeleteCustomer(string json)
        {
            var customer = JsonConvert.DeserializeObject<User>(json);
            _context.Remove(customer);
            _context.SaveChanges();
            return ("Customer deleted");
        }
        
    }
}