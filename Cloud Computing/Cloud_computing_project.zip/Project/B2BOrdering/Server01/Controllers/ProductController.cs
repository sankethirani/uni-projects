﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //Code for database access
        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;
        public ProductController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }

        //GET /Product/getallproducts
        public string GetAllProducts()
        {
            var products = _context.Product.ToList();
            string json = JsonConvert.SerializeObject(products);
            return json;
        }

        //GET /Product/getproduct
        public string GetProduct(int productid)
        {
            var product = _context.Product.Where(p => p.ProductId == productid).SingleOrDefault();
            var json = JsonConvert.SerializeObject(product);
            return json;
        }

        //POST /Product/postnewproduct
        [HttpPost]
        public string PostNewProduct(string json)
        {
            var product = JsonConvert.DeserializeObject<Product>(json);
            _context.Add(product);
            _context.SaveChanges();
            return "Data Added";
        }

        //POST /Product/postupdateproduct
        [HttpPost]
        public string PostUpdateProduct(string json)
        {
            var product = JsonConvert.DeserializeObject<Product>(json);
            _context.Update(product);
            _context.SaveChanges();
            return "Data Saved";
        }


        //POST /Product/DeleteProduct
        [HttpPost]
        public string DeleteProduct(string json)
        {
            var product = JsonConvert.DeserializeObject<Product>(json);
            _context.Remove(product);
            _context.SaveChanges();
            return "Product Deleted";

        }
    }
}