﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Server01.Models.DB;

namespace Server01.Controllers
{
    public class InvoiceController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        //Code for database access
        private readonly string _appAccessKey;
        private readonly CDQ3_B2BContext _context;
        public InvoiceController(IConfiguration configuration, CDQ3_B2BContext context)
        {
            _appAccessKey = configuration.GetSection("AppSettings")["appAccessKey"];
            _context = context;
        }
        //GET /Invoice/getallinvoices
        public string GetAllInvoices()
        {
            var invoices = _context.Invoice.ToList();
            string json = JsonConvert.SerializeObject(invoices);
            return json;
        }

        //GET /Invoice/getcustomerinvoices
        public string GetCustomerInvoices(int userId)
        {
            var invoices = _context.Invoice.Where(i => i.UserId == userId).ToList();
            string json = JsonConvert.SerializeObject(invoices);
            return json;
        }

        //GET /Invoice/getinvoice
        public string GetInvoice(int invoiceid)
        {
            var invoice = _context.Invoice.Where(i => i.InvoiceId == invoiceid).SingleOrDefault();
            var json = JsonConvert.SerializeObject(invoice);
            return json;
        }

        //POST /Invoice/postnewinvoice
        [HttpPost]
        public string PostNewInvoice(string json)
        {
            var invoice = JsonConvert.DeserializeObject<Invoice>(json);
            _context.Add(invoice);
            _context.SaveChanges();
            return "Data Added";
        }

    }
}