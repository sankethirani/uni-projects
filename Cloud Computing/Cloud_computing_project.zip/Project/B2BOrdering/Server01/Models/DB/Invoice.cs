﻿using System;
using System.Collections.Generic;

namespace Server01.Models.DB
{
    public partial class Invoice
    {
        public Invoice()
        {
            OrderItem = new HashSet<OrderItem>();
        }

        public int InvoiceId { get; set; }
        public int UserId { get; set; }
        public decimal? TotalAmount { get; set; }
        public DateTime? Date { get; set; }

        public User User { get; set; }
        public ICollection<OrderItem> OrderItem { get; set; }
    }
}
