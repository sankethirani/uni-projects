﻿using System;
using System.Collections.Generic;

namespace Server01.Models.DB
{
    public partial class User
    {
        public User()
        {
            Invoice = new HashSet<Invoice>();
        }

        public int UserId { get; set; }
        public string BusinessName { get; set; }
        public string Representative { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string StreetAddress { get; set; }
        public string Suburb { get; set; }
        public string City { get; set; }
        public int? ZipCode { get; set; }
        public string Role { get; set; }
        public string Password { get; set; }

        public ICollection<Invoice> Invoice { get; set; }
    }
}
