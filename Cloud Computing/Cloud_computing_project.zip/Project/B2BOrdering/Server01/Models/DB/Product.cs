﻿using System;
using System.Collections.Generic;

namespace Server01.Models.DB
{
    public partial class Product
    {
        public Product()
        {
            OrderItem = new HashSet<OrderItem>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal? UnitPrice { get; set; }
        public int? QuantityPerUnit { get; set; }
        public int? StockLevel { get; set; }
        public string Category { get; set; }

        public ICollection<OrderItem> OrderItem { get; set; }
    }
}
