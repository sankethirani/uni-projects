﻿//20180908 SPV Load Menu
setupMenu();

function setupMenu() {
    var xmenu;
    var oe = document.getElementById("menu");

    xmenu = new XMLHttpRequest();
    xmenu.open("GET", "sharedMenu.html", false);
    xmenu.send();
    oe.innerHTML = xmenu.responseText;
    checkIfLoggedIn();
}
//if logged in then make Catalog and Editing visible
function checkIfLoggedIn() {
    var userCookie = getCookie("customerid");
    var roleCookie = getCookie("userrole").toLowerCase();
    //alert(roleCookie);
    if (userCookie !== "") {
        document.getElementById("cdetails").style.display = "inline";
        document.getElementById("signup").style.display = "none";
        document.getElementById("invoice").style.display = "inline";
        
    }
    if (roleCookie !== "") {
        document.getElementById("logout").style.display = "inline";
        document.getElementById("login").style.display = "none";
    }
    if (roleCookie === "admin") {
        document.getElementById("addProduct").style.display = "inline";
        document.getElementById("sCustomer").style.display = "inline";
        document.getElementById("invoice").style.display = "inline";
        document.getElementById("signup").style.display = "none"; 
        document.getElementById("cdetails").style.display = "none";
    }
}
//Ref: https://www.w3schools.com/js/js_cookies.asp
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function logout() {
    document.cookie = "customerid=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie = "userrole=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    $.cookie('customerid', "", -1);
    $.cookie('userrole', "", -1);
    alert("You have logged out successfully");
}
