(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.SoccerGoalPostIsolated = function() {
	this.initialize(img.SoccerGoalPostIsolated);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1680,1008);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.SoccerGoalPostIsolated();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.3,0.29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,504.3,292.6), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("ABJiWQAZAMAUAVQAeAdAMAmQAHAXAAAbQAAA5ghAsQgHAJgJAIQgxAxhFAAQgZAAgXgHQgngLgegfQgxgxAAhFIAAAAQAAhEAxgxQADgDAEgEIA6A/IBFgiIBGBOIBJghABXgRIgKBWIA5AgAhEAqIhigqAhuh8QAvgqA/AAQAoAAAhAQAg0g9IgQBnIBFA+IgxA4AABBoIBMgjAARhfIA4g3");
	this.shape.setTransform(16.7,16.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("Ah1B6QgxgxAAhFIAAgBIBiAqIBEA+IgwA4QgmgLgfgegABNBIIAKhVIBJgiQAHAYAAAbQAAA5ghArgAhuh4QAvgqA/gBQAoABAhAQIg4A3IhFAig");
	this.shape_1.setTransform(16.7,16.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgsCYIAwg4IBMgjIA5AfIgPASQgxAxhFAAQgZAAgXgHgAhAAiIAQhnIBEgiIA5g3QAYAMAVAVQAdAdAMAlIhJAiIhGhOIBGBOIgKBWIhMAjgAiigIQAAhEAxgxIAHgHIA6A/IgQBngAgwhFg");
	this.shape_2.setTransform(16.3,17.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-1,-1,35.4,35.4), null);


// stage content:
(lib.Untitled1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Football
	this.instance = new lib.Symbol1();
	this.instance.parent = this;
	this.instance.setTransform(5.8,405.8,5.485,5.485,0,0,0,16.7,16.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:5.29,scaleY:5.29,rotation:30,x:9.4,y:373},0).wait(1).to({scaleX:5.09,scaleY:5.09,rotation:60,x:14.5,y:340.3},0).wait(1).to({scaleX:4.89,scaleY:4.89,rotation:15,x:21.5,y:308},0).wait(1).to({scaleX:4.69,scaleY:4.69,rotation:53,x:30.3,y:276.1},0).wait(1).to({scaleX:4.49,scaleY:4.49,rotation:143.1,x:41.4,y:245},0).wait(1).to({scaleX:4.29,scaleY:4.29,rotation:166.4,x:55.1,y:214.9},0).wait(1).to({scaleX:4.09,scaleY:4.09,rotation:204.5,x:71.5,y:186.2},0).wait(1).to({scaleX:3.9,scaleY:3.9,rotation:234.3,x:90.8,y:159.3},0).wait(1).to({scaleX:3.7,scaleY:3.7,rotation:159.4,x:113.2,y:134.9},0).wait(1).to({scaleX:3.5,scaleY:3.5,rotation:99.4,x:138.2,y:113.4},0).wait(1).to({scaleX:3.3,scaleY:3.3,rotation:-5.7,x:165.7,y:95.1},0).wait(1).to({scaleX:3.1,scaleY:3.1,rotation:-80.5,x:195.2,y:80.2},0).wait(1).to({scaleX:2.9,scaleY:2.9,rotation:54.3,x:226.1,y:68.5},0).wait(1).to({scaleX:2.7,scaleY:2.7,rotation:-125.6,x:258.1,y:60},0).wait(1).to({scaleX:2.5,scaleY:2.5,rotation:-5.6,x:290.6,y:54.4},0).wait(1).to({scaleX:2.31,scaleY:2.31,rotation:144.5,x:323.6,y:51.1},0).wait(1).to({scaleX:2.11,scaleY:2.11,rotation:24.4,x:356.6,y:50.2},0).wait(1).to({scaleX:1.91,scaleY:1.91,rotation:84.3,x:389.7,y:51.1},0).wait(1).to({scaleX:1.71,scaleY:1.71,x:422.6,y:53.7},0).wait(1).to({x:420.8,y:48.7},0).wait(1).to({x:418.9,y:43.7},0).wait(1).to({x:416.8,y:38.8},0).wait(1).to({x:414.6,y:33.9},0).wait(1).to({x:412.1,y:29.2},0).wait(1).to({x:409.4,y:24.6},0).wait(1).to({x:406.4,y:20.2},0).wait(1).to({x:402.8,y:16.2},0).wait(1).to({x:398.6,y:13},0).wait(1).to({x:393.6,y:11.2},0).wait(1).to({x:388.3,y:11.8},0).wait(1).to({x:383.6,y:14.3},0).wait(1).to({x:379.7,y:17.8},0).wait(1).to({x:376.3,y:22},0).wait(1).to({x:373.3,y:26.4},0).wait(1).to({x:370.6,y:31},0).wait(1).to({x:368.1,y:35.7},0).wait(1).to({x:365.8,y:40.5},0).wait(1).to({x:363.7,y:45.4},0).wait(1).to({x:361.6,y:50.4},0).wait(1).to({x:359.7,y:55.3},0).wait(1).to({x:357.9,y:60.4},0).wait(1).to({x:356.1,y:65.4},0).wait(1).to({x:354.5,y:70.5},0).wait(1).to({x:352.8,y:75.6},0).wait(1).to({x:351.3,y:80.7},0).wait(1).to({x:349.7,y:85.8},0).wait(1).to({x:348.3,y:90.9},0).wait(1).to({x:346.1,y:82.6},0).wait(1).to({x:343.8,y:74.3},0).wait(1).to({x:341.3,y:66.1},0).wait(1).to({x:338.6,y:57.9},0).wait(1).to({x:335.7,y:49.8},0).wait(1).to({x:332.3,y:41.9},0).wait(1).to({x:328.1,y:34.2},0).wait(1).to({x:322.5,y:27.8},0).wait(1).to({x:314.6,y:27},0).wait(1).to({x:309,y:33.2},0).wait(1).to({x:305.2,y:41.1},0).wait(1).to({x:302.3,y:49.2},0).wait(1).to({x:299.9,y:57.5},0).wait(1).to({x:297.8,y:65.8},0).wait(1).to({x:296,y:74.2},0).wait(1).to({x:294.3,y:82.6},0).wait(1).to({x:292.8,y:91.1},0).wait(1).to({x:291.4,y:99.6},0).wait(1).to({x:290.1,y:108.1},0).wait(1).to({x:288.9,y:116.6},0).wait(1).to({x:287.7,y:125.1},0).wait(1).to({x:286.6,y:133.7},0).wait(1).to({x:285.6,y:142.2},0).wait(1).to({x:284.6,y:150.8},0).wait(25));

	// Goal
	this.text = new cjs.Text("300 G   ALS", "80px 'Times New Roman'", "#E60000");
	this.text.textAlign = "center";
	this.text.lineHeight = 91;
	this.text.lineWidth = 478;
	this.text.parent = this;
	this.text.setTransform(276,-102.4);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({x:275.9},0).wait(2).to({x:275.8},0).wait(2).to({x:275.7},0).wait(2).to({x:275.6},0).wait(2).to({x:275.5},0).wait(2).to({x:275.4},0).wait(2).to({x:275.3},0).wait(2).to({x:275.2},0).wait(2).to({x:275.1},0).wait(2).to({x:275},0).wait(1).to({x:273.8,y:-88.5},0).wait(1).to({x:272.6,y:-74.7},0).wait(1).to({x:271.4,y:-60.8},0).wait(1).to({x:270.2,y:-47},0).wait(1).to({x:269,y:-33.1},0).wait(1).to({x:267.8,y:-19.3},0).wait(1).to({x:266.6,y:-5.4},0).wait(1).to({x:265.4,y:8.4},0).wait(1).to({x:264.2,y:22.3},0).wait(1).to({x:263,y:36.1},0).wait(1).to({x:261.8,y:50},0).wait(1).to({x:260.6,y:63.8},0).wait(1).to({x:259.4,y:77.7},0).wait(1).to({x:258.2,y:91.5},0).wait(1).to({x:257,y:105.4},0).wait(62));

	// Goal-Posts
	this.instance_1 = new lib.Symbol4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(252,92.3,1.002,1,0,0,0,251.6,146.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:252.2,x:252.7},0).wait(4).to({x:252.8},0).wait(3).to({x:252.9},0).wait(2).to({x:253},0).wait(1).to({x:253.1,y:92.4},0).wait(3).to({x:253.2},0).wait(2).to({scaleX:1,x:253.3},0).wait(3).to({x:253.4,y:92.3},0).wait(1).to({y:76.9},0).wait(1).to({y:61.5},0).wait(1).to({y:46.1},0).wait(1).to({y:30.7},0).wait(1).to({y:15.3},0).wait(1).to({y:-0.1},0).wait(1).to({y:-15.5},0).wait(1).to({y:-30.9},0).wait(1).to({scaleY:1,y:-46.3},0).wait(1).to({y:-61.6},0).wait(1).to({y:-77},0).wait(1).to({y:-92.4},0).wait(1).to({y:-107.8},0).wait(1).to({y:-123.2},0).wait(1).to({y:-138.6},0).wait(4).to({y:-138.7},0).wait(2).to({scaleX:1},0).wait(8).to({y:-138.6},0).wait(9).to({y:-138.7},0).wait(7).to({scaleX:1},0).wait(3).to({y:-138.6},0).wait(9).to({y:-138.7},0).wait(8).to({scaleY:1},0).wait(2).to({y:-138.6},0).wait(2).to({scaleX:1},0).wait(7).to({y:-138.7},0).wait(1));

	// Background
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("EgnfgXfMBO/AAAMAAAAu/MhO/AAAg");
	this.shape.setTransform(252,150.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#8C8C8C").s().p("EgnfAXgMAAAgu/MBO/AAAMAAAAu/g");
	this.shape_1.setTransform(252,150.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(96));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(163.9,45.6,605.6,604.5);
// library properties:
lib.properties = {
	id: 'B03E34967656C94AB59920D7DBA02DA1',
	width: 505,
	height: 300,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/SoccerGoalPostIsolated.png", id:"SoccerGoalPostIsolated"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B03E34967656C94AB59920D7DBA02DA1'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;