﻿var index = 0;
carousel();

function carousel() {
    var i;
    var images = document.getElementsByClassName("mySlides");
    var news = document.getElementsByClassName("contentSlides");
    for (i = 0; i < images.length; i++) {
        images[i].style.display = "none";
        news[i].style.display = "none";
    }
    index++;
    if (index > images.length) { index = 1 }
    images[index - 1].style.display = "block";
    news[index - 1].style.display = "block";
    setTimeout(carousel, 4000); // Change image every 2 seconds
}